################################################################################
##
## File: vMEM-Simula-dev.R
##
## Purpose:
##  R functions for vMEM simulation.
##
## Created: 2010.10.02
##
## Version: 2012.10.19
##
## Author:
##  Fabrizio Cipollini <cipollini@ds.unifi.it>
##
################################################################################

.simula.uMean <-
function(nobs, neqn, muParm, uMean)
{
  ##############################################################################
  ## Description:
  ##  Set the unconditional mean values corresponding to all observations. 
  ## 
  ## Arguments:
  ##  nobs: (numeric[1]) number of observations.
  ##  neqn: (numeric[1]) number of equations.
  ##  muParm: (numeric) parameters corresponding to the unconditional mean.
  ##  uMean: (NULL or numeric[neqn] or matrix[1,neqn] or matrix[nobs,neqn]) 
  ##   unconditional mean values.
  ##  
  ## Values:
  ##  (matrix[nobs,neqn]) unconditional mean values.
  ##############################################################################

  ## FUNCTION:

  #### Unconditional mean values
  if ( length(uMean) == neqn )
  {
    uMean <- matrix(data = uMean, nrow = nobs, ncol = neqn, byrow = TRUE)
  }
  else if ( NROW(uMean) == 0 || NCOL(uMean) != neqn )
  {
    if ( NROW(muParm) != neqn )
    {
      stop("Arguments 'uMean' and 'muParm' are not consistent with the structure of the model")
    }
    else
    {
      uMean <- matrix(data = muParm, nrow = nobs, ncol = neqn, byrow = TRUE)
    }
  }
  else if ( NROW(uMean) != nobs )
  {
    stop("Argument 'uMean' is not consistent with the length of the time series")
  }
  
  #### Answer
  uMean
}
# ------------------------------------------------------------------------------


.simula.mu <-
function(model, uMean, eta0, xi0, eps, signRet)
{
  ##############################################################################
  ## Description:
  ##  Simulates the mu components of a vMEM.
  ##
  ## Arguments:
  ##  model: (list) .
  ##  uMean: (NULL or numeric[neqn] or matrix[1,neqn] or matrix[nobs,neqn]) 
  ##   unconditional mean values.
  ##  eta0: (numeric) .
  ##  xi0: (numeric) .
  ##  eps: (matrix)
  ##  signRet: (character[1])
  ##
  ## Values:
  ##  (matrix) simulated time series.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  ## Model
  model <- .iaux(x = model, iter = c(mu = TRUE, betaE = TRUE))
  iaux  <- model$iaux
  iauxW <- model$iauxW
  model <- model$model
  ## Dimensions
  nobs   <- NROW(eps)
  neqn   <- NCOL(eps)
  niv    <- iaux$niv
  pos    <- iaux$pos
  in1Eqn <- iaux$in1Eqn
  np1Eqn <- iaux$np1Eqn
  in2Eqn <- iaux$in2Eqn
  np2Eqn <- iaux$np2Eqn
  nLagE  <- iaux$nLagE
  mLagE  <- iaux$mLagE
  nF     <- iaux$nF
  nLagF  <- iaux$nLagF
  mLagF  <- iaux$mLagF
  nE     <- iaux$nE
  nLagE  <- iaux$nLagE
  mLagE  <- iaux$mLagE
  nEta   <- iaux$nF - neqn
  indEta   <- nEta > 0
  indXi    <- (nEta + 1) : nF
  indErr2  <- niv > neqn
  indxInd2 <- (niv - neqn + 1) : niv
  indMod   <- iaux$indMod == 3
  ## Parameters
  parmVal <- model[, "start"]
  ## 'psi' parameters
  ind <- iauxW$parm == .psi.N()
  if ( any(ind) )
  {
    psiParmVal <- parmVal[ind]
  }
  else
  {
    psiParmVal <- 0
  }
  
  #### Build starting values for fltLag
  x1 <- NULL
  if (indEta)
  {
    x1 <- c(x1, eta0)
  }
  x1 <- c(x1, xi0)
  fltLag <- .fltLag.start(x = x1, mLag = iaux$mLagF)
  
  #### Build starting values for errLag
  x1 <- numeric(nE)
  errLag <- .fltLag.start(x = x1, mLag = iaux$mLagE)

  #### Build starting values (time 0) for xDep and xInd
  x1   <- uMean[1,] + ifelse(indEta, psiParmVal * eta0, 0) + xi0
  xDep <- matrix(data = x1, nrow = 1)
  xInd <- .xInd(iauxList = iaux, xDep = xDep, xRet = x1, xPred = NULL)$x
  x1   <- signRet[1,] * 0

  #### Initialize
  muMatrix  <- matrix(data = NA, nrow = nobs, ncol = neqn)
  fltMatrix <- matrix(data = NA, nrow = nobs, ncol = nF)

  #### Cycle the filter
  for (i in 1 : nobs)
  {
    #### Store AR and ERR into x2 
    x2 <-   .Fortran(
      "X2ST", 
      nLagF   = as.integer(nLagF), 
      fltLag  = as.double(fltLag), 
      nLagE   = as.integer(nLagE), 
      errLag  = as.double(errLag),
      ans     = double(nLagF + nLagE),
      PACKAGE = .package())$ans

    #### Filter
    flt <- .Fortran(
      "FLT2w", 
      parmVal = as.double(parmVal), 
      pos     = as.integer(pos), 
      x2      = as.double(x2),
      nF      = as.integer(nF),
      in2Eqn  = as.integer(in2Eqn),
      np2Eqn  = as.integer(np2Eqn), 
      flt     = double(nF),
      PACKAGE = .package())$flt

    #### 'mu' value
    mu <- uMean[i, ] + psiParmVal * flt[1] + flt[indXi]    

    #### xDep and xInd
    xDep <- matrix(data = mu * eps[i,], nrow = 1)
    xInd <- .xInd(iauxList = iaux, xDep = xDep, xRet = signRet[i,], 
      xPred = NULL)$x

    #### err
    err <- xDep - mu
    if ( indErr2 )
    {
      err <- c(err, xInd[indxInd2] - 0.5 * mu)
    }

    ####
    fltLag <- .Fortran( "FLTLU", 
      nF     = as.integer(nF), 
      nLagF  = as.integer(nLagF), 
      mLagF  = as.integer(mLagF), 
      flt    = as.double(flt), 
      fltLag = as.double(fltLag), 
      PACKAGE = .package())$fltLag
    errLag <- .Fortran( "FLTLU", 
      nE     = as.integer(nE), 
      nLagE  = as.integer(nLagE), 
      mLagE  = as.integer(mLagE), 
      err    = as.double(err), 
      errLag = as.double(errLag),
      PACKAGE = .package())$errLag

    #### Store
    muMatrix[i, ] <- mu
    fltMatrix[i, ] <- flt
  }


  ##############################################################################
  ## Part 4: Answer
  ##############################################################################

  #### Answer
  list(mu = muMatrix, flt = fltMatrix, model = model)
}
# ------------------------------------------------------------------------------


MEM.simula <-
function(model, eps, uMean = NULL, eta0 = NULL, xi0 = NULL, 
  signRet = "1", nBurn = 1000)
{
  ##############################################################################
  ## Description:
  ##  Simulates a vMEM.
  ##
  ## Arguments:
  ##  model: (data.frame) model for simulating a vMEM.
  ##  eps: (matrix[nobs,k]) Values of the error component. 
  ##  uMean: (NULL or numeric[neqn] or matrix[1,neqn] or matrix[nobs,neqn]) 
  ##   unconditional mean values.
  ##  eta0: (numeric[1]) Starting value for 'eta' (long-term component). 
  ##  xi0: (numeric[k]) Starting values for 'xi' (short-term component). 
  ##  signRet: (character[1]) There is only one indicator of returns?
  ##   Needed only if 'gamma' parameters are included into 'model'.
  ##  nBurn: (numeric[1]) Number of burning observations.
  ##
  ## Values:
  ##  (matrix[nobs,k]) simulated time series.
  ##############################################################################

  # FUNCTION:

  ##############################################################################
  ## Part 0: Settings
  ##############################################################################
  
  #### Length of the simulated series
  nTot <- NROW(eps)
  #### Number of simulated obs
  nobs <- nTot - nBurn
  if (nobs <= 0)
  {
    stop("NROW(eps) must be > nBurn")
  }
  
  #### Build
  model <- list(add = model)
  model <- .model.build(x = model)$model

  #### Extract
  model <- .extract.model(x = model)  

  #### Check the size of eps
  neqn <- .neqn(x = model[, "eqn"])
  if (NCOL(eps) != neqn)
  {
    stop("Arguments 'model' and 'eps' are not consistent.")
  }


  ##############################################################################
  ## Part 1: Initialize
  ##############################################################################
  
  #### Simulates 'signRet'
  x1 <- c(.gammaX.N(), .gammaE.N())
  if ( any( model[, "parm"] %in% x1 ) )
  {
    nc <- ifelse( signRet[1] == "1", 1, neqn)
    x <- 2 * rbinom(n = nTot * nc, size = 1, prob = 0.5) - 1
    signRet  <- matrix(data = x, nrow = nTot, ncol = nc)
  }
  else
  {
    signRet <- NULL
  }
  
  #### eta0
  if ( NROW(eta0) == 0 )
  {
    eta0 <- 0
  }
  else
  {
    eta0 <- eta0[1]
  }
  
  #### xi0
  if ( NROW(xi0) < neqn )
  {
    xi0 <- numeric(neqn)
  }
  else
  {
    xi0 <- xi0[1 : neqn]
  }
  

  ##############################################################################
  ## Part 2: Simulates
  ##############################################################################

  #### Unconditional mean values
  muParmVal <- model[model[, "parm"] == .mu.N(), "start"]
  uMean <- .simula.uMean(nobs = nTot, neqn = neqn, 
    muParm = muParmVal, uMean = uMean)

  #### mu values
  x1 <- .simula.mu(model = model, uMean = uMean, eta0 = eta0, xi0 = xi0, 
    eps = eps, signRet = signRet)
  model <- x1$model
  mu  <- x1$mu
  flt <- x1$flt

  #### x values
  x <- mu * eps


  ##############################################################################
  ## Part 3: Answer
  ##############################################################################

  #### Prune burning values
  ind <- (nBurn + 1) : nTot
  uMean <- uMean[ind, , drop = FALSE]
  eps <- eps[ind, , drop = FALSE]
  mu  <- mu[ind, , drop = FALSE]
  flt <- flt[ind, , drop = FALSE]
  signRet <- signRet[ind, , drop = FALSE]
  x <- x[ind, , drop = FALSE]

  #### Decompose flt
  nEta <- NCOL(flt) - neqn
  nobs <- NROW(x)
  ## 'eta'
  if ( nEta > 0 )
  {
    eta <- flt[, 1 : nEta]
  }
  else
  {
    eta <- numeric(nobs)
  }
  ## 'xi'
  xi <- flt[, (nEta + 1) : NCOL(flt)]

  #### Answer
  list(x = x, signRet = signRet, 
    mu = mu, uMean = uMean, eta = eta, xi = xi, eps = eps, 
    model = model)
}
# ------------------------------------------------------------------------------
