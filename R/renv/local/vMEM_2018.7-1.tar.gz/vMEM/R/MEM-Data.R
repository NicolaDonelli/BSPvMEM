################################################################################
## 
## File: MEM-Data.R
##
## Purpose: 
##  MEM: Handle data on the basis of model formulation.
##
## Created: 2010.05.09
## 
## Version: 2014.12.02
##
################################################################################
## 
## PART I - FUNCTION:              HANDLE DATA ON THE BASIS OF 'MODEL'
##  .check.modelVsData()            Check 'model' formulation versus data
##  .ind.lt0()                      Transform: x < 0 -> 1; x == 0 or NA -> 0.5; 
##                                   x > 0 -> 0.  
##  .xInd()                         Make all xInd from a 'model'
##  .xDep()                         Make xDep from a 'model'
## 
################################################################################

.check.modelVsData <- 
function(iauxList, xDep, xRet = NULL, xPred = NULL)
{
  ##############################################################################
  ## Description:
  ##  Check consistency between the model and the input data.
  ##
  ## Arguments:
  ##  iauxList: (list) model description
  ##  xDep: (numeric) time series                                       
  ##  xRet: (numeric) returns (if any) or NULL (if not)
  ##  xPred: (matrix) predetermined variables (if any) or NULL (if not)
  ## 
  ## Value: 
  ##  NONE
  ##
  ## Remarks: 
  ##  Use 'parm' and 'lag' from 'iauxList'.
  ##############################################################################

  ## FUNCTION:
  
  #### Extract
  parm <- iauxList$parm
  lag <- iauxList$lag
  
  #### Check for parameters needing 'xRet'
  ## Ind
  ind <- parm %in% c( .gammaE.N(), .gammaX.N() )
  ## xRet is given?
  if ( any(ind) )
  {
  	#### xRet given?
  	ind <- NROW(xRet) == 0
  	if ( ind )
  	{
       stop("Parms 'gammaE'/'gammaX' need values for 'xRet'.")
    }
    
#    #### NROW(xRet) == NROW(xDep)?
#    ind <- NROW(xRet) != NROW(xDep)
#    if ( ind )
#    {
#       stop("NROW(xRet) must be equal to NROW(xDep) but",
#         " NROW(xRet) = ", NROW(xRet),  
#         ", NROW(xDep) = ", NROW(xDep))
#    }

    #### NCOL(xRet) == 1 or NCOL(xDep)?
    ind <- !( NCOL(xRet) %in% c( 1, NCOL(xDep) ) )
    if ( ind )
    {
      stop("NCOL(xRet) must be equal to 1 or to NCOL(xDep) but",
        " NCOL(xRet) = ", NCOL(xRet),  
        ", NCOL(xDep) = ", NCOL(xDep))
    }
  }
  
  #### Check for parameters needing 'xPred'
  ## Ind
	ind  <- parm %in% .delta.N()
  ## xPred is given?
  if ( any(ind) )
  {
  	#### xPred given?
  	if ( NROW(xPred) == 0 )
  	{
      stop("Parms 'delta' need values for 'xPred'.")
    }
    
    #### NROW(xPred) == NROW(xDep)?
    if ( NROW(xPred) != NROW(xDep) )
    {
      stop("'xPred' must have the same length of 'xDep'.")
    }
    
	  #### Enough columns for 'xPred'?
    ## Commented since delta does not have a lag option 
	  # tmp1 <- max( lag[ind] )
    # if ( NCOL(xPred) < tmp1 )
    # {
    #   stop("'xPred' must have as many columns as ", 
    #     "the maximum lag of delta parameters")
    # }    
  }

  #### Answer  
  invisible(NULL)
}
# ------------------------------------------------------------------------------


.ind.lt0 <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Transform: x < 0 -> 1; x == 0 or NA -> 0.5; x > 0 -> 0.  
  ##
  ## Arguments:
  ##  x: (numeric) time series of data.
  ## 
  ## Value: 
  ##  (numeric) new values.
  ##############################################################################
  
  ## FUNCTION:
  
  #### x
  x[is.na(x)] <- 0
  
  #### ind
  ind <- x < 0
  ind[x == 0] <- 0.5

  #### Answer
  ind
}
# ------------------------------------------------------------------------------


.xDep <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Make 'xDep' from a time series on the basis of a given model.
  ##
  ## Arguments:
  ##  x: (numeric) time series 
  ## 
  ## Value: 
  ##  (list) with components
  ##   $x: (numeric) the modeled dependent var.  
  ##   $Ex: (numeric) conditional mean of the dependent var.
  ##############################################################################

  ## FUNCTION:

  ####
  x <- as.matrix(x)
  
  #### Answer
  list(x = x, Ex = colMeans(x))    
}
# ------------------------------------------------------------------------------


.xInd <- 
function(iauxList, xDep, xRet, xPred)
{
  ##############################################################################
  ## Description:
  ##  Make 'xInd' from a time series on the basis of a given model.
  ##
  ## Arguments:
  ##  iauxList: (list) model description
  ##  xDep: (numeric) dependent variable
  ##  xRet: (numeric) returns (if any) or NULL (if not)
  ##  xPred: (matrix) predetermined variables (if any) or NULL (if not)
  ## 
  ## Value: 
  ##  (list) with components
  ##   $x: (matrix) independent vars.
  ##   $Ex: (numeric) conditional mean of the independent vars.
  ##
  ## Remarks: 
  ##  Use 'parm' info from 'iauxList'.
  ##############################################################################

  ## FUNCTION:
    
  ##############################################################################
  ## Part 0: Settings 
  ##############################################################################

  #### 'parm'
  parm <- iauxList$parm
      
      
  ##############################################################################
  ## Part 1: 'mu'
  ##############################################################################

  #### Parameters of interest
  ind <- parm %in% .mu.N()
  
  #### Append
  if ( any(ind) )
  {
    ans <- cbind("1" = rep.int(1, NROW(xDep)))
  }


  ##############################################################################
  ## Part 2: 'delta'
  ##############################################################################

  #### Parameters of interest
  ind <- parm %in% .delta.N()
  
  #### Append
  if ( any(ind) )
  {
    ans <- cbind(ans, xPred)
  }

  
  ##############################################################################
  ## Part 3: 'gammaX' and 'gammaE'
  ##############################################################################

  #### Parameters of interest
  ind <- parm %in% c( .gammaX.N(), .gammaE.N() )
  
  #### Append  
  if ( any(ind) )
  {  
    #### Make
    ind <- .ind.lt0(x = xRet)
    if ( NCOL(ind) == 1 && NCOL(xDep) > 1 )
    {
      ind <- matrix(data = ind, nrow = NROW(xDep), ncol = NCOL(xDep))
    }
    ans <- cbind(ans, xDep * ind)
  }  
  

  ##############################################################################
  ## Part 4: Answer
  ##############################################################################

  list( x = ans, Ex = colMeans(ans, na.rm = TRUE) )
}
# ------------------------------------------------------------------------------
