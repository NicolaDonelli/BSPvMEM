################################################################################
##
## File: MEM-Formulation-dev10.R
##
## Purpose:
##  R functions for handling MEM model formulation.
##
## Created: 2010.04.30
##
## Version: 2017.10.15
##
## Author:
##  Fabrizio Cipollini <cipollini@disia.unifi.it>
##
################################################################################

################################################################################
## PART 0 - FUNCTION:               GLOBAL CONSTANTS:
##  .Machine.constants()            Machine constants or (transformations of
##                                   them)
################################################################################

.Machine.constants <-
function()
{
  ##############################################################################
  ## Description:
  ##  Passes some Machine constant (or transformations of them) to a F77 common
  ##   block.
  ##
  ## Arguments:
  ##  NONE
  ##
  ## Value:
  ##  NONE
  ##############################################################################

  ## FUNCTION:

  #### constants
  deps    <- .Machine$double.eps
  xDouble <- c(
    deps,
    sqrt(deps),
    deps^(1/3),
    .Machine$double.xmax)

  #### F77 call
  .Fortran( "SETMACHINE",
    xDouble = as.double(xDouble),
    PACKAGE = .package())

  #### Answer
  NULL
}
# ------------------------------------------------------------------------------

################################################################################
## PART 1 - FUNCTION:               FUNCTIONS FOR GLOBAL CONSTANTS:
##  .alphaX.N()                     Numeric 'alphaX'.
##  .gammaX.N()                     Numeric 'gammaX'.
##  .betaX.N()                      Numeric 'betaX'.                     
##  .alphaE.N()                     Numeric 'alphaE'.
##  .gammaE.N()                     Numeric 'gammaE'.      
##  .betaE.N()                      Numeric 'betaE'.
##  .sigma.N()                      Numeric 'sigma'.
##
##  .alphaX.C()                     Character 'alphaX'.
##  .gammaX.C()                     Character 'gammaX'.
##  .betaX.C()                      Character 'betaX'.
##  .alphaE.C()                     Character 'alphaE'.
##  .gammaE.C()                     Character 'gammaE'.
##  .betaE.C()                      Character 'betaE'.
##  .sigma.C()                      Character 'sigma'.
##
##  .xi1.N()                        Numeric single 'xi'.
##  .xi1.C()                        Character single 'xi'.        
##  .eta1.N()                       Numeric single 'eta'.
##  .eta1.C()                       Character single 'eta'.
##  .eps1.N()                       Numeric single 'eps'.
##  .eps1.C()                       Character single 'eps'.
##
##  .xi.N()                         Numeric 'xi'.
##  .xi.C()                         Character 'xi'.
##  .eta.N()                        Numeric 'eta'.
##  .eta.C()                        Character 'eta'.
##  .eps.N()                        Numeric 'eps'.
##  .eps.C()                        Character 'eps'.
##
##  .parm.N()                       Numeric parameters.
##  .parm.C()                       Character parameters.
##  .pGroup.N()                     Numeric group.
##  .pGroup.C()                     Character group.
##
##  .pTyp12()                       Numeric: type 1/2 parameters.
##  .algr.C()                       Character algorithm.
##  .algr.N()                       Numeric algorithm.
##
################################################################################


################################################################################
## Parameters as numeric
################################################################################

.psi.N    <- function() {   1 }
# ------------------------------------------------------------------------------

.mu.N     <- function() {  11 }
# ------------------------------------------------------------------------------

.delta.N  <- function() {  12 }
# ------------------------------------------------------------------------------

.omegaE.N <- function() {  21 }
# ------------------------------------------------------------------------------

.betaE.N  <- function() {  23 }
# ------------------------------------------------------------------------------

.alphaE.N <- function() {  25 }
# ------------------------------------------------------------------------------

.gammaE.N <- function() {  27 }
# ------------------------------------------------------------------------------

.omegaX.N <- function() {  31 }
# ------------------------------------------------------------------------------

.betaX.N  <- function() {  33 }
# ------------------------------------------------------------------------------

.alphaX.N <- function() {  35 }
# ------------------------------------------------------------------------------

.gammaX.N <- function() {  37 }
# ------------------------------------------------------------------------------

.sigma.N  <- function() { 101 }
# ------------------------------------------------------------------------------


################################################################################
## Parameters as character
################################################################################

.psi.C    <- function() { "psi" }
# ------------------------------------------------------------------------------

.mu.C     <- function() { "mu" }
# ------------------------------------------------------------------------------

.delta.C  <- function() { "delta" }
# ------------------------------------------------------------------------------

.omegaE.C <- function() { "omegaE" }
# ------------------------------------------------------------------------------

.betaE.C  <- function() { "betaE" }
# ------------------------------------------------------------------------------

.alphaE.C <- function() { "alphaE" }
# ------------------------------------------------------------------------------

.gammaE.C <- function() { "gammaE" }
# ------------------------------------------------------------------------------

.omegaX.C <- function() { "omegaX" }
# ------------------------------------------------------------------------------

.betaX.C  <- function() { "betaX" }
# ------------------------------------------------------------------------------

.alphaX.C <- function() { "alphaX" }
# ------------------------------------------------------------------------------

.gammaX.C <- function() { "gammaX" }
# ------------------------------------------------------------------------------

.sigma.C  <- function() { "sigma" }
# ------------------------------------------------------------------------------


################################################################################
## Group id's
################################################################################

.psi1.N  <- function() { .psi.N() }
# ------------------------------------------------------------------------------

.psi1.C  <- function() { "psi" }
# ------------------------------------------------------------------------------

.mu1.N  <- function() { .mu.N() }
# ------------------------------------------------------------------------------

.mu1.C  <- function() { "mu" }
# ------------------------------------------------------------------------------

.eta1.N  <- function() { .omegaE.N() }
# ------------------------------------------------------------------------------

.eta1.C  <- function() { "eta" }
# ------------------------------------------------------------------------------

.xi1.N  <- function() { .omegaX.N() }
# ------------------------------------------------------------------------------

.xi1.C  <- function() { "xi" }
# ------------------------------------------------------------------------------

.eps1.N  <- function() { .sigma.N() }
# ------------------------------------------------------------------------------

.eps1.C  <- function() { "eps" }
# ------------------------------------------------------------------------------


################################################################################
## Groups
################################################################################

#### Legend:
#### X0 includes parameters not associated to variables
#### X1 includes parameters associated to exogenous variables
#### X2 includes parameters associated to endogenous variables
#### X3 includes parameters associated to the distribution of residuals

.X0.N <- function()
{
  c( .psi.N() )
}
# ------------------------------------------------------------------------------

.X0.C <- function()
{
  c( .psi.C() )
}
# ------------------------------------------------------------------------------

.X1.N <- function()
{
  c( .mu.N(), .delta.N() )
}
# ------------------------------------------------------------------------------

.X1.C <- function()
{
  c( .mu.C(), .delta.C() )
}
# ------------------------------------------------------------------------------

.eta.N <- function()
{
  c( .alphaE.N(), .gammaE.N(), .betaE.N() )
}
# ------------------------------------------------------------------------------

.eta.C <- function()
{
  c( .alphaE.C(), .gammaE.C(), .betaE.C() )
}
# ------------------------------------------------------------------------------

.xi.N <- function()
{
  c( .alphaX.N(), .gammaX.N(), .betaX.N() )
}
# ------------------------------------------------------------------------------

.xi.C <- function()
{
  c( .alphaX.C(), .gammaX.C(), .betaX.C() )
}
# ------------------------------------------------------------------------------

.eps.N <- function()
{
  c( .sigma.N() )
}
# ------------------------------------------------------------------------------

.eps.C <- function()
{
  c( .sigma.C() )
}
# ------------------------------------------------------------------------------

.ar.N <- function()
{
  c(.betaE.N(), .betaX.N())
}
# ------------------------------------------------------------------------------

.err.N <- function()
{
  c( .alphaE.N(), .gammaE.N(), .alphaX.N(), .gammaX.N() )
}
# ------------------------------------------------------------------------------

.X2.N <- function()
{
  c( .eta.N(), .xi.N() )
}
# ------------------------------------------------------------------------------

.X2.C <- function()
{
  c( .eta.C(), .xi.C() )
}
# ------------------------------------------------------------------------------

.X3.N <- function()
{
  c( .eps.N() )
}
# ------------------------------------------------------------------------------

.X3.C <- function()
{
  c( .eps.C() )
}
# ------------------------------------------------------------------------------

.parm.N <- function()
{  
  c( .X0.N(), .X1.N(), .X2.N(), .X3.N() )
}
# ------------------------------------------------------------------------------

.parm.C <- function()
{
  c( .X0.C(), .X1.C(), .X2.C(), .X3.C() )
}
# ------------------------------------------------------------------------------

.noIter.N <- function()
{
  c(.sigma.N())
}
# ------------------------------------------------------------------------------

.iter.N <- function()
{
  x <- .parm.N()
  x[ !(x %in% .noIter.N()) ]
}
# ------------------------------------------------------------------------------

.noFilter.N <- function()
{
  c(.sigma.N())
}
# ------------------------------------------------------------------------------

.filter.N <- function()
{
  x <- .parm.N()
  x[ !(x %in% .noFilter.N()) ]
}
# ------------------------------------------------------------------------------


################################################################################
## p
################################################################################

.pGroup.N <- function() 
{ 
  c( rep.int(.psi1.N() , NROW(.X0.N())  ), 
     rep.int(.mu1.N()  , NROW(.X1.N())  ), 
     rep.int(.eta1.N() , NROW(.eta.N()) ), 
     rep.int(.xi1.N()  , NROW(.xi.N())  ), 
     rep.int(.eps1.N() , NROW(.eps.N())))
}
# ------------------------------------------------------------------------------

.pGroup.C <- function() 
{ 
  c( rep.int(.psi1.C() , NROW(.X0.C())  ), 
     rep.int(.mu1.C()  , NROW(.X1.C())  ), 
     rep.int(.eta1.C() , NROW(.eta.C()) ), 
     rep.int(.xi1.C()  , NROW(.xi.C())  ), 
     rep.int(.eps1.C() , NROW(.eps.C())))
}
# ------------------------------------------------------------------------------


.pType0123 <- function()
{
  ##############################################################################
  ## Description:
  ##  Group variables into X0 X1 (code 1), X2 (code 2) and other (code 3).
  ##  Group variables into X1 (code 1), X2 (code 2) and other (code 3).
  ##
  ## Remarks:
  ##  X0 is for...; X1 is for EXO and ENDO vars; X2 is for AR and ERR vars; 
  ##  X3 is for the remaining. 
  ##############################################################################

  #### Settings
  X0 <- .X0.N()
  X1 <- .X1.N()
  X2 <- .X2.N()
  X3 <- .X3.N()                                                                                                                     
  x  <- c(X0, X1, X2, X3)
  
  #### Make
  ans <- x
  ans <- replace(x = ans, list = x %in% X0, values = 0)
  ans <- replace(x = ans, list = x %in% X1, values = 1)
  ans <- replace(x = ans, list = x %in% X2, values = 2)
  ans <- replace(x = ans, list = x %in% X3, values = 3)

  #### Answer
  ans
}
# ------------------------------------------------------------------------------


.pOrd12 <- function()
{
  ##############################################################################
  ## Description:
  ##  Ordering of X1 and X2 parameters (variables).
  ##
  ## Remarks:
  ##  1. X1 is for EXO and ENDO vars; X2 is for AR and ERR vars. 
  ##  2. The order into .parm.N() is followed.
  ##  3. The order of X1 and X2 parameters is included in the same file but 
  ##     they have to be considered separately.
  ##############################################################################

  ## FUNCTION
  
  #### Settings
  x <- c(   
       .psi.N(), 1,
        .mu.N(), 1,
     .delta.N(), 2,
    .alphaE.N(), 5, 
    .gammaE.N(), 7, 
     .betaE.N(), 1,
    .alphaX.N(), 5,
    .gammaX.N(), 7, 
     .betaX.N(), 2,
     .sigma.N(), 1 )
  x <- matrix(data = x, ncol = 2, byrow = TRUE)
  lev <- x[, 1]
  lab <- x[, 2]
  
  ####
  .factor(x = .parm.N(), levels = lev, labels = lab, typeNum = TRUE)
}
# ------------------------------------------------------------------------------


################################################################################
## Estimation Algorithms
################################################################################

.default.algorithmControl <-
function()
{
  ##############################################################################
  ## Description:
  ##  Default parameters for controlling the estimation algorithms.
  ##
  ## Arguments:
  ##  NONE
  ##
  ## Value: 
  ##  (data.frame) with columns:
  ##   "algr": (character) algorithm name.
  ##   "name": (character) parameter name.
  ##   "type": (character) parameter type: "int" for integer, "real" for real.
  ##   "value": (numeric) parameter value.
  ##############################################################################

  ## FUNCTION:

  ####
  cnames <- c(
    "algr",     "name", "type",  "default", "min", "max")
  x <- c(
                                                          # NEWUOA
    "newuoa", "IPRNT" , "int" ,          3,     0,     3, # Print specification:                                         
                                                          #  IPRNT = 0: there is no output
                                                          #  IPRNT = 1: there is output only at the return
                                                          #  IPRNT = 2: each new value of RHO is printed, with the 
                                                          #   best vector of variables so far and the corresponding 
                                                          #   value of the objective function
                                                          #  IPRNT = 3: each new value of of F is printed with its 
                                                          #   parameters               
    "newuoa", "MFV"   , "int" ,       1000,     0,   Inf, # Maximum number of function evaluations.
    "newuoa", "RHOBEG", "real",        0.2,     0,   Inf, # Greatest expected change to a variable
    "newuoa", "RHOEND", "real",     1.0e-5,     0,   Inf, # Accuracy required in the final values of the variables
                                                          # -------------------------------------------------------
                                                          # DIFFEVO
    "diffevo", "IPRNT", "int" ,        100,  -Inf,   Inf, # Print specification:                                         
                                                          #  IPRNT < 0: there is no output.
                                                          #  IPRNT = 0: there is output only at the return.
                                                          #  IPRNT > 0: output every IPRNT function evaluations.
    "diffevo", "NPOP" , "int" ,        100,     0,   Inf, #  Population size                                         
    "diffevo", "MFV"  , "int" ,       5000,     0,   Inf, # Maximum number of function evaluations.
    "diffevo", "PCROS", "real",        0.9,     0,     1, #  Probability of cross-over [0.85, 0.99].
    "diffevo", "FACT" , "real",        0.7,     0,     1, #  Two scale parameter [0.5, 0.95].
    "diffevo", "FACT1", "real",      0.005,     0,     1, #  Two scale parameter [0.00, 0.01].
    "diffevo", "TOLF" , "real",     0.0001,     0,   Inf, #  Accuracy for termination (on the function value). 
                                                          #   0.0001 is ok; 0.0000001 is often more than enough.
                                                          # -------------------------------------------------------
                                                          # SPG
    "spg"    , "IPRNT", "int" ,         20,  -Inf,   Inf, # Print specification:
                                                          #  IPRNT < 0: there is no output.
                                                          #  IPRNT = 0: there is output only at the return.
                                                          #  IPRNT > 0: output every IPRNT iterations.
    "spg"    , "MIT"  , "int" ,        200,     0,   Inf, # Maximum number of iterations.
    "spg"    , "MFV"  , "int" ,        500,     0,   Inf, # Maximum number of function evaluations.
    "spg"    , "TOLG" , "real",       1e-5,     0,   Inf, # Tolerance for the gradient                                                            
                                                          # -------------------------------------------------------
                                                          # LEVENBERG-MARQUARDT
    "levmar" , "IPRNT", "int" ,         20,  -Inf,   Inf, # Print specification:
                                                          #  IPRNT < 0: there is no output.
                                                          #  IPRNT = 0: there is output only at the return.
                                                          #  IPRNT > 0: output every IPRNT iterations.
    "levmar" , "MIT"  , "int" ,        200,     0,   Inf, # Maximum number of iterations.
    "levmar" , "TOLG" , "real",       1e-7,     0,   Inf, # Tolerance for the gradient
    "levmar" , "TAU"  , "real",       1e-3,     0,   Inf, # Multiplier for computing the starting MU 
    "levmar" , "RHO1" , "real",        0.2,     0,     1, # Left limit for the max level of the multiplicator of MU
    "levmar" , "RHO2" , "real",        0.8,     0,     1, # Right limit for the min level of the multiplicator of MU
    "levmar" , "ML1"  , "real",        2.0,     0,   Inf, # Max level of the multiplicator of MU
    "levmar" , "ML2"  , "real",       0.33,     0,   Inf, # Min level of the multiplicator of MU    
                                                          # -------------------------------------------------------
                                                          # POWELL DOG LEG
    "dogleg" , "IPRNT", "int" ,         20,  -Inf,   Inf, # Print specification:
                                                          #  IPRNT < 0: there is no output.
                                                          #  IPRNT = 0: there is output only at the return.
                                                          #  IPRNT > 0: output every IPRNT iterations.
    "dogleg" , "MIT"  , "int" ,        200,     0,   Inf, # Maximum number of iterations.
    "dogleg" , "TOLG" , "real",       1e-7,     0,   Inf, # Tolerance for the gradient
    "dogleg" , "DELTA", "real",        1.0,     0,   Inf, # Starting radius
    "dogleg" , "RHO1" , "real",        0.2,  -Inf,   Inf, # Left limit for the max level of the multiplicator of DELTA
    "dogleg" , "RHO2" , "real",        0.8,  -Inf,   Inf, # Right limit for the min level of the multiplicator of DELTA
    "dogleg" , "ML1"  , "real",       0.33,     0,   Inf, # Min level of the multiplicator of DELTA
    "dogleg" , "ML2"  , "real",       2.00,     0,   Inf, # Max level of the multiplicator of DELTA    
                                                          # -------------------------------------------------------
                                                          # NEWTON
    "newton" , "IPRNT", "int" ,         20,  -Inf,   Inf, # Print specification:
                                                          #  IPRNT < 0: there is no output.
                                                          #  IPRNT = 0: there is output only at the return.
                                                          #  IPRNT > 0: output every IPRNT iterations.
    "newton" , "MIT"  , "int" ,        200,     0,   Inf, # Maximum number of iterations.
    "newton" , "TOLG" , "real",       1e-7,     0,   Inf) # Tolerance for the gradient                                                            
  
  #### Adjust to a data.frame 
  x <- matrix(data = x, ncol = NROW(cnames), byrow = TRUE)
  x1 <- x[1, ] ## Store for the automatic distinction numeric/character below
  x <- as.data.frame(x)                         
  colnames(x) <- cnames
  
  #### Adjust column types
  warn <- options()$warn
  options(warn = -1)
  ind <- !is.na( as.numeric(x1) )
  options(warn = warn)
  # ind <- 4 : 6 ## This setting replaces the automatic distinction numeric/character
  x[, ind] <- apply(X = x[, ind], MARGIN = 2, FUN = as.numeric)  
  
  #### Add algr numeric code
  lev <- unique(x[, "algr"])
  lab <- 1 : NROW(lev)
  x1 <- .factor(x = x[, "algr"], levels = lev, labels = lab, typeNum = TRUE)
  x <- data.frame(algrN = x1, x)
  
  #### Answer
  x
}
#-------------------------------------------------------------------------------


################################################################################
## PART 2 - FUNCTION:               UTILITY FUNCTIONS FOR PARAMETERS:
##  .convert.parm()                  Converts 'parm'.
################################################################################

.convert.parm <-
function(x, type = c("parm", "group", "type12", "ord12"))
{
  ##############################################################################
  ## Description:
  ##  Converts 'parm'.
  ##
  ## Arguments:
  ##  Z: (vector) 'parm' as codes (if numeric) or names (if character).
  ##  typeParm: (logical) convert to parm if TRUE, to group if FALSE.
  ##
  ## Value:
  ##  (vector) converted values.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  type <- substr(x = type[1], start = 1, stop = 1)

  #### Check
  if (is.numeric(x))
  {
    parmFrom  <- .parm.N()
    
    if (type == "p")
    {
      parmTo <- .parm.C()
    }
    else if (type == "g")
    {
      parmTo <- .pGroup.N()
    }
    else if (type == "t")
    {
      parmTo <- .pType0123()
    }
    else if (type == "o")
    {
      parmTo <- .pOrd12()
    }
    else
    {
      stop("Wrong 'type' argument")
    }

  }
  else if (is.character(x))
  {
    parmFrom  <- .parm.C()

    if (type == "p")
    {
      parmTo <- .parm.N()
    }
    else if (type == "g")
    {
      parmTo <- .pGroup.C()
    }
    else if (type == "t")
    {
      parmTo <- .pType0123()
    }
    else if (type == "o")
    {
      parmTo <- .pOrd12()
    }
    else
    {
      stop("Wrong 'type' argument")
    }

  }
  else
  {
    stop("Argument 'x' must be numeric or character.")
  }

  #### Convert
  .factor(x = x, levels = parmFrom, labels = parmTo, 
    typeNum = is.numeric(parmTo))
}
# ------------------------------------------------------------------------------


################################################################################
## PART 3 - FUNCTION:               MODEL FORMULATION:
##  .neqn()                          Compute the number of equations from 'eqn'.
##  .extract.model()                 Extract model formulation from the original 
##                                    'model' input.
##  .check.model()                   Check model formulation.
################################################################################

.extract.model <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Extract model formulation from a the original 'model' input.
  ##
  ## Arguments:
  ##  x: (vector or data.frame) with, at most, 2 columns:
  ##  - x[,1] or x[,"parm"] includes 'model' formulation. Elements of x[, 1] 
  ##    have structure "parm[i,j,l]" where
  ##    'parm' is one of the proper parameter names
  ##    'i' means the output equation
  ##    'j' means the input equation
  ##    'l' means the lag
  ##    One or more among i, j, l can be missing.
  ##    Symbols '[', ']', ',' can be replaced by any punctuation character.
  ##  - x[,2] or x[,"start"] (if provided) includes starting values.
  ##  - x[,3] or x[,"left"] (if provided) includes left bounds.
  ##  - x[,4] or x[,"right"] (if provided) includes right bounds.
  ##  Columns 3-4 (or "left", "right") are used only by the DIFFEVO algorithm.
  ##  Columns 2-4 (or "start", "left", "right") can be missing.
  ##
  ## Value:
  ##  (matrix) representing 'model' formulation with columns:
  ##   'parm': parameter code.
  ##   'eqn': output equation.
  ##   'from': input equation.
  ##   'lag': lag.
  ##   'start': starting values.
  ##   'left': left bounds.
  ##   'right': right bounds.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Add colnames if missing, check colnames
  ##############################################################################

  #### If NCOL(x) == 0
  if (NCOL(x) == 0)
  {
     stop("Not enough information for building a model formulation")
  }
  
  #### If NCOL(x) == 1
  else if (NCOL(x) == 1)
  {
    x <- data.frame(parm = x, start = NA, stringsAsFactors = FALSE)
  }

  #### proper colnames
  proper  <- c("parm", "start", "left", "right")

  #### If colnames are missing store them
  if (is.null(colnames(x)))
  {
     colnames(x) <- proper[1:NCOL(x)]
  }

  #### Remove not proper colnames
  ind  <- colnames(x) %in% proper
  if ( !all(ind) )
  {
     out <- paste("'", colnames(x)[!ind], "'", sep = "")
     warning("The following columns of 'model' are unfeasible: ", out,
       "they have been removed")
     x <- x[, ind, drop = FALSE]
  }

  #### Remove duplicated colnames
  ind <- duplicated(colnames(x))
  if ( any(ind) )
  {
     x  <- x[, !ind, drop = FALSE]
  }
  
  
  ##############################################################################
  ## Part 2: Select
  ##############################################################################

  #### If NCOL(x) == 0
  if (NCOL(x) == 0)
  {
     stop("Not enough information for building a model formulation")
  }

  #### If NCOL(x) > 0
  if (NCOL(x) == 1)
  {
    x1     <- x
    startx <- NA
  }
  else
  {
    #### Colnames
    cnames <- colnames(x)
    
    #### 'parm'
    if ("parm" %in% cnames)
    {
      x1 <- x[,"parm"]
    }
    else
    {
      stop("Not enough information for building a model formulation")
    }

    #### 'start'
    startx <- NA
    if ("start" %in% cnames)
    {
      startx <- as.numeric( x[,"start"] )
    }

    #### 'left'
    leftx <- NA
    if ("left" %in% cnames)
    {
      leftx <- as.numeric( x[,"left"] )
    }

    #### 'right'
    rightx <- NA
    if ("left" %in% cnames)
    {
      rightx <- as.numeric( x[,"right"] )
    }
  }

  
  ##############################################################################
  ## Part 3: Split information included into the string 'parm[i,j,l]'    
  ##############################################################################

  #### Split
  ## Remove blanks
  x1 <- gsub(pattern = "[[:blank:]]", replacement = "", x = x1)
  ## Split
  x1 <- strsplit(x = x1, split = "[[:punct:]]")

  #### Append starting values
  x1 <- mapply(FUN = c, x1, as.list(startx), as.list(leftx), as.list(rightx), 
    SIMPLIFY = FALSE)
   
  #### Adjust parameters
  x1 <- .parm.adjust(x = x1)

  #### Numeric codes of parameters
  x1[, "parm"] <- .convert.parm(x = x1[, "parm"], type = "parm")

  #### Compose
  cnames1 <- colnames(x1)
  x1 <- matrix(data = as.numeric(x1), ncol = NCOL(x1))
  colnames(x1) <- cnames1


  ##############################################################################
  ## Part 4: Answer
  ##############################################################################

  #### Answer
  x1
}


.parm.adjust <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Extract parameter info for parameters given in the form 
  ##  'parm[eqn, from, lag]'. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (data.frame) with columns 'parm', 'eqn', 'from', 'lag'.
  ##    
  ## Remarks: 
  ##  This is an auxiliary function of .extract.model().
  ##############################################################################

  ## FUNCTION

  #### Answer
  rbind( 
    .parm.adjust.1(x = x, parms = c(.mu.C(), .psi.C()), 
      cols = "eqn"), 
    .parm.adjust.1(x = x, parms = c(.delta.C(), .sigma.C()), 
      cols = c("eqn", "from")),
    .parm.adjust.1(x = x, parms = .betaE.C(), 
      cols = "lag"),
    .parm.adjust.1(x = x, parms = c( .alphaE.C(), .gammaE.C() ), 
      cols = c("from", "lag")),
    .parm.adjust.1(x = x, parms = c( .betaX.C(), .alphaX.C(), .gammaX.C() ), 
      cols = c("eqn", "from", "lag")) 
    )
}


.parm.adjust.1 <- 
function(x, parms, cols)
{
  ##############################################################################
  ## Description:
  ##  Extract parameter info for parameters given in the form 
  ##  'parm[eqn, from, lag]'. Only 1 type of parameter is handled.
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##  parms: (numeric) numeric codes of parameters to be adjusted.
  ##  cols: (character) wich columns are meaningful.
  ##
  ## Value:
  ##  (data.frame) with columns 'parm', 'eqn', 'from', 'lag', 'start'.
  ##    
  ## Remarks: 
  ##  This is an auxiliary function of .extract.model().
  ##############################################################################

  ## FUNCTION

  #### Returns immediately if parms is empty
  if ( NROW(parms) == 0)
  {
    return(NULL)
  }
  
  #### Settings
  parmC <- parms
  parmN <- .convert.parm(x = parmC, type = "parm")

  #### Select                  
  ind <- unlist( lapply(X = x, FUN = "[", 1) )
  ind <- ind %in% parmC
  x1  <- x[ind]
  
  #### Answer
  if ( NROW(x1) == 0 )
  {
    NULL
  }
  else 
  {
    #### colnames
    cnames <- c("parm", cols, "start", "left", "right")
  
    #### Number of elements
    ind <- lapply(X = x1, FUN = NROW)
        
    #### Check
    if ( all( ind == NROW(cnames) ) )
    {     
      #### Adjust
      x1 <- do.call(what = rbind, args = x1)
      #### Set colnames
      colnames(x1) <- cnames
      #### Make the whole
      x2 <- cbind(parm = 0, eqn = 0, from = 0, lag = 0, 
        start = NA, left = NA, right = NA)
      x2 <- .rep.mat(x = x2, times = NROW(x1))
      #### Plug into the whole
      x2[, colnames(x1)] <- x1
      ####
      x2
    }
    else
    {
      tmp <- paste("'", parmC, "'", sep = "")
      tmp <- paste(tmp, collapse = ", ")
      stop(tmp, " parameters must be set as 'parm[eqn]'")
    }
  }
}
# ------------------------------------------------------------------------------


.parmName.1 <- 
function(x, parms, cols, ans)
{
  ##############################################################################
  ## Description:
  ##  Make parameter names for parameters in the form 'parm[eqn]'. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (data.frame) with columns parm, eqn, from, lag.
  ##    
  ## Remarks: 
  ##  This is an auxiliary function of .parmName().
  ##############################################################################

  ## FUNCTION
  
  #### Select
  ind <- x[, "parm"] %in% parms
  
  #### Select
  parm <- .convert.parm(x = x[ind, "parm"], type = "parm")
  x <- as.list( x[ind, cols, drop = FALSE] )
  
  #### Adjust 'eqn', 'from', 'lag'
  x <- do.call(what = paste, args = c(x, sep = ","))
  x <- paste(parm, "[", x, "]", sep = "")
  ans[ind] <- x
  
  #### Answer
  ans
}
# ------------------------------------------------------------------------------


.parmName <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Make parameter names for parameters in the form 'parm[eqn,from,lag]'. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (character) labels of kind 'parm[eqn,from,lag]'.
  ##############################################################################

  ## FUNCTION
  
  #### Initialize
  np <- NROW(x)
  x1 <- character(np)
  
  #### eqn
  parmN <- c( .mu.N(), .psi.N() )
  cols <- "eqn"
  x1 <- .parmName.1(x = x, parms = parmN, cols = cols, ans = x1)
  
  #### lag (NONE)
  parmN <- c( .betaE.N() )
  cols <- "lag"
  x1 <- .parmName.1(x = x, parms = parmN, cols = cols, ans = x1)

  #### eqn, from
  parmN <- c( .delta.N(), .sigma.N() )
  cols <- c("eqn", "from")
  x1 <- .parmName.1(x = x, parms = parmN, cols = cols, ans = x1)
  
  #### from, lag
  parmN <- c( .alphaE.N(), .gammaE.N() )
  cols <- c("from", "lag")
  x1 <- .parmName.1(x = x, parms = parmN, cols = cols, ans = x1)

  #### eqn, from, lag
  parmN <- c( .betaX.N(), .alphaX.N(), .gammaX.N() )
  cols <- c("eqn", "from", "lag")
  x1 <- .parmName.1(x = x, parms = parmN, cols = cols, ans = x1)
  
  #### Answer
  x1
}
# ------------------------------------------------------------------------------


.eqnUni <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Equations taken into account in the model.
  ##
  ## Arguments:
  ##  x: (numeric) equations.
  ##
  ## Value:
  ##  (numeric) unique equations.
  ##############################################################################

  ## FUNCTION:
  
  #### Unique
  x <- unique(x)
  
  #### Answer
  sort( x[x > 0] )
}
# ------------------------------------------------------------------------------


.neqn <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Number of equations.
  ##
  ## Arguments:
  ##  x: (numeric) equations.
  ##
  ## Value:
  ##  (numeric) number of equations.
  ##############################################################################

  ## FUNCTION:
  
  #### Answer
  NROW( .eqnUni(x))
}
# ------------------------------------------------------------------------------


.check.model <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Internal check of 'model' formulation. 
  ##
  ## Arguments:
  ##  x: (data.frame) 'model' formulation.
  ##
  ## Value:
  ##  x: (data.frame) checked 'model' formulation.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Only parameters estimated iteratively
  ind <- x[, "parm"] %in% .iter.N()
  x <- x[ind, , drop = FALSE]

  #### Further settings
  x[, "eqn"] <- abs( round(x[, "eqn"]) )
  x[, "from"] <- abs( round(x[, "from"]) )
  x[, "lag"] <- abs( round(x[, "lag"]) )
  eqnUni <- .eqnUni(x = x[, "eqn"])
  neqn <- NROW(eqnUni)

  
  ##############################################################################
  ## Part 2: 'mu' parameters.
  ##############################################################################

  #### Settings
  parm1 <- .mu.N()
    
  #### Remove unfeasible: 'eqn' > 0; 'from', 'lag' == 0
  ind <- x[, "parm"] %in% parm1 & 
    (x[, "eqn"] == 0 | x[, "from"] > 0 | x[, "lag"] > 0) 
  x <- x[!ind, , drop = FALSE]

  #### Add: 'mu' parameters for all equations must be included.
  xNew <- cbind(eqn = eqnUni, from = 0, lag = 0)
  x <- .add.parm(x = x, parm = parm1, xNew = xNew)  

  
  ##############################################################################
  ## Part 3: 'xi' parameters.
  ##############################################################################

  #### Settings
  parm1 <- .xi.N()

  #### Remove unfeasible: 'eqn', 'from', 'lag' > 0
  ind <- x[, "parm"] %in% parm1 & 
    ( x[, "eqn"] == 0 | x[, "from"] == 0 | x[, "lag"] == 0 ) 
  x <- x[!ind, , drop = FALSE]
  
  #### Settings
  parm1 <- .betaX.N() 

  #### 'from' values of 'betaX' parameters must appear into some 'eqn'.
  rows <- which( x[, "parm"] %in% parm1 ) 
  ####  
  if ( NROW(rows) > 0 )
  {
    #### Select
    x1   <- x[rows, , drop = FALSE]
    from <- x1[, "from"]
    
    #### Check and correct
    ind  <- from %in% eqnUni
    if ( !all(ind) )
    {
       warning("Some 'betaX' have 'from' values not in some 'eqn':", "\n", 
         "they have been removed.")
       x <- rbind( x[ -rows, drop = FALSE], x1[ind, , drop = FALSE])
    }
  }
  
  
  ##############################################################################
  ## Part 4: 'psi' and 'eta' parameters.
  ##############################################################################

  #### Settings
  parm1 <- c(.psi.N(), .eta.N()) 

  #### rows
  indEta <- any( x[, "parm"] %in% parm1 ) 
 
  #### 
  if ( indEta )
  {
    ############################################################################
    ## 'psi'
    ############################################################################

    #### Settings
    parm1 <- .psi.N()

    #### Remove unfeasible: 'eqn' > 0; 'from', 'lag' = 0
    ind <- x[, "parm"] %in% parm1 & 
      ( x[, "eqn"] == 0 | x[, "from"] > 0 | x[, "lag"] > 0 ) 
    x <- x[!ind, , drop = FALSE]
    
    #### Add: 'psi' parameters for all equations must be included.
    xNew <- cbind(eqn = eqnUni, from = 0, lag = 0)
    x <- .add.parm(x = x, parm = parm1, xNew = xNew)

    
    ############################################################################
    ## 'eta' parameters
    ############################################################################

    #### Remove unfeasible: 'eqn', 'from' = 0; 'lag' > 0
    ind <- (x[, "parm"] %in% .eta.N() & (x[, "eqn"] > 0 | x[, "lag"] == 0)) |
           (x[, "parm"] %in% .betaE.N() & x[, "from"] > 0)
    x <- x[!ind, , drop = FALSE]

    #### Settings
    parm1 <- .betaE.N()

    #### Add: at least 'betaE[1]' must be included.
    ind <- x[, "parm"] %in% parm1 & x[, "lag"] == 1
    if (!any(ind))
    {
      xNew <- cbind(eqn = 0, from = 0, lag = 1)
      x <- .add.parm(x = x, parm = parm1, xNew = xNew)  
    }
    
    #### Settings
    parm1 <- .alphaE.N()

    #### Add: at least 'alphaE[1:K,1]' must be included.
    ind <- x[, "parm"] %in% parm1
    if (!any(ind))
    {
      xNew <- cbind(eqn = 0, from = 1 : neqn, lag = 1)
      x <- .add.parm(x = x, parm = parm1, xNew = xNew)  
    }  
  }
  

  ##############################################################################
  ## Part 5: Append 'sigma'.
  ##############################################################################
  
  #### Settings
  parm1 <- .sigma.N()

  #### Add: 'mu' parameters for all equations must be included.
  xNew <- cbind(eqn = rep.int(x = eqnUni, times = neqn : 1), 
    from = unlist(mapply(FUN = seq, from = 1 : neqn,  
    MoreArgs = list(to = neqn, by = 1), SIMPLIFY = TRUE, USE.NAMES = FALSE)), 
    lag = 0)
  x <- .add.parm(x = x, parm = parm1, xNew = xNew)  

  
  ##############################################################################
  ## Part 6: Check if there are duplicated rows
  ##############################################################################

  #### Find and remove duplicated rows
  ind  <- colnames(x) %in% c("parm", "eqn", "from", "lag")
  ind  <- duplicated( x[, ind, drop = FALSE] )
  x <- x[!ind, , drop = FALSE]


  ##############################################################################
  ## Part 7: Answer
  ##############################################################################
  
  #### Answer
  x
}
# ------------------------------------------------------------------------------


.add.parm <- 
function(x, parm, xNew)
{
  ## FUNCTION:
  
  #### Colnames of xNew must be "eqn", "from", "lag"
  ind <- !duplicated(colnames(xNew))
  xNew <- xNew[, ind, drop = FALSE]
  usedCols <- c("eqn", "from", "lag")
  xNew <- xNew[, usedCols, drop = FALSE]
  
  #### Settings
  parm <- parm[1]
  start <- NA
  left <- NA
  right <- NA
  
  #### Ind
  ind <- x[, "parm"] %in% parm
  
  #### Adjust: x1 is not empty
  if ( any(ind) )
  {
     #### Append
     x1 <- data.frame(where = "old", x[ind, usedCols, drop = FALSE])
     xNew <- data.frame(where = "new", xNew)

     #### Remove combinations already in the data
     x1 <- merge(x = x1, y = xNew, by = usedCols, all = TRUE, 
        sort = FALSE, suffixes = c(".x",".y"))
     ind <- is.na(x1[, "where.x"])
     ind1 <- !(colnames(x1) %in% c("where.x", "where.y"))
     x1 <- x1[ind, ind1, drop = FALSE]
  }
  else
  {
     #### Select
     x1 <- xNew    
  }
    
  #### Last adjustments
  if ( NROW(x1) > 0 )
  {
    x1 <- cbind(parm = parm, x1, 
      start = start, left = left, right = right)
  }
    
  #### Answer
  rbind(x, x1)
}
# ------------------------------------------------------------------------------


################################################################################
## PART 2 - FUNCTION:               AUXILIARY INFO FOR ESTIMATION:
##  .maxlag.X2()                     Compute 'maxLag' for type 1 (EXO, ENDO) or 
##                                    2 parameters (AR, ERR).
##  .pos()                           Compute 'pos', namely the position within 
##                                    of the vector of variables with which each 
##                                    parameter have to be multiplied.
##  .iaux()                          Extract model formulation from the original 
##                                    'model' input.
################################################################################

.maxlag.X2 <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute the maximum lag for each one of the AR and ERR components of the 
  ##  model.  
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (data.frame) model formulation checked.
  ##
  ## Remarks: 
  ##  1. This function must follow .extract.model().
  ##  2. Only parameters used within the filter are retained.
  ##############################################################################
  
  ## FUNCTION:
  
  #### Store ind(X0)
  ind <- c(.psi.N(), .eta.N())
  indEta <- any( x[, "parm"] %in% ind )
  
  #### Select
  ind <- x[, "parm"] %in% .X2.N()
  x <- x[ind, , drop = FALSE]
  
  #### Largest dimension
  K <- max( x[, "from"] )  
  
  #### Append 'ord12'              
  if ( !("ord12" %in% colnames(x)) )
  {
    x <- data.frame(x, ord12 = .convert.parm(x = x[, "parm"], type = "ord12"))
  }

  #### Single parameters and ord12 into X2
  x1 <- .xi.N()
  if ( indEta )
  {
    x1 <- c( .eta.N(), x1 ) 
  }
  indUniX2  <- .parm.N() %in% x1
  ordUniX2  <- .pOrd12()[indUniX2]
  parmUniX2 <- .parm.N()[indUniX2]
  #### Smallest/Largest 'from' for each ord12 into X2
  ind <- parmUniX2 == .betaE.N()
  minFromUniX2 <- rep.int(x = 1, times = NROW(parmUniX2))
  minFromUniX2[ ind ] <- 0
  maxFromUniX2 <- rep.int(x = K, times = NROW(parmUniX2))
  maxFromUniX2[ ind ] <- 0
  #### All from
  fromAll <- mapply(FUN = seq, from = minFromUniX2, to = maxFromUniX2,  
    MoreArgs = list(by = 1), SIMPLIFY = FALSE)
  #### All parm
  n2 <- sapply(X = fromAll, FUN = NROW) 
  parmAll <- mapply(FUN = rep.int, x = parmUniX2, times = n2, 
    SIMPLIFY = FALSE)
  #### Unlist
  fromAll <- unlist(fromAll)
  parmAll <- unlist(parmAll)
  #### Ord12
  ord12All <- .convert.parm(x = parmAll, type = "ord12")
  #### Pack
  xAll <- data.frame(parm = parmAll, from = fromAll, ord12 = ord12All)
  
  #### Largest lag for all possible combinations (ord12, from) included into the 
  #### data
  x1 <- aggregate(x = x[, "lag", drop = FALSE], 
    by = x[, c("ord12", "from"), drop = FALSE], 
    FUN = max, simplify = TRUE)

  #### Merge in order to be sure that all ord are included
  xAll <- merge(x = xAll, y = x1, by = c("ord12", "from"), all = TRUE, 
    sort = FALSE)
  xAll[is.na(xAll[,"lag"]), "lag"] <- 0
    
  #### Sort
  ind <- order(xAll[, "ord12"], xAll[, "from"])
  xAll <- xAll[ind, , drop = FALSE]

  #### Answer
  xAll
}
# ------------------------------------------------------------------------------


.maxlag.ar <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute the maximum lag for each one of the AR components of the model.  
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (data.frame) model formulation checked.
  ##
  ## Remarks: 
  ##  1. This function must follow .extract.model().
  ##  2. Only parameters used within the filter are retained.
  ##############################################################################
  
  ## FUNCTION:
  
  #### Settings
  parmSel <- .ar.N()
  ind <- .eta.N() %in% x[, "parm"]
  if ( !any(ind) )
  {
    parmSel <- parmSel[ !(parmSel %in% .eta.N()) ]
  }
  neqn <- .neqn( x = x[, "eqn"] )  
  
  #### Select parameters
  ind <- x[, "parm"] %in% parmSel
  x <- x[ind, , drop = FALSE]
   
  #### Compute ord12
  if ( !("ord12" %in% colnames(x)) )
  {
    x <- data.frame(x, ord12 = .convert.parm(x = x[, "parm"], type = "ord12"))
  }

  #### Select useful vars
  x1 <- x[, c("ord12", "from", "lag"), drop = FALSE] 
  
  #### Append possible missing values, in order that all possible combinations 
  #### (ord12, from) are covered
  parm <- parmSel[ parmSel %in% .xi.N()]
  ord12 <- .convert.parm(x = parm, type = "ord12")
  ord12 <- unique( ord12 )
  from <- rep.int(x = 1 : neqn, times = rep.int(NROW(ord12), neqn))
  ord12 <- rep.int(x = ord12, times = neqn)
  x2 <- cbind(ord12 = ord12, from = from, lag = 0)
  x1 <- rbind(x1, x2) 

  #### Compute maxLag
  x1 <- aggregate(x = x1[, "lag", drop = FALSE], 
    by = x1[, c("ord12", "from"), drop = FALSE], 
    FUN = max, simplify = TRUE)    
                                          
  #### Sort
  ind <- order(x1[, "ord12"], x1[, "from"])
  x1[ind, , drop = FALSE] 
}
# ------------------------------------------------------------------------------


.maxlag.err <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute the maximum lag for each one of the AR and ERR components of the 
  ##  model.  
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (data.frame) model formulation checked.
  ##
  ## Remarks: 
  ##  1. This function must follow .extract.model().
  ##  2. Only parameters used within the filter are retained.
  ##############################################################################
  
  ## FUNCTION:
  
  #### Settings
  ## Set useful parameters
  parmSel <- .err.N()
  ind <- .eta.N() %in% x[, "parm"]
  if ( !any(ind) )
  {
    parmSel <- parmSel[ !(parmSel %in% .eta.N()) ]
  }
  ## neqn
  neqn <- .neqn( x = x[, "eqn"] )  
  
  #### Select parameters
  ind <- x[, "parm"] %in% parmSel
  x <- x[ind, , drop = FALSE]
  
  #### Compute ord12
  if ( !("ord12" %in% colnames(x)) )
  {
    x <- data.frame(x, ord12 = .convert.parm(x = x[, "parm"], type = "ord12"))
  }
  
  #### Select useful vars
  x1 <- x[, c("ord12", "from", "lag"), drop = FALSE] 
  
  #### Append possible missing values, in order that all possible combinations 
  #### (ord12, from) are covered
  parm <- .convert.parm(x = parmSel, type = "ord12")
  parm <- unique( parm )
  from <- rep.int(x = 1 : neqn, times = rep.int(NROW(parm), neqn))
  parm <- rep.int(x = parm, times = neqn)
  x2 <- cbind(ord12 = parm, from = from, lag = 0)
  x1 <- rbind(x1, x2) 
  
  #### Compute maxLag
  x1 <- aggregate(x = x1[, "lag", drop = FALSE], 
    by = x1[, c("ord12", "from"), drop = FALSE], 
    FUN = max, simplify = TRUE)    
  
  #### Sort
  ind <- order(x1[, "ord12"], x1[, "from"])     
  x1[ind, , drop = FALSE] 
}
# ------------------------------------------------------------------------------


.pos <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute 'positions', the position, within the variables, of the element 
  ##  against which each parameter must be multiplied. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (numeric) positions.
  ##
  ## Remarks: 
  ##  1. This function must follow .extract.model().
  ##  2. Only parameters used within the filter are retained.
  ##  3. 'pos' for X1 and X2 parameters have a different meaning.
  ##############################################################################

  ## FUNCTION:
  
  #### Initialize
  pos <- rep.int(x = 0, times = NROW(x))
  
  #### Make 'pos' for X1 parameters
  ind <- x[, "parm"] %in% .X1.N()
  pos[ind] <- .pos.X1(x = x[ind, , drop = FALSE])
  
  #### Make 'pos' for X2 parameters
  ind <- x[, "parm"] %in% .X2.N()
  pos[ind] <- .pos.X2(x = x[ind, , drop = FALSE])
  
  #### Answer
  pos
}


.pos.X1 <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute 'positions' (the position, within the variables, of the element 
  ##  against which each parameter must be multiplied) for X1 parameters. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (numeric) positions.
  ##
  ## Remarks: 
  ##  This is an auxiliary function of .pos().
  ##############################################################################

  ## FUNCTION:
  
  #### Check
  if ( !all(x[, "parm"] %in% .X1.N()) )
  {
    stop("Argument 'x' must include only 'X1' parameters")
  }
  
  #### Initialize
  pos <- x[, "from"]
  
  #### Adjust 'from' of 'mu' parms
  ind <- x[, "parm"] == .mu.N()
  indMu <- any(ind)
  if ( indMu )
  {
    pos[ind] <- 1
  }

  #### Adjust 'from' of 'delta' parms
  ind <- x[, "parm"] == .delta.N()
  indDelta <- any(ind)
  if ( indDelta )
  {
    x1  <- x[ind, "from"]
    lev <- sort( unique( x1 ) )
    lab <- 1 : NROW(lev)
    x1  <- .factor(x = x1, levels = lev, labels = lab, typeNum = TRUE)
    pos[ind] <- x1 + indMu
  }
  
  ####
  pos
}


.pos.X2 <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute 'positions' (the position, within the variables, of the element 
  ##  against which each parameter must be multiplied) for X2 parameters. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation.
  ##
  ## Value:
  ##  (numeric) positions.
  ##
  ## Remarks: 
  ##  This is an auxiliary function of .pos().
  ##############################################################################

  ## FUNCTION:
  
  #### Check
  if ( !all(x[, "parm"] %in% .X2.N()) )
  {
    stop("Argument 'x' must include only 'X2' parameters")
  }
  
  #### MaxLag
  x1 <- rbind(.maxlag.ar(x = x), .maxlag.err(x = x))           

  #### Comulate lags 
  cum <- cumsum(x1[, "lag"])
  cum <- c(0, cum[-NROW(cum)])

  #### Make keys
  k1 <- paste("a", x1[, "ord12"], "b", x1[, "from"], sep = "")
  k2 <- paste("a",  x[, "ord12"], "b",  x[, "from"], sep = "")
  cum <- .factor(x = k2, levels = k1, labels = cum, typeNum = TRUE)
  
  ####
  cum + x[, "lag"]
}
# ------------------------------------------------------------------------------


.in.end <-
function(n1)
{
  ##############################################################################
  ## Description:
  ##  Internal function used by '.in.np.Eqn()'. Computes 'in' and 'end' 
  ##  (starting and ending points, respectively) from the dimensions of the 
  ##  components into 'n1'.
  ##
  ## Arguments:
  ##  n1: (numeric) counts
  ##
  ## Value:
  ##  (data.frame) with "in", "end" columns.
  ##############################################################################

  ## FUNCTION:
  
  ####
  n    <- NROW(n1)                                       
  in1  <- cumsum( c(1, n1[-n]) )
  end1 <- in1 + n1 - 1
  
  #### Answer
  cbind("in" = in1, "end" = end1)
}
# ------------------------------------------------------------------------------


.in.np.Eqn <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute 'in0Eqn', 'np0Eqn', 'in1Eqn', 'np1Eqn', 'in2Eqn', 'np2Eqn'. 
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation. Only 'typ12' and 'group' columns are  
  ##   used.                                          
  ##
  ## Value:
  ##  (list) with components:
  ##   in0Eqn: 
  ##   np0Eqn:
  ##   in1Eqn: 
  ##   np1Eqn:
  ##   in2Eqn:
  ##   np2Eqn:
  ##
  ## Remarks:
  ##  Before to apply this function, columns have to be sorted by 'group'.
  ##############################################################################
  
  ## FUNCTION:
  
  #### Select
  x <- data.frame( x[, c("typ12", "eqn"), drop = FALSE] )
  
  #### Tabulate
  x <- as.data.frame( table( x ), stringsAsFactors = FALSE )
  x <- as.matrix( x )
  x <- apply(x, 2, as.numeric)

  #### Remove some combinations
  ind <- ( x[, "typ12"] %in% c(0, 1) ) & x[, "eqn"] == 0
  x <- x[!ind, , drop = FALSE]

  #### Sort
  ind <- order(x[, "typ12"], x[, "eqn"])
  x <- x[ind, , drop = FALSE]
  
  #### Append in/end
  x <- data.frame( x, .in.end(x[,"Freq"]), check.names = FALSE )
  
  #### Separate: 0
  ind <- x[, "typ12"] == 0
  if ( any(ind) )
  {
    in0Eqn <- x[ind, "in"]
    np0Eqn <- x[ind, "Freq"]
  }
  else
  {
    K <- max(x[, "eqn"])
    in0Eqn <- numeric(K)
    np0Eqn <- numeric(K)    
  }

  #### Separate: 1 
  ind <- x[, "typ12"] == 1
  in1Eqn <- x[ind, "in"]
  np1Eqn <- x[ind, "Freq"]
  
  #### Separate: 2 
  ind <- x[, "typ12"] == 2
  in2Eqn <- x[ind, "in"]
  np2Eqn <- x[ind, "Freq"]
  
  #### Answer
  list(in0Eqn = in0Eqn, np0Eqn = np0Eqn,
       in1Eqn = in1Eqn, np1Eqn = np1Eqn,
       in2Eqn = in2Eqn, np2Eqn = np2Eqn)
}
# ------------------------------------------------------------------------------


.in.np.Parm <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Store some integer values useful for F77 routines.
  ##
  ## Arguments:
  ##  x: (data.frame) model formulation. Only the 'parm' column is used.                                          
  ##
  ## Value:
  ##  (numeric) dimension of each kind of parameter.
  ##
  ## Remarks:
  ##  Before to apply this function, columns have to be sorted by 'group'.
  ##############################################################################
  
  ## FUNCTION:
  
  #### Select
  x <- x[, "parm", drop = FALSE]
  
  #### Tabulate
  x1 <- data.frame( table( x ) )
  x <- x1[, "x"]  
  x1[, "x"] <- as.numeric(levels(x))[x]

  #### Adjust colnames
  colnames(x1)[colnames(x1) == "x"] <- "parm"
  colnames(x1)[colnames(x1) == "Freq"] <- "n"
  
  #### Append missing parms
  x <- .filter.N()
  ind <- !( x %in% x1[,"parm"] )
  x <- cbind(parm = x[ind], n = 0)
  x1 <- rbind(x1, x)
  
  #### Sort
  x1 <- x1[ order(x1[, "parm"]), , drop = FALSE] 
  
  #### Append in/end
  x <- cbind( x1, .in.end(x1[,"n"]) )
  colnames(x1)[colnames(x1) == "x"] <- colnames(x)
  
  #### Answer
  list(inParm = x[, "in"], npParm = x[, "n"])
}
# ------------------------------------------------------------------------------


.indIter <-
function(parm, eqn, iterMu, indMod)
{
  ##############################################################################
  ## Description:
  ##  Find iterative parameters.
  ##
  ## Arguments:
  ##  parm: (numeric) parameters.
  ##  eqn: (numeric) equations.
  ##  iterMu: (logical[1]) 'mu' estimated iteratively?
  ##
  ## Value:
  ##  (logical) TRUE for parameters estimated iteratively.
  ##############################################################################
  
  ## FUNCTION:
  
  #### Initialize
  noIter <- .noIter.N()
  
  #### Append 'mu'
  if ( !as.logical(iterMu) )
  {
    noIter <- c(.mu.N(), noIter)
  }

  #### Append 'betaE'
  if ( indMod < 3 )
  {
    noIter <- c(.betaE.N(), noIter)
  }

  #### First setting for indIter
  indIter <- !( parm %in% noIter )

  #### Correct for 'psi(K)' as noIter
  indIter[parm == .psi.N() & eqn == .neqn(x = eqn)] <- FALSE
  
  #### Answer
  indIter
}
# ------------------------------------------------------------------------------


.xInd.n <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute the number of independent variables.
  ##
  ## Arguments:
  ##  x: (data.frame) Model formulation.
  ##
  ## Value:
  ##  (numeric) number of independent variables.
  ##############################################################################
  
  ## FUNCTION:
  
  #### For X1 parameters
  ind <- .convert.parm(x = x[, "parm"], type = "type12") == 1
  x1 <- x[ind, c("parm", "from", "lag"), drop = FALSE]
  ind <- !duplicated( x1 )
  n1 <- sum(ind)
  
  #### For indRet
  ind <- x[, "parm"] %in% c(.gammaE.N(), .gammaX.N())  
  n2 <- ifelse( any( ind ), max(x[,"eqn"]), 0)  

  #### Answer
  n1 + n2
}
# ------------------------------------------------------------------------------


.iaux <-
function(x, iter)
{
  ##############################################################################
  ## Description:
  ##  Make settings useful for F77 routines and other procedures.
  ##
  ## Arguments:
  ##   x: (data.frame) checked 'model' formulation.
  ##   iter: (logical[2]) 'mu'/'betaE' estimated iteratively?
  ##
  ## Value:
  ##  (list) with components:
  ##   $model: (data.frame) Model formulation sorted. 
  ##   $iaux: (list) list (to be unlisted) for F77 routines.
  ##   $iauxW: (list) list for R handling.
  ##
  ## Remarks:
  ##  0. This function must follow '.check.model()'. 
  ##  1. Set of parameter values must be integrated of those estimated 
  ##     non-iteratively.
  ##  2. 'model' columns have to be sorted by "parm" and "lag" on exit.
  ##############################################################################
  
  ## FUNCTION:
  
  ##############################################################################
  ## Part 1: Settings
  ##############################################################################
  
  #### Number of equations
  neqn <- .neqn(x = x[, "eqn"])
  #### iterMu
  iterMu <- as.numeric(iter["mu"])
  #### iterBetaE
  iterBetaE <- as.numeric(iter["betaE"])
  

  ##############################################################################
  ## Part 2: 'eta'?
  ##############################################################################

  #### ind
  ind <- c(.psi.N(), .eta.N())
  indEta <- any( ind %in% x[,"parm"] )

  #### ind
  if (indEta)
  {
     indEta <- ifelse(iterBetaE, 3, 2)
  }
  else
  {
    indEta <- 1
  }
  
  
  ##############################################################################
  ## Part 3: Settings
  ##############################################################################
  
  #### Extract
  parm <- x[, "parm"]
  eqn <- x[, "eqn"]
  
  #### Append
  x <- data.frame(x, 
    group = .convert.parm(x = parm, type = "group"),
    typ12 = .convert.parm(x = parm, type = "type12"), 
    ord12 = .convert.parm(x = parm, type = "ord12"),
    indIter = .indIter(parm = parm, eqn = eqn, iterMu = iterMu, indMod = indEta), 
    indFilter = parm %in% .filter.N())    
    
  #### Sort 
  #### In particular sorting is needed before IN0EQN, NP0EQN, IN1EQN, NP1EQN, 
  #### IN2EQN, NP2EQN. However, it is made at this point in order to perform
  #### both iauxW and iaux settings.
  ind <- order(x[, "group"], x[,"eqn"], x[,"parm"], x[,"from"], x[,"lag"])
  x <- x[ind, , drop = FALSE]
  x <- cbind(prog = 1 : NROW(x), x)

  
  ##############################################################################
  ## Part 5: Compute 'iauxW'
  ##############################################################################
    
  #### iaux for the Whole set
  iauxW <- list( parm = x[, "parm"], eqn = x[, "eqn"], from = x[, "from"], 
    lag = x[, "lag"], iterMu = iterMu, indMod = indEta)

    
  ##############################################################################
  ## Part 6: Compute 'iaux'
  ##############################################################################
 
  #### Only parameters appearing in filter               
  ind <- x[, "indFilter"]
  x <- x[ind, , drop = FALSE]
  
  #### neqn
  neqn <- .neqn(x = x[, "eqn"])
  
  #### niv (xInd includes the variables corresponding to 'mu' (the constant 1) 
  #### and to the 'delta' parameters)
  niv <- .xInd.n(x = x)

  #### 'parmValX': all parms in filtering
  npx <- NROW(x)
  
  #### 'parmVal': parms estimated iteratively
  indIter <- x[,"indIter"]
  posx <- x[indIter, "prog"]
  np  <- NROW(posx)                                                           

  #### 'parmVal1': parms involved in filtering but not estimated iteratively 
  np1 <- npx - np  
  posx1 <- x[!indIter, "prog"]  

  #### 'pos' (for 'parmValX')
  pos <- .pos(x = x)
  x <- data.frame(x, pos = pos)
  
  #### 'maxLag'
  ## AR
  mLagF <- .maxlag.ar(x = x)[, "lag"]
  ## ERR
  mLagE <- .maxlag.err(x = x)[, "lag"]
  
  #### IN0EQN, NP0EQN, IN1EQN, NP1EQN, IN2EQN, NP2EQN
  in.np.Eqn <- .in.np.Eqn(x = x)
  in0Eqn <- in.np.Eqn$in0Eqn
  in1Eqn <- in.np.Eqn$in1Eqn
  in2Eqn <- in.np.Eqn$in2Eqn
  np0Eqn <- in.np.Eqn$np0Eqn
  np1Eqn <- in.np.Eqn$np1Eqn
  np2Eqn <- in.np.Eqn$np2Eqn
   
  #### Answer
  list(
    model = x, 
    iaux = list( 
      neqn = neqn, niv = niv, 
      iterMu = as.numeric(iterMu),
      indMod = indEta,
      np = np, np1 = np1, npx = npx, 
      nF = NROW(mLagF), nE = NROW(mLagE), 
      nLagF = sum(mLagF), nLagE = sum(mLagE),  
      mLagF = mLagF, mLagE = mLagE, 
      in0Eqn = in0Eqn, np0Eqn = np0Eqn, 
      in1Eqn = in1Eqn, np1Eqn = np1Eqn, 
      in2Eqn = in2Eqn, np2Eqn = np2Eqn,
      posx = posx,    ## Positions of     iter parms into parmValX 
      posx1 = posx1,  ## Positions of non-iter parms into parmValX
      parm = x[, "parm"], eqn = x[, "eqn"], from = x[, "from"], lag = x[, "lag"], 
      pos = x[,"pos"]),
    iauxW = iauxW)
}
# ------------------------------------------------------------------------------


.daux <-
function(ExDep, ExInd, fltLag, DfltLag, errLag, DerrLag)
{
  ##############################################################################
  ## Description:
  ##  Store some double precision values useful for F77 routines.
  ##
  ## Arguments:
  ##  ExDep: (numeric) .
  ##  ExInd: (numeric) .
  ##
  ## Value:
  ##  (list) with two components:
  ##   $list: 
  ##   $vector: 
  ##############################################################################
  
  ## FUNCTION:
  
  #### Answer
  list(ExDep = ExDep, ExInd = ExInd, 
    fltLag = fltLag, DfltLag = DfltLag, errLag = errLag, DerrLag = DerrLag)
}
# ------------------------------------------------------------------------------


.model.type <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Retrieve the model type.
  ##
  ## Arguments:
  ##  x: (data.frame)
  ##
  ## Value:
  ##
  ##############################################################################
  
  ## FUNCTION:
  
  #### Settings
  parm <- x[, "parm"]
  eqn <- x[, "eqn"]
  vals <- x[, "start"]
  
  #### MEM or vMEM
  ind <- max(eqn) == 1
  model1 <- ifelse(ind, "MEM", "vMEM")
  
  #### Trend?
  ind <- any(parm %in% .betaE.N())
  trend1 <- ifelse(ind, "moving level", "fixed level") 
  
  #### Stationary trend?
  if (trend1 == "moving level")
  {
    ind <- parm == .betaE.N() & eqn == 1
    ind <- vals[ind]
    ind <- NROW(ind) > 0 && ind == 1
    stat1 <- ifelse(ind, "non stat", "stat") 
  }
  else
  {
    stat1 <- ""
  }
  
  #### Answer
  list(model = model1, trend = trend1, stat = stat1)
}
# ------------------------------------------------------------------------------


################################################################################
## PART 3 - FUNCTION:               ???:
##  .startingValues()
##  .boundValues()
################################################################################

.startingValues <-
function( model, ExDep )
{
  ##############################################################################
  ## Description:
  ##  Computes starting values (if not given).
  ##
  ## Arguments:
  ##  model: (data.frame) model formulation.
  ##  ExDep: (numeric) marginal expectations of dependent variables.
  ##
  ## Value:
  ##  'parmVal' with missing starting values computed.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Model
  parm    <- model[,"parm"]
  parmVal <- model[,"start"]
  eqn     <- model[,"eqn"]
  from    <- model[,"from"]
  lag     <- model[,"lag"]
  indIter <- model[,"indIter"]
  
  #### Number of equations
  neqn <- unique(eqn)
  neqn <- NROW(neqn[neqn > 0])
 
  #### Ind
  indLag1 <- lag == 1

  #### Default
  delta.def  <- 0.00
  betaE.def  <- 0.90
  alphaE.def <- 0.00
  gammaE.def <- 0.00
  alphaX.def <- 0.00
  gammaX.def <- 0.00
  betaX.def  <- ifelse( any(parm %in% .eta.N()), 0.00, 0.70)
  psi.def    <- neqn

  
  ##############################################################################
  ## Part 2: Parameters in the 'xi' equations
  ##############################################################################

  #### ind
  indAX <- parm == .alphaX.N()
  indGX <- parm == .gammaX.N()
  indBX <- parm == .betaX.N()
  indX  <- indAX | indGX | indBX
  indEqnEqFrom <- eqn == from
  
  #### Adjust
  ## alphaX, gammaX, betaX
  ind <- is.na(parmVal) & indLag1 & indEqnEqFrom
  parmVal[indAX & ind] <- alphaX.def
  parmVal[indGX & ind] <- gammaX.def
  parmVal[indBX & ind] <- betaX.def
  ## Set remaining NA with zeros
  ind <- is.na(parmVal) & indX
  parmVal[ind] <- 0
  
  
  ##############################################################################
  ## Part 3: 'mu'
  ##############################################################################

  #### Find
  ind <- parm == .mu.N()

  #### Adjust
  ind <- is.na(parmVal) & ind
  parmVal[ind] <- ExDep[eqn[ind]]


  ##############################################################################
  ## Part 4: 'delta'
  ##############################################################################

  #### Find
  ind <- parm == .delta.N()

  #### Adjust
  ind <- is.na(parmVal) & ind
  parmVal[ind] <- delta.def


  ##############################################################################
  ## Part 4: 'psi'
  ##############################################################################

  #### Find
  ind <- parm == .psi.N()
  
  #### Adjust
  if (any(ind))
  {
    #### Extract
    x1 <- parmVal[ind]
    
    #### Settings
    ind.na <- is.na(x1)
    
    #### Adjust 
    if (any(ind.na))
    {     
      #### Adjust parameters without starting values    
      x1[ind.na] <- (psi.def - sum(x1[!ind.na])) / sum(ind.na)
    }
    
    #### Store by constraining the sum to be = psi.def 
    parmVal[ind] <- x1 * (psi.def / sum(x1))   
  }
    
  
  ##############################################################################
  ## Part 5: 'betaE'
  ##############################################################################

  #### Find
  ind <- parm %in% .betaE.N()
  
  #### Adjust
  if (any(ind))
  {    
    #### Adjust 'betaE[1]'
    ind1 <- is.na(parmVal) & ind & indLag1
    parmVal[ind1] <- ifelse(indIter[ind1], betaE.def, 1)
    
    #### 'betaE[l]': l > 1
    ind1 <- is.na(parmVal) & ind & !indLag1
    parmVal[ind1] <- 0
  }


  ##############################################################################
  ## Part 6: 'eta' parms different from 'betaE'
  ##############################################################################

  #### Adjust
  ind <- is.na(parmVal) & parm %in% .alphaE.N()
  parmVal[ind] <- alphaE.def
  
  ind <- is.na(parmVal) & parm %in% .gammaE.N()
  parmVal[ind] <- gammaE.def
 
  
  ##############################################################################
  ## Part 7: Answer
  ##############################################################################

  ####
  parmVal
}
# ------------------------------------------------------------------------------


.boundValues <-
function( model, ExDep )
{
  ##############################################################################
  ## Description:
  ##  Computes bound values for each parameter. Useful for the DIFFEVO 
  ##  optimization algorithm.
  ##
  ## Arguments:
  ##  model: (data.frame) model formulation.
  ##  ExDep: (numeric) marginal expectations of dependent variables.
  ##
  ## Value:
  ##  
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Default parameter bounds. 
  x <- c(
    .psi.N()   , -0.5,   2.0,
    .mu.N()    ,  0.0, 100.0, 
    .delta.N() ,  0.0,   1.0, 
    .omegaE.N(),  0.0,   1.0,
    .alphaE.N(), -0.2,   1.0,
    .gammaE.N(), -0.2,   1.0,
    .betaE.N() ,  0.0,   1.0,
    .omegaX.N(),  0.0,   1.0,
    .alphaX.N(), -0.2,   1.0, 
    .gammaX.N(), -0.2,   1.0, 
    .betaX.N() ,  0.0,   1.0)
  x <- matrix(data = x, ncol = 3, byrow = TRUE)
  colnames(x) <- c("parm", "left", "right")

  #### Extract
  parm  <- model[, "parm"]
  eqn   <- model[, "eqn"]
  left  <- model[, "left"]
  right <- model[, "right"]

  #### Right bounds for mu parameters are given?
  indMu <- parm == .mu.N() & is.na(right)
  
  
  ##############################################################################
  ## Part 2: First adjustment
  ##############################################################################

  #### Left
  x1 <- left
  ind <- is.na(x1)
  x1[ind] <- .factor(x = parm[ind], 
    levels = x[, "parm"], labels = x[, "left"], typeNum = TRUE)
  left <- x1
  
  #### right
  x1 <- right
  ind <- is.na(x1)
  x1[ind] <- .factor(x = parm[ind], 
    levels = x[, "parm"], labels = x[, "right"], typeNum = TRUE)
  right <- x1
    
  #### 'mu': set right bounds to the double of the sample unconditional average
  ind <- indMu
  if ( any(ind) )
  {
    right[ind] <- 2 * ExDep[eqn[ind]]
  }
  
  
  ##############################################################################
  ## Part 3: Answer
  ##############################################################################

  #### Answer
  cbind(left = left, right = right)
}
# ------------------------------------------------------------------------------


################################################################################
## PART III - FUNCTION:            CONTROL SPECIFICATION:
##  .control()                      Default 'control' on the basis of current
##                                   'control' settings.
##  .make.PARList()                 Compose a list of control parameters before 
##                                   estimation. Useful since the implemented 
##                                   estimation algorithms need to separate 
##                                   integer and real parameters.
################################################################################

.control <-
function(control = NULL, model = NULL)
{
  ##############################################################################
  ## Description:
  ##  MEM: Creates a default 'control' list for model inference on the basis of
  ##  the selected 'control' options.
  ##
  ## Arguments:
  ##  control: (list) 'control' settings.
  ##  model: (data.frame) model settings (used by DIFFEVO only).
  ##
  ## Value:
  ##  (list) with components:
  ##   $method: (character[1]) method. One among "settings", "inference", 
  ##    "g2s".
  ##   $iter: (logical[2]) some parameters are estimated iteratively? It has 
  ##    elements named "mu", "betaE".
  ##   $algr: (data.frame) of control inputs for estimation and inference with 
  ##    the following columns:
  ##    "prog": prog of algorithms used in estimation.
  ##    "algr": algorithm name.
  ##    "name": parameter name. 
  ##    "value": parameter value
  ##    "algrN": algorithm code.
  ##    "type": parameter type.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Settings
  method  <- control$method
  iter    <- control$iter
  algr    <- as.list(control$algr)
  nobs0   <- control$nobs0
  
  #### Default
  nobs0Def <- 10
  iterDef <- c(mu = FALSE, betaE = TRUE)
  algrDef <- .default.algorithmControl()
  
  
  ##############################################################################
  ## Part 2: nobs0
  ##############################################################################

  #### 
  if ( NROW(nobs0) == 0 || round(nobs0[1]) < 1 )
  {
    nobs0 <- nobs0Def
  }


  ##############################################################################
  ## Part 2: Method
  ##############################################################################

  #### 
  method <- substr(x = method[1], start = 1, stop = 1)
  proper <- c("s", "i", "g")
  fullNames <- c("settings", "inference", "g2s")
  
  #### 
  if ( NROW(method) > 0 && method %in% proper)
  {
    method <- fullNames[method == proper] 
  }
  else
  {
    x1 <- paste(paste("'", fullNames, "'", sep = ""), collapse = " or ") 
    stop("'control$method' must be set to ", x1)
  }


  ##############################################################################
  ## Part 3: 'iter'
  ##############################################################################

  #### 'mu'
  ind <- "mu"
  x1 <- iter[ind]
  mu <- ifelse( NROW(x1) == 0, iterDef[ind], x1)
  #### 'betaE'
  ind <- "betaE"
  x1 <- iter[ind]
  betaE <- ifelse( NROW(x1) == 0, iterDef[ind], x1)
  #### Copy back
  iter <- c(mu = mu, betaE = betaE)
  

  ##############################################################################
  ## Part 5: Algorithms
  ##############################################################################

  #### Check if the some algorithm is in the settings: if none, it sets 'dogleg'
  if ( NROW(algr) == 0 || !(names(algr) %in% unique( algrDef[, "algr"])) )
  {
    ####
    # algr <- list(newuoa = NULL, levmar = NULL)
    algr <- list(dogleg = NULL)
  }

  #### Since DIFFEVO does not use starting values, only 1 makes sense
  ind <- which( names(algr) == "diffevo" )
  if ( NROW(ind) > 1 )
  {
    algr <- algr[ -ind[-1] ]
  }

  #### Make a table of settings comparable to algrDef: it has columns 
  #### "prog", "algr", "name", "value"
  x <- NULL
  for ( i in 1 : NROW(algr) )
  {
    #### Select from algr settings
    algr.i <- algr[[i]]
    algrName <- names(algr)[i]
    
    #### Make table for the considered algorithm
    if ( NROW(algr.i) > 0 )
    {
      x1 <- data.frame(algr = algrName, name = names(algr.i), value = algr.i)
    }
    else
    {
      x1 <- data.frame(algr = NA, name = NA, value = NA)[0, , drop = FALSE]
    }
      
    #### Select from algrDef the same algorithm 
    ind <- algrDef[, "algr"] == algrName
    x2 <- algrDef[ ind, , drop = FALSE ]
    
    #### Add prog (for sorting in the right way at the end)
    x2 <- data.frame(prog = 1 : NROW(x2), x2)

    #### Merge    
    x1 <- merge(x = x1, y = x2, by = c("algr", "name"), 
      all = TRUE, suffixes = c("", ".def"), sort = FALSE)

    #### Only parameters with a feasible name
    ind <- !is.na(x1[, "default"])
    x1 <- x1[ind, , drop = FALSE]

    #### Sort
    ind <- order(x1[, "prog"])
    x1 <- x1[ind, , drop = FALSE]
    ind <- colnames(x1) != "prog"
    x1 <- x1[, ind, drop = FALSE]
    
    #### Attach prog
    x1 <- cbind(prog = i, x1)
    
    #### Append
    x <- rbind(x, x1)
  }
  algr <- x
  
  #### Check if values are within the default (min, max) range. If not, correct.
  ind <- is.na(algr[, "value"]) | algr[, "value"] < algr[, "min"] | 
    algr[, "max"] < algr[, "value"] 
  algr[ind, "value"] <- algr[ind, "default"] 
    
  #### Replace NA values
  ind <- is.na(algr[, "value"])
  algr[ind, "value"] <- algr[ind, "default"]
  
  
  ##############################################################################
  ## Part 3: Adjust for DIFFEVO and SPG
  ##############################################################################
  
  #### Find
  algrX <- c("diffevo", "spg") 
  ind <- algrX %in% algr[, "algr"]
  
  #### Adjust
  if ( any(ind) )
  {
    #### Check for 'model'
    if (NROW(model) == 0)
    {
      x1 <- paste(paste("'", toupper(algrX), "'", sep = ""), collapse = ", ")
      stop("Control settings for algorithms", x1, " need 'model'")
    }

    #### 'model' with iter parameters only
    ind <- as.logical(model[, "indIter"])
    model <- model[ind, , drop = FALSE]
    
    #### Parameter bounds
    ## left
    ind1 <- "left"
    x1 <- model[, "parmValLeft"] 
    names(x1) <- paste( toupper(ind1), 1 : NROW(x1), sep = "")
    left <- x1
    ## right
    ind1 <- "right"
    x1 <- model[, "parmValRight"] 
    names(x1) <- paste( toupper(ind1), 1 : NROW(x1), sep = "")
    right <- x1
    ## Append
    x1 <- c(left, right)
    
    #### Select the appropriate algr from data
    ## Select rows
    ind <- algr[, "algr"] %in% algrX
    x <- algr[ind, , drop = FALSE]
    ind <- duplicated(x[, "prog"])
    x <- x[!ind, , drop = FALSE]
    ## Select cols (in order to avoid clashing names)
    ind <- !(colnames(x) %in% c("value", "name")) 
    x <- x[, ind, drop = FALSE] 
    ## Refine
    x[, c("min", "max")] <- NA
    x[, "type"] <- "real"
    
    #### Merge x and x1
    ## Append prog to parameter bounds
    ind <- rep.int(x[, "prog"], rep.int(NROW(x1), NROW(x))) 
    x1 <- data.frame(prog = ind, value = x1, name = names(x1))
    ## Merge
    x <- merge(x = x, y = x1, by = "prog", all = TRUE, sort = FALSE)
    
    #### Append
    algr <- rbind(algr, x)
  }  

 
  ##############################################################################
  ## Part 4: Adjust for LEVMAR
  ##############################################################################
  
  #### Find
  algrX <- "dogleg" 
  ind <- algrX %in% algr[, "algr"]

  #### Adjust
  if ( any(ind) )
  { 
    #### Select
    ind <- algr[, "algr"] == algrX & 
      algr[, "name"] %in% c("RHO1", "RHO2", "ML1", "ML2") 
    x <- algr[ind, , drop = FALSE]
    algr <- algr[!ind, , drop = FALSE]
    
    #### Sort
    ind <- order(x[, "prog"])
    x <- x[ind, , drop = FALSE]
    
    #### Extract
    indRho1 <- which(x[, "name"] == "RHO1")
    indRho2 <- which(x[, "name"] == "RHO2")
    indMl1  <- which(x[, "name"] == "ML1")
    indMl2  <- which(x[, "name"] == "ML2")
    
    #### Extract 
    ind <- c("value", "default", "min", "max")
    rho1 <- x[indRho1, ind, drop = FALSE]
    rho2 <- x[indRho2, ind, drop = FALSE]
    ml1  <- x[indMl1, ind, drop = FALSE]
    ml2  <- x[indMl2, ind, drop = FALSE]
   
    #### Adjust 
    ## rho1 and rho2
    ind <- x[indRho1, "value"] > x[indRho2, "value"]
    if (any(ind))
    {
      ind1 <- indRho1[ind]
      x[ind1, "value"] <- x[ind1, "default"] 
      ind1 <- indRho2[ind]
      x[ind1, "value"] <- x[ind1, "default"]
    }
    ## ml1 and ml2
    ind <- x[indMl1, "value"] > x[indMl2, "value"]
    if (any(ind))
    {
      ind1 <- indMl1[ind]
      x[ind1, "value"] <- x[ind1, "default"] 
      ind1 <- indMl2[ind]
      x[ind1, "value"] <- x[ind1, "default"] 
    }
    
    #### Append
    algr <- rbind(algr, x)
  }  

  
  ##############################################################################
  ## Part 5: Adjust for LEVMAR
  ##############################################################################
  
  #### Find
  algrX <- "levmar" 
  ind <- algrX %in% algr[, "algr"]

  #### Adjust
  if ( any(ind) )
  { 
    #### Select
    ind <- algr[, "algr"] == algrX & 
      algr[, "name"] %in% c("RHO1", "RHO2", "ML1", "ML2") 
    x <- algr[ind, , drop = FALSE]
    algr <- algr[!ind, , drop = FALSE]
    
    #### Sort
    ind <- order(x[, "prog"])
    x <- x[ind, , drop = FALSE]
    
    #### Extract
    indRho1 <- which(x[, "name"] == "RHO1")
    indRho2 <- which(x[, "name"] == "RHO2")
    indMl1  <- which(x[, "name"] == "ML1")
    indMl2  <- which(x[, "name"] == "ML2")
    
    #### Extract 
    ind <- c("value", "default", "min", "max")
    rho1 <- x[indRho1, ind, drop = FALSE]
    rho2 <- x[indRho2, ind, drop = FALSE]
    ml1  <- x[indMl1, ind, drop = FALSE]
    ml2  <- x[indMl2, ind, drop = FALSE]
   
    #### Adjust 
    ## rho1 and rho2
    ind <- x[indRho1, "value"] > x[indRho2, "value"]
    if (any(ind))
    {
      ind1 <- indRho1[ind]
      x[ind1, "value"] <- x[ind1, "default"] 
      ind1 <- indRho2[ind]
      x[ind1, "value"] <- x[ind1, "default"]
    }
    ## ml1 and ml2
    ind <- x[indMl1, "value"] < x[indMl2, "value"]
    if (any(ind))
    {
      ind1 <- indMl1[ind]
      x[ind1, "value"] <- x[ind1, "default"] 
      ind1 <- indMl2[ind]
      x[ind1, "value"] <- x[ind1, "default"] 
    }
    
    #### Append
    algr <- rbind(algr, x)
  }  

  
  ##############################################################################
  ## Part 6: Adjust
  ##############################################################################

  #### Check if there are missing values
  ind <- is.na( algr[, "value"] )
  if ( any(ind) )
  {
    print(algr[ind, , drop = FALSE])
    stop("Missing values in starting values")  
  }
  
  #### Sort 
  ind <- order( algr[, "prog"] )
  algr <- algr[ind, , drop = FALSE]
 
  #### Remove cols
  ind <- !( colnames(algr) %in% c("default", "min", "max") )
  algr <- algr[, ind, drop = FALSE]
  
  
  ##############################################################################
  ## Part 4: Answer
  ##############################################################################

  #### 
  list(nobs0 = nobs0, method = method, iter = iter, algr = algr)
}
# ------------------------------------------------------------------------------


.make.PARList <-
function(control)
{
  ##############################################################################
  ## Description:
  ##  Compose a list of control parameters before estimation. Useful since the 
  ##  implemented estimation algorithms need to separate integer and real 
  ##  parameters.
  ##
  ## Arguments:
  ##  control (list): list of control parameters.
  ##
  ## Value:
  ##  A list with the following components:
  ##   $IPAR (numeric): vector storing integer control parameters
  ##   $RPAR (numeric): vector storing real control parameters
  ##############################################################################

  ## FUNCTION:

  #### Extract
  x <- control$algr
  
  #### Algorithm codes
  ind <- !duplicated( x[, "prog"] )
  ialg <- x[ind, "algrN"]
  names(ialg) <- "algrN"
  
  #### Split
  x <- split(x = x, f = list(type = x[, "type"]))
  
  #### ipar
  ## Values
  x1 <- split(x = x$int[, "value"], f = x$int[, "prog"])
  x2 <- as.list(ialg)
  x1 <- mapply(FUN = c, x2, x1, SIMPLIFY = FALSE, USE.NAMES = FALSE)
  ipar <- unlist(x1, use.names = FALSE)
  ## Names  
  x1 <- split(x = x$int[, "name"], f = x$int[, "prog"])
  x2 <- as.list( names(ialg) )
  x1 <- mapply(FUN = c, x2, x1, SIMPLIFY = FALSE, USE.NAMES = FALSE)
  names(ipar) <- unlist(x1, use.names = FALSE)
  
  #### rpar                                      
  rpar <- x$real[, "value"]
  names(rpar) <- x$real[, "name"]

  #### Answer
  list(IPAR = ipar, RPAR = rpar)
}
# ------------------------------------------------------------------------------


################################################################################
##  
################################################################################

.stat <-
function(parmVal, xDep, xInd, iauxList, dauxList, statType)
{
  ##############################################################################
  ## Description:
  ##  Computes a specified statistics by calling the corresponding F77 routine.
  ##
  ## Arguments:
  ##  parmVal: (numeric) values of parameters.
  ##  xDep: (numeric) dependent variables.              
  ##  xInd (numeric): matrix of independent variables.
  ##  iauxList: (list) integer auxiliary information as List.
  ##  dauxList: (list) double precision auxiliary information as List.
  ##  statType: (character) type of the statistic computed and returned. One
  ##   among:
  ##   "filter": for filtered values of 'eta' and 'xi'
  ##   "residuals": for residuals computed as 'depVar / condMean'
  ##   "sigmaM": for 'sigma', the sd of eps(t)
  ##   "muParm": for 'mu' parameters.
  ##
  ## Value:
  ##  Computed values of the statistic.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Initialize
  ##############################################################################

  #### Dimensions
  nobs <- max( NROW(xDep), NROW(xInd) )

  ####
  statType  <- statType[1]


  ##############################################################################
  ## Part 2: Compute
  ##############################################################################

  if (statType %in% c("sigmaM", "filter", "residuals"))
  {
     #### Filtered values   
     out <- .filter(parmVal = parmVal, xDep = xDep, xInd = xInd, 
       ExDep = dauxList$ExDep, 
       fltLag = dauxList$fltLag, errLag = dauxList$errLag, 
       iauxList = iauxList)$mu

     #### Other cases
     if (statType == "residuals")
     {
       out <- xDep / out
     }
     else if (statType == "sigmaM")
     {
       out <- xDep / out - 1
       out <- crossprod(out) / nobs
     }
     else if (statType == "R2")
     {
       out <- diag( cor(xDep, out) )^2
       out <- crossprod(out) / nobs
     }
  }
  else if (statType == "muParm")
  {
    ####
    out <- .muParm.est(parmVal = parmVal,  
      iauxList = iauxList, dauxList = dauxList)
  }
  else
  {
    stop("Bad 'statType' argument")
  }


  ##############################################################################
  ## Part 3: Answer
  ##############################################################################

  ####
  out
}
# ------------------------------------------------------------------------------


.plot.ts <-
function( x, inference, dates = NULL, main.title = "", fileout = "")
{
  ##############################################################################
  ## Description:
  ##  Plot MEM.
  ##
  ## Arguments:
  ##
  ## Value:
  ##
  ## Implemented by:
  ##   Fabrizio Cipollini
  ##############################################################################

  ## FUNCTION:

  #### Adjust dates
  if (NROW(dates) == 0)
  {
     dates <- 1: NROW(x)
  }
  else if (is.numeric(dates))
  {
     dates <- as.Date(x = as.character(dates), format = "%Y%m%d")
  }
  else if (is.character(dates))
  {
     dates <- as.Date(x = dates, format = "%Y%m%d")
  }
  

  ##############################################################################
  ## Part 2: Plot
  ##############################################################################
  
  #### Plot settigs: 6 windows, remove margins
  par(mfrow = c(3,2), mar = c(2,2,2,1))

  #### Time series and 1-step forecasts
  tmp <- main.title
  plot(x = dates, y = x, type = "p", xlab = "", ylab = "", main = tmp)
  lines(x = dates, y = inference$filter[,"xi"], new = FALSE, col = "red")

  #### Omega component
  tmp <- expression(paste("Estimated ", omega, " component"))
  plot(x = dates, y = inference$filter[,"omega"], type = "l", 
    xlab = "", ylab = "", main = tmp, col = "gray")

  #### Alpha component
  tmp <- expression(paste("Estimated ", alpha, " component"))
  plot(x = dates, y = inference$filter[,"alpha"], type = "l", 
    xlab = "", ylab = "", main = tmp, col = "red")

  #### Gamma component
  tmp <- expression(paste("Estimated ", gamma, " component"))
  plot(x = dates, y = inference$filter[,"gamma"], type = "l", 
    xlab = "", ylab = "", main = tmp, col = "orange")

  #### Beta component
  tmp <- expression(paste("Estimated ", beta, " component"))
  plot(x = dates, y = inference$filter[,"beta"], type = "l", 
    xlab = "", ylab = "", main = tmp, col = "blue")

  #### Answer
  NULL
}
# ------------------------------------------------------------------------------


.portmanteau <-
function(epsMatrix, lagMax, fitdf)
{
  ##############################################################################
  ## Description:
  ##  Computes Portmanteau (Box-Ljang) test from vMEM residuals.
  ##
  ## Arguments:
  ##  epsMatrix: (matrix[nobs,K]) vMEM residuals.
  ##  lagMax: (numeric[1]) maximum lag.
  ##  fitdf: (numeric[1]) number of degrees of freedom to be subtracted if x is 
  ##   a series of residuals.
  ##
  ## Value:
  ##  A matrix with columns
  ##   "lag"
  ##   "stat"
  ##   "df"
  ##   "pvalue"
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Check
  ##############################################################################

  #### Maximum time Horizon for portmanteau test
  lagMax <- round( as.numeric(lagMax[1]) )

  if (lagMax <= 0)
  {
    stop("Argument 'lagMax' have to be a positive integer.")
  }


  ##############################################################################
  ## Part 2: Settings
  ##############################################################################

  ####
  neqn <- NCOL(epsMatrix)
  nobs <- NROW(epsMatrix)


  ##############################################################################
  ## Part 3: Zero mean residuals
  ##############################################################################

  ####
  ## u <- epsMatrix - 1
  
  ####
  if (!is.matrix(epsMatrix))
  {
    epsMatrix <- as.matrix(epsMatrix)
  }
  u <- .A.op.tx(epsMatrix, colMeans(epsMatrix), binOp = "-")


  ##############################################################################
  ## Part 4: Computes P, dfs, pvalues
  ##############################################################################

  #### lags
  lags <- 1:lagMax

  #### Auto-codeviance at lag 0
  C0    <- crossprod(u)
  C0inv <- solve(C0)

  #### Initialize
  P <- numeric(lagMax)

  #### Cycle
  for (i in lags)
  {
    #### Indices
    in1  <- -(1:i)
    end1 <- -((nobs-i+1) : nobs)
    #### Auto-codeviance at lag i
    Ci   <- crossprod(u[in1,], u[end1,])
    #### Statistic
    P[i] <- sum( (C0inv %*% Ci) * (Ci %*% C0inv) ) / (nobs - i)
  }

  ####
  P <- (nobs * (nobs + 2)) * cumsum(P) 
  
  #### dfs
  dfs <- neqn * neqn * lags - fitdf

  #### Adjusts for negative dfs
  ind <- dfs > 0
  lags <- lags[ind]
  P   <- P[ind]
  dfs <- dfs[ind]

  #### p-values
  pvalue <- pchisq(q = P, df = dfs, lower.tail = FALSE)


  ##############################################################################
  ## Part 5: Answer
  ##############################################################################

  ####
  cbind(lag = lags, stat = P, df = dfs, pvalue = pvalue)
}
# ------------------------------------------------------------------------------


################################################################################
## PART III - FUNCTION:            INFERENCE:
################################################################################

.gmmEst <-
function(parmVal, xDep, xInd, iauxList, dauxList, control)
{
  ##############################################################################
  ## Description:
  ##  MEM: Parameter estimation via GMM. 
  ##
  ## Arguments:
  ##  parmVal: (numeric) starting values.
  ##  xDep: (numeric[n]) dependent variable.
  ##  xInd: (matrix[n,k]) independent variables.
  ##  iauxList: (list) integer auxiliary quantities for function evaluation 
  ##   (see .iaux() for details).
  ##  dauxList: (list) real auxiliary quantities for function evaluation 
  ##   (see .daux() for details)
  ##  control: (list) control settings for estimation (see .control() for 
  ##   details).
  ##  
  ## Value:
  ##  (list) Parameter estimates.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################
    
  #### Unlist
  iaux <- unlist(x = iauxList, use.names = FALSE)
  daux <- unlist(x = dauxList, use.names = FALSE)

  #### Estimation Algorithm control
  tmp  <- .make.PARList(control = control)
  ipar <- tmp$IPAR
  nipar <- names(ipar)
  rpar <- tmp$RPAR

  #### Settings
  np   <- NROW(parmVal)
  nobs <- NROW(xDep)
  nip  <- NROW(ipar)
  nrp  <- NROW(rpar)

  
  ##############################################################################
  ## Part 2: Estimation 
  ##############################################################################
  
  #### Trace time
  timeEst <- Sys.time()
 
  #### Estimation
  x1 <- .Fortran( "MEMEST",
    np      = as.integer(np),
    parmVal = as.double(parmVal),
    nobs    = as.integer(nobs),
    xDep    = as.double(xDep),
    xInd    = as.double(xInd),
    iaux    = as.integer(iaux),
    daux    = as.double(daux),
    nip     = as.integer(nip),
    ipar    = as.integer(ipar),
    nrp     = as.integer(nrp),
    rpar    = as.double(rpar),
    PACKAGE = .package())
  
  #### Trace time
  timeEst <- Sys.time() - timeEst

  #### Extract
  ## parmVal
  parmVal <- x1$parmVal
  ## number of iterations
  ipar <- x1$ipar
  names(ipar) <- nipar
  nIter <- if ( "MIT" %in% nipar ) { as.numeric(ipar["MIT"]) } else { NA }
  
  
  ##############################################################################
  ## Part 3: Answer 
  ##############################################################################

  #### Answer
  list(parmVal = parmVal, time = timeEst, nIter = nIter)
}
# ------------------------------------------------------------------------------


################################################################################
## PART III - FUNCTION:            INFERENCE:
##  .inference()                    Default settings for estimation algorithms.
################################################################################

.inference <-
function( parmVal, xDep, xInd, iauxList, dauxList, iauxWList)
{
  ##############################################################################
  ## Description:
  ##  Compose inference after estimation.
  ##
  ## Arguments:
  ##  parmVal: (numeric) values of parameters.
  ##  xDep: (numeric) vector of dependent variables
  ##  xInd: (numeric) matrix of independent variables
  ##  iauxList: (list) integer auxiliary information as list
  ##  dauxList: (list) double precision auxiliary information as list.
  ##
  ## Value:
  ##  time: (numeric) estimation time.
  ##  nobs: 
  ##  np:
  ##  score: (numeric) .
  ##  parmEst: (numeric) estimated parameters.
  ##  seEst: (numeric) s.e. of parameters.
  ##  vcovEst: (numeric) variance matrix of parameters.
  ##  filter:
  ##  pmTest:
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Function evaluations at the estimated parameters. 
  ##############################################################################

  #### Function evaluation
  fgh <- .fgh(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    iauxList = iauxList, dauxList = dauxList)

  #### 'sigma'
  sigmaM <- .stat(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    iauxList = iauxList, dauxList = dauxList, statType = "sigmaM")

  #### 'mu' parameter  
  muParm <- .stat(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    iauxList = iauxList, dauxList = dauxList, statType = "muParm")

  
  ##############################################################################
  ## Part 2: Variance-covariance matrix
  ##############################################################################

  #### Variance-covariance matrix
  vcovEst <- .vcov(parmVal = parmVal, xDep = xDep, xInd = xInd, 
     iauxList = iauxList, dauxList = dauxList)
   

  ##############################################################################
  ## Part 2: Integrate for non-iteratively estimated parameters.
  ##############################################################################

  #### 
  x <- .integrate.nonIter(parmVal = parmVal, g = fgh$g, 
    vcov = vcovEst, muParm = muParm, sigmaM = sigmaM, 
    iauxList = iauxList, iauxWList = iauxWList)

  
  ##############################################################################
  ## Part 3: Answer
  ##############################################################################

  #### Answer
  x
}
# ------------------------------------------------------------------------------


.integrate.nonIter <-
function(parmVal, g, vcov, muParm, sigmaM, iauxList, iauxWList)
{
  ##############################################################################
  ## Description:
  ##  Compose inference after estimation.
  ##
  ## Arguments:
  ##  parmVal: (numeric[npIt]) parameter estimates.
  ##  g: (numeric[npIt]) gradient values at convergence.
  ##  vcov: (matrix[np1, np1]) variance-covariance matrix.
  ##  muParm: 
  ##  sigmaM: (matrix) variance-covariance of the error term.
  ##  iauxList: (list) .
  ##  wauxList: (list) .
  ##
  ## Value:
  ##  (list)
  ##
  ## Remarks:
  ##  np1 = npIt + !iterMu * neqn 
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Model settings  
  ##############################################################################

  #### Settings
  neqn <- .neqn(x = iauxList$eqn)  
  
  #### info
  model <- as.data.frame( iauxList[ c("parm", "eqn", "from", "lag") ] )
  indIter <- .indIter(parm = model[, "parm"], eqn = model[, "eqn"], 
    iterMu = iauxList$iterMu, indMod = iauxList$indMod)
  model <- model[indIter, , drop = FALSE]
  ## Append 'estimates' and 'gradient' since they have the same structure of 
  ## 'indIter'
  model <- data.frame( parmName = .parmName(x = model),  
    est = parmVal, gradient = g)

  #### W info
  modelW <- as.data.frame( iauxWList[ c("parm", "eqn", "from", "lag") ] )
  modelW <- data.frame( prog = 1 : NROW(modelW), 
    parmName = .parmName(x = modelW), modelW, est = NA, gradient = NA )

  #### Check conformability between modelW and model
  progW <- modelW[, "prog"]
  posx  <- iauxList$posx
  posx1 <- iauxList$posx1
  prog  <- c(posx, posx1)
  ind   <- !( progW %in% prog )
  ind   <- any(ind) && min( progW[ind] ) <= max( prog )
  if ( ind )
  {
    stop("'modelW' is not conformable with 'model'")
  }
  
  #### Merge
  ind <- c("parmName", "est", "gradient")
  modelW[posx, ind] <- model


  ##############################################################################
  ## Part 2: vcov matrix
  ##############################################################################

  #### Settings
  npW <- NROW(modelW)
  vcovW <- matrix(data = NA, nrow = npW, ncol = npW)
  
  #### Kind of vcov: in case of ET, vcov includes 'mu' in addition to 'indIter' 
  #### elements
  ## Initialize
  ind1 <- posx
  ## Find positions into 'posx1' corresponding to 'mu' parameters
  if ( !iauxList$iterMu )
  {
    ind <- iauxList$parm[posx1] == .mu.N()
    ind1 <- sort( c(ind1, posx1[ind]) )
  }
  ## Copy      
  vcovW[ind1, ind1] <- vcov
  
    
  ##############################################################################
  ## Part 3a: Insert parameters estimated not iteratively: 'mu'
  ##  (Only estimates since the corresponding vcov elements are already stored)
  ##############################################################################

  #### ind of NA elements in estimated 'mu' parameters
  ind <- modelW[, "parm"] == .mu.N() & is.na( modelW[, "est"] )  
  
  #### Compute
  if ( any(ind) )
  {         
    #### Estimated values
    est <- muParm
    modelW[ind, "est"] <- est
  }
  
  
  ##############################################################################
  ## Part 3b: Insert parameters estimated not iteratively: 'betaE'
  ##  (Only estimates since the corresponding vcov elements are NA)
  ##############################################################################

  #### Settings
  ind <- modelW[, "parm"] == .betaE.N() & is.na(modelW[, "est"]) & 
    iauxList$indMod == 2
  
  #### Compute
  if ( any(ind) )
  { 
    #### Estimated values
    est <- 1
    modelW[ind, "est"] <- est
  }
  

  ##############################################################################
  ## Part 3c: Insert parameters estimated not iteratively: 'psi'
  ##############################################################################

  #### Settings
  ind <- modelW[, "parm"] == .psi.N() & is.na(modelW[, "est"])
  
  #### Compute
  if ( any(ind) )
  { 
    #### Estimated values
    ind1 <- modelW[, "parm"] == .psi.N() & !is.na(modelW[, "est"])
    x <- modelW[ind1, "est"]
    est <- neqn - sum(x)
    modelW[ind, "est"] <- est
    
    #### Estimated vcov elements
    if (neqn > 1)
    {
      A <- cbind( diag(neqn - 1), -1 )
      ind <- modelW[, "parm"] == .psi.N()
      vcovW[ind, ind] <- crossprod(A, vcovW[ind1, ind1]) %*% A    
    }
  }
  
 
  ##############################################################################
  ## Part 3d: Insert parameters estimated not iteratively: 'sigma'
  ##  (Only estimates since the corresponding vcov elements are NA)
  ##############################################################################

  #### Settings
  ind <- modelW[, "parm"] == .sigma.N() & is.na( modelW[, "est"] )
  
  #### Compute
  if ( any(ind) )
  { 
    #### Values
    x <- modelW[ind, , drop = FALSE] 
    
    #### Estimated values
    est <- sigmaM
    ind1 <- as.matrix( modelW[ind, c("eqn", "from"), drop = FALSE] )
    est <- est[ind1]
    modelW[ind, "est"] <- est
  }
  

  ##############################################################################
  ## Part 4: Append columns
  ##############################################################################

  #### Quantities from the estimation algorithm
  parmVal <- modelW[, "est"]
  se <- sqrt( diag( vcovW ) )
  tstat <- parmVal / se
  pvalue <- 2 * (1 - pnorm( abs(tstat) ) )
  modelW <- data.frame( parmName = .parmName(x = modelW),  
    est = parmVal, se = se, tstat = tstat, pvalue = pvalue, 
    gradient = modelW[, "gradient"])
 
   
  ##############################################################################
  ## Part 5: Answer
  ##############################################################################

  #### Answer
  # list(modelW = modelW, vcov = vcovW )
  c( as.list(modelW), list(vcov = vcovW) )
}
# ------------------------------------------------------------------------------


.integrate.nonIter <-
function(parmVal, g, vcov, muParm, sigmaM, iauxList, iauxWList)
{
  ##############################################################################
  ## Description:
  ##  Compose inference after estimation.
  ##
  ## Arguments:
  ##  parmVal: (numeric[npIt]) parameter estimates.
  ##  g: (numeric[npIt]) gradient values at convergence.
  ##  vcov: (matrix[np1, np1]) variance-covariance matrix.
  ##  muParm: 
  ##  sigmaM: (matrix) variance-covariance of the error term.
  ##  iauxList: (list) .
  ##  wauxList: (list) .
  ##
  ## Value:
  ##  (list)
  ##
  ## Remarks:
  ##  np1 = npIt + !iterMu * neqn 
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Model settings  
  ##############################################################################

  #### Settings
  neqn <- .neqn(x = iauxList$eqn)  
  
  #### info
  model <- as.data.frame( iauxList[ c("parm", "eqn", "from", "lag") ] )
  indIter <- .indIter(parm = model[, "parm"], eqn = model[, "eqn"], 
    iterMu = iauxList$iterMu, indMod = iauxList$indMod)
  model <- model[indIter, , drop = FALSE]
  ## Append 'estimates' and 'gradient' since they have the same structure of 
  ## 'indIter'
  model <- data.frame( parmName = .parmName(x = model),  
    est = parmVal, gradient = g)

  #### W info
  modelW <- as.data.frame( iauxWList[ c("parm", "eqn", "from", "lag") ] )
  modelW <- data.frame( prog = 1 : NROW(modelW), 
    parmName = .parmName(x = modelW), modelW, est = NA, gradient = NA )

  #### Check conformability between modelW and model
  progW <- modelW[, "prog"]
  posx  <- iauxList$posx
  posx1 <- iauxList$posx1
  prog  <- c(posx, posx1)
  ind   <- !( progW %in% prog )
  ind   <- any(ind) && min( progW[ind] ) <= max( prog )
  if ( ind )
  {
    stop("'modelW' is not conformable with 'model'")
  }
  
  #### Merge
  ind <- c("parmName", "est", "gradient")
  modelW[posx, ind] <- model


  ##############################################################################
  ## Part 2: vcov matrix
  ##############################################################################

  #### Settings
  npW <- NROW(modelW)
  vcovW <- matrix(data = NA, nrow = npW, ncol = npW)
  
  #### Kind of vcov: in case of ET, vcov includes 'mu' in addition to 'indIter' 
  #### elements
  ## Initialize
  ind1 <- posx
  ## Find positions into 'posx1' corresponding to 'mu' parameters
  if ( !iauxList$iterMu )
  {
    ind <- iauxList$parm[posx1] == .mu.N()
    ind1 <- sort( c(ind1, posx1[ind]) )
  }
  ## Copy      
  vcovW[ind1, ind1] <- vcov
  
    
  ##############################################################################
  ## Part 3a: Insert parameters estimated not iteratively: 'mu'
  ##  (Only estimates since the corresponding vcov elements are already stored)
  ##############################################################################

  #### ind of NA elements in estimated 'mu' parameters
  ind <- modelW[, "parm"] == .mu.N() & is.na( modelW[, "est"] )  
  
  #### Compute
  if ( any(ind) )
  {         
    #### Estimated values
    est <- muParm
    modelW[ind, "est"] <- est
  }
  
  
  ##############################################################################
  ## Part 3b: Insert parameters estimated not iteratively: 'betaE'
  ##  (Only estimates since the corresponding vcov elements are NA)
  ##############################################################################

  #### Settings
  ind <- modelW[, "parm"] == .betaE.N() & is.na(modelW[, "est"]) & 
    iauxList$indMod == 2
  
  #### Compute
  if ( any(ind) )
  { 
    #### Estimated values
    est <- 1
    modelW[ind, "est"] <- est
  }
  

  ##############################################################################
  ## Part 3c: Insert parameters estimated not iteratively: 'psi'
  ##############################################################################

  #### Settings
  ind <- modelW[, "parm"] == .psi.N() & is.na(modelW[, "est"])
  
  #### Compute
  if ( any(ind) )
  { 
    #### Estimated values
    ind1 <- modelW[, "parm"] == .psi.N() & !is.na(modelW[, "est"])
    x <- modelW[ind1, "est"]
    est <- neqn - sum(x)
    modelW[ind, "est"] <- est
    
    #### Estimated vcov elements
    if (neqn > 1)
    {
      A <- cbind( diag(neqn - 1), -1 )
      ind <- modelW[, "parm"] == .psi.N()
      vcovW[ind, ind] <- crossprod(A, vcovW[ind1, ind1]) %*% A    
    }
  }
  
 
  ##############################################################################
  ## Part 3d: Insert parameters estimated not iteratively: 'sigma'
  ##  (Only estimates since the corresponding vcov elements are NA)
  ##############################################################################

  #### Settings
  ind <- modelW[, "parm"] == .sigma.N() & is.na( modelW[, "est"] )
  
  #### Compute
  if ( any(ind) )
  { 
    #### Values
    x <- modelW[ind, , drop = FALSE] 
    
    #### Estimated values
    est <- sigmaM
    ind1 <- as.matrix( modelW[ind, c("eqn", "from"), drop = FALSE] )
    est <- est[ind1]
    modelW[ind, "est"] <- est      
  }
  

  ##############################################################################
  ## Part 4: Append columns
  ##############################################################################

  #### Quantities from the estimation algorithm
  parmVal <- modelW[, "est"]
  se <- sqrt( diag( vcovW ) )
  tstat <- parmVal / se
  pvalue <- 2 * (1 - pnorm( abs(tstat) ) )
  modelW <- data.frame( parmName = .parmName(x = modelW),  
    est = parmVal, se = se, tstat = tstat, pvalue = pvalue, 
    gradient = modelW[, "gradient"])
 
   
  ##############################################################################
  ## Part 5: Answer
  ##############################################################################

  #### Answer
  # list(modelW = modelW, vcov = vcovW )
  c( as.list(modelW), list(vcov = vcovW) )
}
# ------------------------------------------------------------------------------


.gamma.logLik <-
function(sigma, x, mu)
{
  ##############################################################################
  ## Description:
  ##  Compute pseudo-loglik (in the case eps(t) | F(t-1) ~ Gamma(phi,phi)) with
  ##   phi = 1 / gamma^2.
  ##
  ## Arguments:
  ##  sigma: (numeric[1]) standard deviation of residuals.
  ##  x: (numeric[n]) data.
  ##  mu: (numeric[n]) conditional expectation.
  ##
  ## Value:
  ##  (numeric[1]) Log-lik.
  ##############################################################################

  ## FUNCTION:

  #### phi
  phi <- 1 / sigma^2
  
  #### Residuals
  eps <- x / mu
  
  #### logLik
  sum( dgamma(x = eps, shape = phi, rate = phi, log = TRUE) - log(mu) )
}
# ------------------------------------------------------------------------------


.compute.psLogLik <-
function(muFilter, sigma, dfsigma)
{
  ##############################################################################
  ## Description:
  ##  Computes a pseudo loglikelihood value for the GMM estimation approach.
  ##
  ## Arguments:
  ##  muFilter: (matrix) [nobs, K]-matrix of filtered values.
  ##  sigma: (matrix) [K, K]-matrix of covariances of residuals.
  ##  dfsigma: (numeric) degrees of freedoms used form computing 'sigma'.
  ##   Usually, 'dfsigma = nobs' or 'dfsigma = nobs - np'.
  ##
  ## Value:
  ##  (numeric) pseudo-loglik value.
  ##############################################################################

  ## FUNCTION:

  ## Dimensions
  nobs <- NROW(muFilter)
  K    <- NCOL(muFilter)
  
  ## Checks
  if ( NROW(sigma) != NCOL(sigma) )
  {
    stop("Argument 'sigma' must be square")
  }
  if ( NROW(sigma) != K )
  {
    stop("Arguments 'muFilter' and 'sigma' must have the same number of columns")
  }
  if ( !is.matrix(sigma) )
  {
    sigma <- as.matrix(sigma)
  }

  ## Answer
  -0.5 * ( nobs * K * log(2 * pi) +
           nobs * determinant(x = sigma, logarithm = TRUE)$modulus +
           dfsigma * K) - sum( log(muFilter) )
}
# ------------------------------------------------------------------------------


.compute.IC <-
function(lLik, nobs, K, np)
{
  ##############################################################################
  ## Description:
  ##  Computes the values of:
  ##   "AIC" (Akaike)
  ##   "BIC"/"SBC" (Bayesian or Schwartz)
  ##   "HQIC" (Hannan-Quinn)
  ##   "AICc" (Corrected Akaike)
  ##  information criteria.
  ##
  ## Arguments:
  ##  lLik: (numeric) logLik value
  ##  nobs: (numeric) number of observations
  ##  K: (numeric) dimension of the time series
  ##  np: (numeric) number of parameters
  ##
  ## Value:
  ##  Named vector of computed values.
  ##############################################################################

  ## FUNCTION:
  
  #### Adjusting coefficients 
  nobs   <- nobs * K
  nobsM  <- nobs - np - 1
  nobsP  <- nobs - np + 1

  #### Answer
  -2 * lLik +
  c(AIC  = 2 * np,
    HQIC = 2 * log(log(nobs)) * np,
    BIC  = log(nobs) * np,
    AICc = 2 * np * nobs / nobsM,
    KIC  = 3 * np,
    KICc = nobs * ( log(nobs / nobsP) + ( 2 * np + 1 - 2 / nobsP ) / nobsM )
    )
}
# ------------------------------------------------------------------------------


.diagnostics <-
function(parmVal, xDep, xInd, iauxList, dauxList, iauxWList)
{
  ##############################################################################
  ## Description:
  ##  Compute variance-covariance matrix.
  ##
  ## Arguments:
  ##
  ## Value:
  ##  (matrix[n,n]) Variance-covariance matrix.
  ##############################################################################

  ## FUNCTION:

  #### Info
  nobs <- NROW(xDep)
  neqn <- NCOL(xDep)
  npW  <- NROW(iauxWList$parm)
  np   <- NROW(iauxList$posx)
  
  #### Filter
  flt <- .filter(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    ExDep = dauxList$ExDep, fltLag = dauxList$fltLag, errLag = dauxList$errLag, 
    iauxList = iauxList)
  mu <- flt$mu

  #### Filter: variance decomposition
  flt.dec <- .filter.varianceDecomposition(x = flt)$ratio

  #### Residuals
  eps <- xDep / mu
  u <- eps - 1

  #### Sigma
  sigma <- sqrt( crossprod(u) / nobs )  
    
  #### Pseudo-LogLik
  lLik <- .compute.psLogLik(muFilter = mu, sigma = sigma, dfsigma = nobs)
  
  #### Information criteria
  xIC <- .compute.IC(lLik = lLik, nobs = nobs, K = neqn, np = npW)

  #### R^2 by components
  R2 <- diag( cor(xDep, mu) )^2
  
  #### Ljung-Box Statistics
  lagMax <- 100
  # pmTest <- .portmanteau(epsMatrix = eps, lagMax = lagMax, fitdf = 0)
  pmTest <- .portmanteau(epsMatrix = eps, lagMax = lagMax, fitdf = np)

  #### Answer
  list(nobs = nobs, 
    logLik = lLik, IC = xIC, R2 = R2,
    pmTest = pmTest, filterDec = flt.dec, 
    muFilter = mu, residuals = eps)
}
# ------------------------------------------------------------------------------


.print.MEM <-
function(inference, diagnostics, control, added, fileout = "")
{
  ##############################################################################
  ## Description:                                                                                                            
  ##
  ## Arguments:
  ##  inference: 
  ##  diagnostics:
  ##  control:
  ##  added:
  ##  fileout:
  ##
  ## Value:
  ##
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Extract
  ##############################################################################

  #### General info
  nobs <- diagnostics$nobs

  #### Parameters and inference
  parmName <- inference$parmName
  parEst   <- inference$est
  seEst    <- inference$se
  tStat    <- inference$tstat
  pvalue   <- inference$pvalue
  score    <- inference$gradient  
  time     <- added$time
  nIter    <- added$nIter

  #### Estimates
  est <- cbind(
    c("estimate", formatC(x = parEst, format = "f", digits = 8)), 
    c("s.e.",     formatC(x = seEst,  format = "f", digits = 8)), 
    c("t-stat",   formatC(x = tStat,  format = "f", digits = 6)),  
    c("pvalue",   formatC(x = pvalue, format = "f", digits = 8)),  
    c("gradient", formatC(x = score, format = "e", digits = 8)) )
  est <- format(x = est, width = 12, justify = "right")
  x1 <- format(x = c("parameter", parmName), width = 20)
  est <- cbind(x1, est)

  #### Algorithm
  algr <- unique(control$algr[, "algr"])
  #### Number of observations to start the filter
  nobs0 <- control$nobs0
  if (nobs0 > nobs)
  {
    nobs0 <- nobs
  }

  #### Convergence
  conv <- .convergence.gradient(inference = inference, control = control)

  #### Likelikood statistics (average) 
  IC <- c( "log-Likelihood" = diagnostics$logLik, diagnostics$IC)
  IC <- IC / nobs
  #### R^2 statistics
  R2 <- diagnostics$R2

  #### Variance decomposition statistics
  x1 <- do.call(args = diagnostics$filterDec, what = cbind)
  n1 <- NROW(x1)
  x1 <- formatC(x = x1, format = "f", digits = 8)
  ind <- c("V(chi)/V(chi+xi)", "V(xi)/V(chi+xi)", 
    "V(chi)/[V(chi)+V(xi)]", "V(xi)/[V(chi)+V(xi)]")
  x1 <- rbind(ind, x1)
  x1 <- format(x = x1, width = max(nchar(ind) + 1), justify = "right")
  ind <- c( "Series", paste("x[", 1 : n1, "]", sep = "") )
  ind <- format(x = ind, width = max(nchar(ind) + 1), justify = "left")
  x1 <- cbind(ind, x1)
  filterDec <- x1

  #### Portmanteau Statistics
  ##
  pmTest  <- diagnostics$pmTest
  ##
  maxLag  <- max( pmTest[,"lag"] )
  lags    <- c( 5, 10, 15, 20)
  lags    <- c(12, 22, 32)
  ind     <- pmTest[,"lag"] %in% lags
  pmTestSel <- pmTest[ind, , drop = FALSE]
  ##
  alpha   <- 0.05
  pmTestPct <- sum(pmTest[,"pvalue"] < alpha) / NROW(pmTest) * 100

  #### Formatting
  ##
  pmTestSel <- rbind(colnames(pmTestSel), pmTestSel)
  pmTestSel <- format(x = pmTestSel, digits = 6, width = 8, na.encode = TRUE)
  pmTestPct <- format(x = pmTestPct, digits = 2, width = 5, na.encode = TRUE)
  IC      <- rbind(names(IC), IC)
  IC      <- format(x = IC, digits = 6, width = 8, na.encode = TRUE)
  ##
  R2      <- format(x = R2, digits = 4, width = 8, na.encode = TRUE)
  names(R2) <- 1 : NROW(R2)
    
  
  ##############################################################################
  ## Print
  ##############################################################################

  #### 1) 'fileout'
  if (NROW(fileout) == 0)
  {
    fileout <- ""
  }

  #### 2) Print
  cat(file = fileout, append = TRUE, "================================================================================", "\n")
  cat(file = fileout, append = TRUE, "MEM Inference", "\n")
  cat(file = fileout, append = TRUE, "Saved at", format(Sys.time(), "%Y-%m-%d, %H:%M:%S"), "\n")

  cat(file = fileout, append = TRUE, "Estimation method: GMM", "\n")
  cat(file = fileout, append = TRUE, "Estimation algorithm:", algr, "\n")
  cat(file = fileout, append = TRUE, "Number of observation to initialize the filter:", nobs0, "\n")
  cat(file = fileout, append = TRUE, "Estimation time:", as.numeric(time, units = "secs"), "seconds", "\n")
  cat(file = fileout, append = TRUE, "Convergence (gradient):", conv, "\n")
  if ( !is.na(nIter) )
  {
    cat(file = fileout, append = TRUE, "Number of iterations:", as.numeric(nIter), "\n")
  }
  cat(file = fileout, append = TRUE, "Number of observations: ", nobs, "\n")

  cat(file = fileout, append = TRUE, "--------------------------------------------------------------------------------", "\n")
  cat(file = fileout, append = TRUE, "Likelihood statistics (approximated, averages): ", "\n")
  write.table(file = fileout, append = TRUE, x = IC,
       quote = FALSE, sep = " ", na = ".", row.names = FALSE, col.names = FALSE)

  cat(file = fileout, append = TRUE, "Generalized R-squared statistics: ", "\n")
  write.table(file = fileout, append = TRUE, x = t(R2),
       quote = FALSE, sep = " ", na = ".", row.names = FALSE, col.names = FALSE)

  cat(file = fileout, append = TRUE, "--------------------------------------------------------------------------------", "\n")
  cat(file = fileout, append = TRUE, "Ljung-Box Statistics:", "\n")
  write.table(file = fileout, append = TRUE, x = pmTestSel,
    quote = FALSE, sep = " ", na = ".", row.names = FALSE, col.names = FALSE)
#  cat(file = fileout, append = TRUE, "Significant Ljung-Box Statistics (alpha =",
#      alpha, ") in", maxLag, "lags =", pmTestPct, "%", "\n")

  cat(file = fileout, append = TRUE, "--------------------------------------------------------------------------------", "\n")
  cat(file = fileout, append = TRUE, "Filter Decomposition Statistics:", "\n")
  write.table(file = fileout, append = TRUE, x = filterDec,
    quote = FALSE, sep = " ", na = ".", row.names = FALSE, col.names = FALSE)

  cat(file = fileout, append = TRUE, "--------------------------------------------------------------------------------", "\n")
  cat(file = fileout, append = TRUE, "Coefficient Estimates:", "\n")
  write.table(file = fileout, append = TRUE, x = est,
    quote = FALSE, sep = " ", na = ".", row.names = FALSE, col.names = FALSE)
  cat(file = fileout, append = TRUE, "Variance-Covariance matrix estimated via", "sandwich estimator", "\n")
  cat(file = fileout, append = TRUE, "================================================================================", "\n")
  
  ####
  invisible(NULL)
}
# ------------------------------------------------------------------------------


.convergence.gradient <- 
function(inference, control)
{
  #### tolg
  x1  <- control$algr
  tolg <- sqrt( x1$value[ x1$name == "TOLG" ] )  
  #### gradient
  x1 <- inference$gradient
  x1 <- as.numeric( replace(x1, list = is.na(x1), values = 0) )
  #### Answer
  x1 <- 0.5 * sum(x1^2)
  ifelse(x1 <= tolg, 0, x1) 
}
# ------------------------------------------------------------------------------



################################################################################
## PART III - FUNCTION:            F77 CALLS:
##  .fgh()                          .
################################################################################

.fgh <-
function(parmVal, xDep, xInd, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  Computes f (criterion function), g (moment function) and h (information 
  ##  function) of the MEM estimated via GMM.
  ##
  ## Arguments:
  ##  parmVal: (numeric)
  ##  xDep: (matrix[nobs,neqn])
  ##  xInd: (matrix[nobs,niv])
  ##  iauxList: (list)
  ##  dauxList: (list)
  ## 
  ## Value:
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### Settings
  np   <- NROW(parmVal)
  nobs <- NROW(xDep)
  iaux <- unlist(x = iauxList, use.names = FALSE)
  daux <- unlist(x = dauxList, use.names = FALSE)

  
  ##############################################################################
  ## Part 2: Function evaluation 
  ##############################################################################

  #### call
  ans <- .Fortran( "MEMFGH0O1",
    np      = as.integer(np),
    parmVal = as.double(parmVal),
    ff      = double(1),
    gf      = double(np),
    hf      = double(np*np),
    nobs    = as.integer(nobs),
    xDep    = as.double(xDep),
    xInd    = as.double(xInd),
    iaux    = as.integer(iaux), 
    daux    = as.double(daux),
    PACKAGE = .package())

  
  ##############################################################################
  ## Part 3: Adjustments 
  ##############################################################################

  #### Adjust HF
  ans$hf <- .copy.UR.2.LL(x = ans$hf)

  
  ##############################################################################
  ## Part 4: Answer 
  ##############################################################################

  #### Answer
  list(f = ans$ff, g = ans$gf, h = ans$hf)
}
# ------------------------------------------------------------------------------


.residuals <-
function(parmVal, xDep, xInd, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  
  ##
  ## Arguments:
  ##
  ## Value:
  ##  A matr with columns
  ##
  ##############################################################################

  ## FUNCTION:

  #### Filter
  flt <- .filter(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    ExDep = dauxList$ExDep, fltLag = dauxList$fltLag, errLag = dauxList$errLag, 
    iauxList = iauxList)

  #### Answer
  xDep / flt$mu
}
# ------------------------------------------------------------------------------                               


.muParm.est <-
function(parmVal, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  Extract 'mu' estimates.
  ##
  ## Arguments:
  ##  parmVal: (numeric)
  ##  iauxList: (list)
  ##  dauxList: (list)                                                                                                  
  ##
  ## Value:
  ##  (numeric) scalar.
  ##############################################################################

  ## FUNCTION:

  #### Variance targeting?
  ind <- !as.logical(iauxList$iterMu)
  
  #### Extract 
  if ( ind )
  {
    dauxList$ExDep
  }
  else
  {
    parm <- iauxList$parm
    eqn  <- iauxList$eqn
    ind  <- .indIter(parm = parm, eqn = eqn, 
      iterMu = iauxList$iterMu, indMod = iauxList$indMod) 
    parm <- parm[ind]
    parmVal[parm == .mu.N()]
  }
}
# ------------------------------------------------------------------------------


################################################################################
## PART VII- FUNCTION:              CHECK F77:
##  .extract.iaux()                  
################################################################################

.extract.iaux <-
function(iauxList)
{
  ##############################################################################
  ## Description:
  ##
  ## Arguments:
  ##  
  ## Value:
  ##  (numeric) .
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### As vector
  iaux <- unlist(x = iauxList, use.names = FALSE)

  
  ##############################################################################
  ## Part 2: Scalar info 
  ##############################################################################

  #### Scalar info
  iauxS <- .Fortran( "EXIAUX1S",
    iaux    = as.integer(iaux),
    neqn    = integer(1),
    niv     = integer(1),
    iterMu  = integer(1),
    indMod  = integer(1),
    np      = integer(1),
    np1     = integer(1),
    npx     = integer(1),
    nF      = integer(1),
    nE      = integer(1),
    nLagF   = integer(1),
    nLagE   = integer(1),
    PACKAGE = .package())
    
  #### Extract  
  ind <- !(names(iauxS) %in% "iaux") 
  iauxS <- iauxS[ind]
  
    
  ##############################################################################
  ## Part 3: Vector info 
  ##############################################################################

  #### Vector info
  iauxV <- .Fortran( "IAUXCHECK",
    iaux    = as.integer(iaux),
    mLagF   = integer(iauxS$nF),
    mLagE   = integer(iauxS$nE),
    in0Eqn  = integer(iauxS$neqn),
    np0Eqn  = integer(iauxS$neqn),
    in1Eqn  = integer(iauxS$neqn),
    np1Eqn  = integer(iauxS$neqn),
    in2Eqn  = integer(iauxS$nF),
    np2Eqn  = integer(iauxS$nF),
    posx    = integer(iauxS$np),
    posx1   = integer(iauxS$np1),
    parm    = integer(iauxS$npx),
    eqn     = integer(iauxS$npx),
    from    = integer(iauxS$npx),
    lag     = integer(iauxS$npx),
    pos     = integer(iauxS$npx),
    PACKAGE = .package())
   
  #### Extract  
  ind <- !(names(iauxV) %in% "iaux") 
  iauxV <- iauxV[ind]

  
  ##############################################################################
  ## Part 4: Answer 
  ##############################################################################

  #### Answer
  c(iauxS, iauxV)
}
# ------------------------------------------------------------------------------


################################################################################
## PART III - FUNCTION:            FILTERING AND FORECASTS:
################################################################################


##  Should be moved from here because it is needed only in estimation
.D.fltLag.errLag.start <-
function(parmVal, iauxList, xDep, nobs0)
{
  ##############################################################################
  ## Description:
  ##  Initialize lagged filtered values. 
  ##
  ## Arguments:
  ##  parmVal: (numeric[np]) Values of parameters.
  ##  iauxList: (numeric[nx]) Maximum lag for each component.
  ##  
  ## Value:
  ##  (numeric) starting values for lagged filtered values.
  ##
  ## Remarks:
  ##  1. See F77 subroutine FLTLU about the order of the elements into the 
  ##     output.
  ##  2. Checks concerning the length of the elements are omitted.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  neqn <- iauxList$neqn
  np   <- iauxList$np
  nF   <- iauxList$nF
  nE   <- iauxList$nE

  #### Default starting values
  flt  <- numeric(nF)
  dflt <- matrix(0, np, nF) 
  err  <- numeric(nE)
  derr <- matrix(0, np, nE)

  #### Starting values for flt
  if ( 0 < nobs0 && nobs0 < NROW(xDep) )
  {
    #### Auxiliaries
    diff <- colMeans(xDep[1 : nobs0, , drop = FALSE]) - colMeans(xDep)
    
    ####
    if (iauxList$indMod == 1)
    {
      flt <- diff
    }
    else if (iauxList$indMod %in% 2 : 3 && neqn > 1)
    {
      eta0 <- mean(diff)
      ind  <- which( iauxList$parm == .psi.N() )
      psi  <- parmVal[ ind ]
      xi0  <- diff - psi * eta0
      ####
      flt  <- c(eta0, xi0)
      indIter <- .indIter(parm = iauxList$parm, eqn = iauxList$eqn, 
        iterMu = iauxList$iterMu, indMod = iauxList$indMod)
      ind <- which( iauxList$parm[indIter] == .psi.N() )
      ind1 <- 2 : (nF - 1)
      dflt[cbind(ind, ind1)] <- -eta0
      dflt[cbind(ind, nF)] <- eta0
    }
  }

  #### Answer
  list(
    flt = .D.fltLag.start(x = flt, dx = dflt, mLag = iauxList$mLagF),
    err = .D.fltLag.start(x = err, dx = derr, mLag = iauxList$mLagE) )
}
# ------------------------------------------------------------------------------


.fltLag.start <-
function(x, mLag)
{
  ##############################################################################
  ## Description:
  ##  Initialize lagged filtered values. 
  ##
  ## Arguments:
  ##  x: (numeric[nx]) Values for initialization.
  ##  mLag (numeric[nx]) Maximum lag for each component.
  ##  
  ## Value:
  ##  (numeric) starting values for lagged filtered values.
  ##
  ## Remarks:
  ##  1. See F77 subroutine FLTLU about the order of the elements into the 
  ##     output.
  ##  2. Checks concerning the length of the elements are omitted.
  ##############################################################################

  ## FUNCTION:

  #### Settings 
  nx  <- NROW(x)
  nxL <- sum(mLag)

  #### F77 Call
  .Fortran( "FLTLS",
    nx      = as.integer(nx),
    nxL     = as.integer(nxL),
    mLag    = as.integer(mLag),
    x       = as.double(x),
    xL      = double(nxL),
    PACKAGE = .package())$xL  
}
# ------------------------------------------------------------------------------


.D.fltLag.start <-
function(x, dx, mLag)
{
  ##############################################################################
  ## Description:
  ##  Initialize lagged filtered values and their derivative. 
  ##
  ## Arguments:
  ##  x: (numeric[nx]) Values for initialization.
  ##  dx: (matrix[np,nx]) Matrix derivative for initialization.
  ##  mLag (numeric[nx]) Maximum lag for each component.
  ##  
  ## Value:
  ##  (list) with components:
  ##   $xL: starting values for lagged filtered values.
  ##   $dxL: derivative of the starting values for lagged filtered values.
  ##
  ## Remarks:
  ##  1. See F77 subroutine FLTLU about the order of the elements into the 
  ##     output.
  ##  2. Checks concerning the length of the elements are omitted.
  ##############################################################################

  ## FUNCTION:

  #### Settings 
  np  <- NROW(dx)
  nx  <- NCOL(dx)
  nxL <- sum(mLag)

  #### F77 Call
  x1 <- .Fortran( "DFLTLS",
    nx      = as.integer(nx),
    nxL     = as.integer(nxL),
    mLag    = as.integer(mLag),
    x       = as.double(x),
    xL      = double(nxL),
    np      = as.integer(np),
    dx      = as.double(dx),
    dxL     = double(np * nxL),
    PACKAGE = .package())[ c("xL", "dxL") ]
  
  #### Reshape dxL as matrix
  x1$dxL <- matrix(x1$dxL, np, nxL)
  
  #### Answer
  x1
}
# ------------------------------------------------------------------------------


.fltLag.update <-
function(xL, x, mLag)
{
  ##############################################################################
  ## Description:
  ##  Update lagged filtered values. 
  ##
  ## Arguments:
  ##  xL (numeric) past lagged values.
  ##  x: (numeric[nx]) current values.
  ##  mLag (numeric[nx]) maximum lag for each component.
  ##  
  ## Value:
  ##  (numeric) xL updated.
  ##
  ## Remarks:
  ##  1. See F77 subroutine FLTLU about the order of the elements into xL.
  ##  2. Checks concerning the length of the elements are omitted.
  ##############################################################################

  ## FUNCTION:

  #### Settings 
  nxL <- NROW(xL)
  neqn <- NROW(x)
     
  #### F77 Call
  .Fortran( "FLTLU",
    neqn    = as.integer(neqn),
    nxL     = as.integer(nxL),
    mLag    = as.integer(mLag),
    x       = as.double(x),
    xL      = as.double(xL),
    PACKAGE = .package())$xL  
}
# ------------------------------------------------------------------------------


.forecasts <-
function(parmVal, xDep, xRet, xPred, fltLag, errLag,
  tTime, tauMax,  
  iauxList)
{
  ##############################################################################
  ## Description:
  ##  Build out of sample forecasts from the estimated vMEM. Forecasts are made 
  ##  from (tTime + 1) to (tTime + tauMax) using the information set available 
  ##  up to 'tTime' (or up to nobs = NROW(xDep) if tTime > nobs).  
  ##
  ## Arguments:
  ##  parmVal: (numeric) parameter values in the X form.
  ##  xDep: (matrix)
  ##  xInd: (matrix)
  ##  xPred: (matrix)
  ##  fltLag:
  ##  errLag:
  ##  tTime: (numeric[1]) time at which to make forecasts. 
  ##  tauMax: (numeric[1]) largest horizon. 
  ##  iauxList: (list) See .iaux() for details. 
  ##
  ## Value:
  ##  (matrix[tauMax,K]) of forecasts.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### Nobs
  nobs <- NROW(xDep)

  #### Set tTime
  tTime <- round(abs(tTime[1]))
  tTime <- ifelse(tTime >= 1, tTime, 1)
  #### Set tLastIn: Last in-sample time used for making forecasts.  
  tLastIn <- min(tTime, NROW(xDep))
  #### Set and tLastOut = Last out-sample time.  
  tLastOut <- tTime + tauMax

  #### Set tauMax
  tauMax <- round(abs(tauMax[1]))
    
  #### Build variables
  ind <- 1 : tLastIn
  xDept  <- xDep[ind, , drop = FALSE]
  xRett  <- xRet[ind, , drop = FALSE]
  xPredt <- xPred[ind, , drop = FALSE]
  #### Build 'xInd'
  xIndt <- .xInd(iauxList = iauxList, 
    xDep = xDept, xRet = xRett, xPred = xPredt)$x
  xIndt <- as.matrix(xIndt)
  #### Build 'xDep'
  xDept <- .xDep(x = xDept)$x
  xDept <- as.matrix(xDept)    
  #### Colnames
  cnames <- colnames(xDep)  

  #### Dimensions
  neqn <- NCOL(xDept)
  niv  <- NCOL(xIndt)
  np   <- NROW(parmVal)
  nF   <- iauxList$nF
  nE   <- iauxList$nE
  
  #### Initialize
  muMatrix  <- matrix(data = NA, nrow = tLastOut, ncol = neqn)
  fltMatrix <- matrix(data = NA, nrow = tLastOut, ncol = nF)
  colnames(muMatrix) <- cnames

  
  ##############################################################################
  ## Part 2: Filter from 1 to tLastIn = min(tTime, nobs) 
  ##############################################################################

  #### Copy the starting filtered values
  fltLagVec <- fltLag
  errLagVec <- errLag
  
  #### Compute the filtered values
  x1 <- .filterX(parmVal = parmVal, xDep = xDept, xInd = xIndt, 
    fltLag = fltLagVec, errLag = errLagVec, iauxList = iauxList)
   
  #### Store  
  ind <- 1 : tLastIn
  muMatrix[ind, ]  <- x1$muMatrix
  fltMatrix[ind, ] <- x1$fltMatrix
    
    
  ##############################################################################
  ## Part 3: Forecast from tLastIn = min(tTime, nobs) to tTime + tauMax 
  ##############################################################################

  #### Initialize fltLagVec and errLagVec (lagged values for flt and err)
  fltLagVec <- x1$fltLag
  errLagVec <- x1$errLag

  #### Make xIndt
  ## Select useful data and append current value (0)
  xDept  <- x1$muMatrix[tLastIn, , drop = FALSE]
  xRett  <- matrix(data = 0, nrow = 1, ncol = neqn)
  xPredt <- xPred[tLastIn, , drop = FALSE]
  ## Make
  xIndt <- .xInd(iauxList = iauxList, xDep = xDept, xRet = xRett, 
    xPred = xPredt)$x

  #### Initialize
  tT <- tLastIn + 1
    
  #### Cycle
  while (tT <= tLastOut)
  {
    #### Compute the filtered values
    x1 <- .filterX(parmVal = parmVal, xDep = xDept, xInd = xIndt, 
      fltLag = fltLagVec, errLag = errLagVec, iauxList = iauxList)
  
    #### Store
    muMatrix[tT, ]  <- x1$muMatrix
    fltMatrix[tT, ] <- x1$fltMatrix
          
    #### Update the starting filtered values
    fltLagVec <- x1$fltLag
    errLagVec <- x1$errLag
     
    #### Make xIndt
    ## Select useful data and append current value (0)
    xDept  <- x1$muMatrix
    xRett  <- matrix(data = 0, nrow = 1, ncol = neqn)
    xPredt <- xPred[tT, , drop = FALSE]
    ## Make
    xIndt <- .xInd(iauxList = iauxList, xDep = xDept, xRet = xRett, 
      xPred = xPredt)$x
        
    #### Increase t
    tT <- tT + 1
  }

  
  ##############################################################################
  ## Part 4: Split forecasts
  ##############################################################################

  #### Filter decomposition
  x1 <- .filter.decomposition(mu = muMatrix, flt = fltMatrix)  
  
  #### Up to tTime
  ind <- 1 : tTime
  upto <- list(
    mu  = x1$mu[ind, , drop = FALSE], 
    eta = x1$eta[ind], 
    chi = x1$chi[ind, , drop = FALSE], 
    xi  = x1$xi[ind, , drop = FALSE])
  
  #### From tTime + 1 to tTime + tauMax 
  if (tauMax > 0)
  {
    ind <- (tTime + 1) : tLastOut
    after <- list(
      mu  = x1$mu[ind, , drop = FALSE], 
      eta = x1$eta[ind], 
      chi = x1$chi[ind, , drop = FALSE], 
      xi  = x1$xi[ind, , drop = FALSE])
  }
  else
  {
    after <- NULL
  }

  
  ##############################################################################
  ## Part 5: Answer 
  ##############################################################################
    
  ####
  list(
    tTime = tTime,
    tauMax = tauMax,
    nobs = nobs,
    upto = upto,
    after = after)
}
# ------------------------------------------------------------------------------


.forecasts.dm <-
function(parmVal, xDep, xRet, xPred, fltLag, errLag,
  tTimeIn, tTimeEnd, tauMax,  
  iauxList)
{
  ##############################################################################
  ## Description:
  ##  Build out of sample forecasts, from the estimated vMEM, for computing the 
  ##  Diebold_mariano statistic. Forecasts are made 
  ##  at tTimeIn for (tTimeIn + 1) ... (tTimeIn + tauMax)
  ##  ...
  ##  at tTimeEnd for (tTimeEnd + 1) ... (tTimeEnd + tauMax).  
  ##
  ## Arguments:
  ##  parmVal: (numeric)
  ##  xDep: (matrix)
  ##  xInd: (matrix)
  ##  xPred: (matrix)
  ##  tTimeIn: (numeric[1]) starting time at which to make forecasts. 
  ##  tTimeEnd: (numeric[1]) endind time at which to make forecasts. 
  ##  tauMax: (numeric[1]) maximum horizon. 
  ##  iauxList: (list) See .iaux() for details. 
  ##
  ## Value:
  ##  (matrix[tauMax,K]) of forecasts.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### Nobs
  nobs <- NROW(xDep)

  #### Set tTimeIn
  x1 <- tTimeIn[1]
  x1 <- round(abs(x1))
  tTimeIn <- max(x1, 1)
  #### Set tTimeEnd
  x1 <- tTimeEnd[1]
  x1 <- round(abs(x1))
  x1 <- max(x1, tTimeIn + 1)
  tTimeEnd <- min(x1, NROW(xDep))
  
  #### Set tauMax
  x1 <- tauMax[1]
  x1 <- round(abs(x1))
  tauMax <- max(x1, 1)
    
  #### Build 'xInd'
  xInd <- .xInd(iauxList = iauxList, 
    xDep = xDep, xRet = xRet, xPred = xPred)$x
  xInd <- as.matrix(xInd)
  #### Build 'xDep'
  xDep <- .xDep(x = xDep)$x
  xDep <- as.matrix(xDep)    
  #### Colnames
  cnames <- colnames(xDep)  

  #### Dimensions
  neqn <- NCOL(xDep)
  niv  <- NCOL(xInd)
  np   <- NROW(parmVal)
  nF   <- iauxList$nF
  nFor <- tTimeEnd - (tTimeIn - 1)
  
  
  ##############################################################################
  ## Part 2: Compute fltLag, errLag for initialization
  ##############################################################################
 
  #### Compute the filtered values
  if ( tTimeIn > 1 )
  {
    #### Select
    ind <- 1 : (tTimeIn - 1)
    
    #### Compute
    x1 <- .filterX(parmVal = parmVal, 
      xDep = xDep[ind, , drop = FALSE], xInd = xInd[ind, , drop = FALSE], 
      fltLag = fltLag, errLag = errLag, iauxList = iauxList)

    #### Initialize fltLag and errLag (lagged values for flt and err)
    fltLag <- x1$fltLag
    errLag <- x1$errLag
  }     
  
    
  ##############################################################################
  ## Part 3: Forecast conditionally on tTimeIn to tTimeEnd (1 at a time)
  ##############################################################################

  #### Initialize
  forec <- array(data = NA, dim = c(nFor, neqn, tauMax), 
    dimnames = list(tTime = tTimeIn : tTimeEnd, 
    series = cnames, tau = 1 : tauMax))

  #### Cycle from tTimeIn to tTimeEnd (as starting point)
  i <- 0
  tTime <- tTimeIn
  while (tTime <= tTimeEnd)
  {
    ####
    i <- i + 1 
  
    #### Make data
    xDept <- xDep[tTime, , drop = FALSE]   
    xIndt <- xInd[tTime, , drop = FALSE]   
  
    #### Update the filter 1-step ahead
    x1 <- .filterX(parmVal = parmVal, xDep = xDept, xInd = xIndt, 
      fltLag = fltLag, errLag = errLag, iauxList = iauxList)
    
    #### Store
    forec[i, , 1] <- x1$muMatrix

    #### Store fltLag and errLag (lagged values for flt and err)
    fltLag <- x1$fltLag
    errLag <- x1$errLag
    
    #### Initialize
    fltLag1 <- fltLag
    errLag1 <- errLag

    #### Cycle from 2 to tauMax
    tau <- 2
    while (tau <= tauMax)
    {
      #### Make xIndt
      ## Select useful data and append current value (0)
      xDept  <- x1$muMatrix
      xRett  <- matrix(data = 0, nrow = 1, ncol = neqn)
      xPredt <- xPred[tTime, , drop = FALSE]
      ## Make
      xIndt <- .xInd(iauxList = iauxList, xDep = xDept, xRet = xRett, 
        xPred = xPredt)$x

      #### Compute the filtered values
      x1 <- .filterX(parmVal = parmVal, xDep = xDept, xInd = xIndt, 
        fltLag = fltLag1, errLag = errLag1, iauxList = iauxList)

      #### Store
      forec[i, , tau] <- x1$muMatrix
    
      #### Update the starting filtered values
      fltLag1 <- x1$fltLag
      errLag1 <- x1$errLag
      
      #### Increment
      tau <- tau + 1
    }
  
    #### Increment
    tTime <- tTime + 1
  }
  
  
  ##############################################################################
  ## Part 5: Answer 
  ##############################################################################
    
  #### Answer
  forec
}
# ------------------------------------------------------------------------------


.filterX <-
function(parmVal, xDep, xInd, 
  fltLag, errLag, 
  iauxList)
{
  ##############################################################################
  ## Description:
  ##  Compute filtered values starting from pre-specified values of the 'flt' 
  ##  and 'err' components. 
  ##
  ## Arguments:
  ##  parmVal: (numeric) parameter values (all parameters used in the filter,
  ##   both free and fixed, need to be included).
  ##  xDep: (matrix) dependent variables.
  ##  xInd: (matrix) independent variables.
  ##  fltLag: (matrix) lagged values of the filter components.
  ##  errLag: (matrix) lagged values of the error components.
  ##  iauxList: (list) See '.iaux()'.
  ##
  ## Value:
  ##  (list) with components:
  ##   $fltLag: (numeric) .
  ##   $errLag: (numeric) .
  ##   $fltMatrix: (matrix) .
  ##   $muMatrix: (matrix) filtered values (conditional mean).
  ##############################################################################

  ## FUNCTION:

  #### Check
  np <- iauxList$np + iauxList$np1
  np <- iauxList$npx

  if ( NROW(parmVal) != np )
  {
    stop("'parmVal' must have", np, "elements,", 
      " whereas NROW(parmVal) = ", NROW(parmVal))
  }

  #### Settings
  nobs <- NROW(xDep)
  neqn <- NCOL(xDep)
  niv  <- NCOL(xInd)
  nF <- iauxList$nF  
  nE <- iauxList$nE  
  
  #### Call 
  x1 <- .Fortran( "MEMFLTX",
    np        = as.integer(np),
    parmVal   = as.double(parmVal),
    nobs      = as.integer(nobs),
    neqn      = as.integer(neqn),
    niv       = as.integer(niv),
    xDep      = as.double(xDep),
    xInd      = as.double(xInd),
    fltLag    = as.double(fltLag),
    errLag    = as.double(errLag),
    fltMatrix = double(nobs * nF),
    errMatrix = double(nobs * nE),
    muMatrix  = double(nobs * neqn),
    nF        = as.integer(iauxList$nF), 
    nLagF     = as.integer(iauxList$nLagF), 
    mLagF     = as.integer(iauxList$mLagF), 
    nE        = as.integer(iauxList$nE), 
    nLagE     = as.integer(iauxList$nLagE), 
    mLagE     = as.integer(iauxList$mLagE), 
    indMod    = as.integer(iauxList$indMod), 
    pos       = as.integer(iauxList$pos),
    in0Eqn    = as.integer(iauxList$in0Eqn), 
    np0Eqn    = as.integer(iauxList$np0Eqn), 
    in1Eqn    = as.integer(iauxList$in1Eqn), 
    np1Eqn    = as.integer(iauxList$np1Eqn), 
    in2Eqn    = as.integer(iauxList$in2Eqn), 
    np2Eqn    = as.integer(iauxList$np2Eqn),
    PACKAGE   = .package())
  #### Adjust
  x1$fltMatrix <- matrix(data = x1$fltMatrix, nrow = nobs)
  x1$errMatrix <- matrix(data = x1$errMatrix, nrow = nobs)
  x1$muMatrix  <- matrix(data = x1$muMatrix,  nrow = nobs)
  
  #### Answer
  ind <- c("fltLag", "errLag", "fltMatrix", "errMatrix", "muMatrix")
  x1[ind]
}
# ------------------------------------------------------------------------------


.Dfilter <-
function(parmVal, xDep, xInd, 
  iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  Compute filtered values and its derivatives starting from pre-specified 
  ##  values of the 'flt', 'err' components and the corresponding derivatives. 
  ##
  ## Arguments:
  ##  parmVal: (numeric) parameter values (all parameters used in the filter,
  ##   both free and fixed, need to be included).
  ##  xDep: (matrix) dependent variables.
  ##  xInd: (matrix) independent variables.
  ##  fltLag: (matrix) lagged values of the filter components.
  ##  errLag: (matrix) lagged values of the error components.
  ##  DfltLag: (matrix) lagged values of the derivative of filter components.
  ##  DerrLag: (matrix) lagged values of the derivative of error components.
  ##  iauxList: (list) See '.iaux()'.
  ##
  ## Value:
  ##  (list) with components:
  ##   $fltLag: (numeric) .
  ##   $errLag: (numeric) .
  ##   $fltMatrix: (matrix) .
  ##   $errMatrix: (matrix) .
  ##   $muMatrix: (matrix) filtered values (conditional mean).
  ##   $DfltMatrix: (matrix) .
  ##   $DerrMatrix: (matrix) .
  ##   $DmuMatrix: (matrix) filtered values (conditional mean).
  ##############################################################################

  ## FUNCTION:

  #### Settings
  nobs <- NROW(xDep)
  neqn <- NCOL(xDep)
  niv  <- NCOL(xInd)
  np   <- NROW(parmVal)
  nF   <- iauxList$nF  
  nE   <- iauxList$nE
  
  #### Call
  x1 <- .Fortran( "MEMDFLT",
    parmVal    = as.double(parmVal),
    nobs       = as.integer(nobs),
    neqn       = as.integer(neqn),
    niv        = as.integer(niv),
    xDep       = as.double(xDep),
    xInd       = as.double(xInd),
    ExDep      = as.double(dauxList$ExDep),
    ExInd      = as.double(dauxList$ExInd),
    fltLag     = as.double(dauxList$fltLag),
    DfltLag    = as.double(dauxList$DfltLag),
    errLag     = as.double(dauxList$errLag),
    DerrLag    = as.double(dauxList$DerrLag),
    fltMatrix  = double(nobs * nF),
    DfltMatrix = double(nobs * np * nF),
    errMatrix  = double(nobs * nE),
    DerrMatrix = double(nobs * np * nE),
    muMatrix   = double(nobs * neqn),
    DmuMatrix  = double(nobs * np * neqn),
    iterMu     = as.integer(iauxList$iterMu), 
    indMod     = as.integer(iauxList$indMod), 
    nF         = as.integer(iauxList$nF), 
    nLagF      = as.integer(iauxList$nLagF), 
    mLagF      = as.integer(iauxList$mLagF), 
    nE         = as.integer(iauxList$nE), 
    nLagE      = as.integer(iauxList$nLagE), 
    mLagE      = as.integer(iauxList$mLagE), 
    in0Eqn     = as.integer(iauxList$in0Eqn), 
    np0Eqn     = as.integer(iauxList$np0Eqn), 
    in1Eqn     = as.integer(iauxList$in1Eqn), 
    np1Eqn     = as.integer(iauxList$np1Eqn), 
    in2Eqn     = as.integer(iauxList$in2Eqn), 
    np2Eqn     = as.integer(iauxList$np2Eqn),
    npx        = as.integer(iauxList$npx), 
    pos        = as.integer(iauxList$pos), 
    np         = as.integer(iauxList$np), 
    posx       = as.integer(iauxList$posx), 
    np1        = as.integer(iauxList$np1), 
    posx1      = as.integer(iauxList$posx1), 
    PACKAGE    = .package())

  #### Adjust
  x1$fltMatrix  <- matrix(data = x1$fltMatrix,  nrow = nobs)
  x1$errMatrix  <- matrix(data = x1$errMatrix,  nrow = nobs)
  x1$muMatrix   <- matrix(data = x1$muMatrix,   nrow = nobs)
  x1$DfltMatrix <- matrix(data = x1$DfltMatrix, nrow = nobs * np)
  x1$DerrMatrix <- matrix(data = x1$DerrMatrix, nrow = nobs * np)
  x1$DmuMatrix  <- matrix(data = x1$DmuMatrix,  nrow = nobs * np)
  
  #### Answer
  ind <- c("fltLag", "errLag", "DfltLag", "DerrLag", 
    "fltMatrix", "errMatrix", "muMatrix", 
    "DfltMatrix", "DerrMatrix", "DmuMatrix")
  x1[ind]
}
# ------------------------------------------------------------------------------


.filter.names <-
function(neqn, nF)
{
  ##############################################################################
  ## Description:
  ##  Names of the filter components. 
  ##
  ## Arguments:
  ##  neqn: (numeric[1]) . 
  ##  nF: (numeric[1]) . 
  ##
  ## Value:
  ##############################################################################

  ## FUNCTION:

  #### Dimensions
  nEta <- nF - neqn
  nXi  <- nF - nEta

  #### xi
  x <- paste0("xi[", 1 : nXi, "]")
  #### eta
  if ( nEta == 1)
  {
    x <- c( "eta", x)
  }
  else if (nEta > 1)
  {
    x <- c(paste0("eta[", 1 : nEta, "]"), x)
  }
    
  #### Answer
  x
}
# ------------------------------------------------------------------------------


.filter.decomposition <-
function(mu, flt)
{
  ##############################################################################
  ## Description:
  ##  Decompose filtered values. 
  ##
  ## Arguments:
  ##  mu: (matrix[nobs, neqn]) Estimates of the conditional mean. 
  ##  flt: (matrix[nobs, neqn]) Estimates of the filtered components. 
  ##
  ## Value:
  ##  (list) with components
  ##  $mean: (numeric[neqn]) Estimate of the unconditional mean.
  ##  $mu: (matrix[nobs, neqn]) Estimates of the conditional mean. 
  ##  $eta: (matrix[nobs, 1]) Estimate of the long run component. 
  ##  $chi: (matrix[nobs, neqn]) Estimate of the specific long run components 
  ##   (mu + psi * eta). 
  ##  $xi: (matrix[nobs, neqn]) Estimate of the short run component. 
  ##############################################################################

  ## FUNCTION:

  #### Dimensions
  nobs <- NROW(mu)
  neqn <- NCOL(mu)
  nF   <- NCOL(flt)
  nEta <- nF - neqn
  indEta <- nEta > 0

  #### xi
  xi <- flt[, (nEta + 1) : nF]
  #### eta
  if ( indEta )
  {
    eta <- flt[, 1 : nEta]
  }
  else
  {
    eta <- rep.int(0, nobs)
  }
  #### chi = mu + psi * eta = mu - xi
  chi <- mu - xi
  
  #### Parameters
  if (indEta)
  {
    ####
    ind1  <- which.min(eta)
    ind2  <- which.max(eta)
    psi   <- ( chi[ind2,] - chi[ind1,] ) / ( eta[ind2] - eta[ind1] )
    muEst <- chi[ind1,] - psi * eta[ind1]    
  }
  else
  {
    psi <- NULL
    muEst <- chi[1,]
  }
    
  #### Answer
  list(mean = muEst, psi = psi, 
    mu = mu, eta = eta, chi = chi, xi = xi, flt = flt)
}
# ------------------------------------------------------------------------------


.filter <-
function(parmVal, xDep, xInd, ExDep, fltLag, errLag, 
  iauxList)
{
  ##############################################################################
  ## Description:
  ##  Compute the filter starting from initial values. 
  ##
  ## Arguments:
  ##  parmVal: ()
  ##  xDep: ()
  ##  xInd: ()
  ##  ExDep: ()
  ##  fltLag: ()
  ##  errLag: ()
  ##  iauxList: ()
  ##
  ## Value:
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  #### Settings
  neqn <- NCOL(xDep)
  
  #### Filtering
  ## parmVal -> parmValX (needed from filterX())
  parmValX <- .parmVal.2.X(parmVal = parmVal, iauxList = iauxList, 
    ExDep = ExDep)
  ## Filtering
  x1 <- .filterX(parmVal = parmValX, xDep = xDep, xInd = xInd, 
    fltLag = fltLag, errLag = errLag, iauxList = iauxList)

  #### Rename
  names(x1)[ names(x1) == "errMatrix" ] <- "err"

  #### Answer
  c( .filter.decomposition(mu = x1$muMatrix, flt = x1$fltMatrix), 
     x1[ c("err", "fltLag", "errLag") ] ) 
}
# ------------------------------------------------------------------------------


####
.filter.varianceDecomposition <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Decompose the variability of the filtered values. 
  ##
  ## Arguments:
  ##  x: (list) filtered values as produced by .filter()
  ##
  ## Value:
  ##  (list)
  ##############################################################################

	## FUNCTION:
	
  #### Number of obs
  nobs <- NROW(x$mu)
  neqn <- NCOL(x$mu)
  
  #### Remove the unconditional mean from both mu and chi 
  x$mu  <- x$mu  - matrix(data = x$mean, nrow = nobs, ncol = neqn, byrow = TRUE)
  x$chi <- x$chi - matrix(data = x$mean, nrow = nobs, ncol = neqn, byrow = TRUE)
  
  #### Correlations
  mu.mu   <- crossprod(x$mu) / nobs
  chi.chi <- crossprod(x$chi) / nobs
  xi.chi  <- crossprod(x$xi, x$chi) /nobs 
  xi.xi   <- crossprod(x$xi) / nobs
  
  #### Diagonals
  chi.mu   <- diag(chi.chi) / diag(mu.mu)
  xi.mu    <- diag(xi.xi) / diag(mu.mu)
  xi.sum   <- diag(xi.xi) / (diag(mu.mu) - 2 * diag(xi.chi))
  chi.sum  <- diag(chi.chi) / (diag(mu.mu) - 2 * diag(xi.chi))
  
  #### Check
  list(
    cov   = list(mu.mu = mu.mu, xi.xi = xi.xi, chi.chi = chi.chi, xi.chi = xi.chi), 
    ratio = list(chi.mu = chi.mu, xi.mu = xi.mu, chi.sum = chi.sum, xi.sum = xi.sum) )
}
# ------------------------------------------------------------------------------


################################################################################
## PART IV - FUNCTION:            Utility functions:
################################################################################

.parm1.matrix <-
function(x, parm)
{
  ##############################################################################
  ## Description:
  ##  Reshape parameters in vector or matrix form depending on eqn and from 
  ##  info.
  ##
  ## Arguments:
  ##  x: (data.frame) with columns 'parm', 'eqn', 'from', 'x'.
  ##  parm: (numeric) parameters to be reshaped.
  ##
  ## Value:
  ##  (numeric or matrix)
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  ####
  parm0  <- c(.betaE.N())                                 ## Without indices
  parmF  <- c(.alphaE.N(), .gammaE.N())                   ## With from only
  parmE  <- c(.psi.N(), .mu.N())                          ## With eqn only
  parmEF <- c(.betaX.N(), .alphaX.N(), .gammaX.N())       ## With eqn and from

  #### Number of equations
  neqn <- .neqn(x = x[, "eqn"])  
  
    
  ##############################################################################
  ## Part 2: Adjust
  ##############################################################################

  #### Compute
  if ( all(parm %in% parm0) )
  {
    #### Selector
    ind <- x[, "parm"] %in% parm
    #### Initialize
    x1 <- 0
    #### Append
    if ( any(ind) )
    {
      x1 <- x1 + sum(x[ind, "x"])
    }
  }
  else if ( all(parm %in% parmF) || all(parm %in% parmE) )
  {
    #### Selector
    ind <- x[, "parm"] %in% parm
    #### Initialize
    x1 <- numeric(neqn)
    #### Append
    if ( any(ind) )
    {
      x2   <- numeric(neqn)
      ind2 <- x[ind, "from"]
      x2[ind2] <- as.numeric(x[ind, "x"])
      x1 <- x1 + x2
    }
  }
  else if ( all(parm %in% parmEF) )
  {
    #### Selector
    ind <- x[, "parm"] %in% parm
    #### Initialize
    x1 <- matrix(0, neqn, neqn)
    #### Append
    if ( any(ind) )
    {
      x2   <- matrix(0, neqn, neqn)
      ind2 <- as.matrix(x[ind, c("eqn", "from")])
      x2[ind2] <- as.numeric(x[ind, "x"])
      x1 <- x1 + x2
    }
  }
  else
  {
    stop("Bad 'parm' argument")
  }
    
    
  ##############################################################################
  ## Part 3: Answer 
  ##############################################################################
  
  #### Answer
  x1
}
# ------------------------------------------------------------------------------


.parmVal.2.X <-
function(parmVal, iauxList, ExDep)
{
  ##############################################################################
  ## Description:
  ##  Transform 'parmVal' (including free parms only) to 'parmValX' (including 
  ##  fixed parms also).
  ##
  ## Arguments:
  ##  parmVal: (numeric) parameter values (free parameters only).
  ##  iauxList: (list) See '.iaux()'.
  ##  dauxList: (list) See '.daux()'.
  ##
  ## Value:
  ##  (numeric) parameter values (all parameters).
  ##############################################################################

  ## FUNCTION:

  #### Settings
  npX <- iauxList$np + iauxList$np1
    
  #### call
  x1 <- .Fortran( "P2PX",
    iterMu   = as.integer(iauxList$iterMu),
    indMod   = as.integer(iauxList$indMod),
    parmVal  = as.double(parmVal),
    ExDep    = as.double(ExDep),
    neqn     = as.integer(iauxList$neqn),
    np       = as.integer(iauxList$np),
    posX     = as.integer(iauxList$posx),
    np1      = as.integer(iauxList$np1),
    posX1    = as.integer(iauxList$posx1),
    parmValX = double(npX), 
    PACKAGE  = .package())$parmValX
    
  #### Answer
  x1
}
# ------------------------------------------------------------------------------


.d.parmValX.d.ParmVal <-
function(parmValX, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  Compute d(parmValX') / d(parmVal).
  ##
  ## Arguments:
  ##  parmValX: (numeric[npX]) parameter values.
  ##  iauxList: (list) See '.iaux()'.
  ##  dauxList: (list) See '.daux()'.
  ##
  ## Value:
  ##  (list) 
  ##   $g:
  ##   $h:
  ##############################################################################

  ## FUNCTION:

  #### Settings
  np  <- iauxList$np
  np1 <- iauxList$np1
  npX <- np + np1

  #### d(parmValX') / d(parmVal)
  dpX <- .Fortran( "DPXDP",
    iterMu   = as.integer(iauxList$iterMu),
    indMod   = as.integer(iauxList$indMod),
    parmValX = as.double(parmValX),
    ExDep    = as.double(dauxList$ExDep),
    neqn     = as.integer(iauxList$neqn),
    np       = as.integer(np),
    posX     = as.integer(iauxList$posx),
    np1      = as.integer(np1),
    posX1    = as.integer(iauxList$posx1),
    dpX      = double(np * npX), 
    PACKAGE  = .package())$dpX
  matrix(data = dpX, nrow = np, ncol = npX)
}
# ------------------------------------------------------------------------------


.copy.UR.2.LL <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Copy the upper-right to the lower-left part of a symmetric matrix.
  ##
  ## Arguments:
  ##  x: (matrix) matrix.
  ##
  ## Value:
  ##  (matrix)
  ##############################################################################

  ## FUNCTION:

  #### Settings
  n <- sqrt(length(x))

  #### Call
  x <- .Fortran( "CPYURTOLL",
    x       = as.double(x),
    n       = as.integer(n),
    PACKAGE = .package())$x
    
  #### Reshape
  matrix(data = x, nrow = n)
}
# ------------------------------------------------------------------------------


################################################################################
## PART IV - FUNCTION:            Expectation Targeting routines:
################################################################################

.vcov <-
function(parmVal, xDep, xInd, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  Estimate the asymptotic variance matrix.
  ##
  ## Arguments:
  ##  parmVal: (numeric)
  ##  xDep: (matrix[nobs,neqn])
  ##  xInd: (matrix[nobs,niv])
  ##  iauxList: (list)
  ##  dauxList: (list)
  ## 
  ## Value:
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### Settings
  np   <- NROW(parmVal)
  nobs <- NROW(xDep)
  neqn <- NCOL(xDep)
  niv  <- NCOL(xInd)
  iterMu  <- iauxList$iterMu
  indIter <- .indIter(parm = iauxList$parm, eqn = iauxList$eqn, 
    iterMu = iauxList$iterMu, indMod = iauxList$indMod)
  ExDep <- as.numeric(dauxList$ExDep)
  ExInd <- as.numeric(dauxList$ExInd)

  
  ##############################################################################
  ## Part 2: Function evaluations
  ##############################################################################

  #### 'dMu' and 'hf'
  x1 <- .dmu.hf(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    iauxList = iauxList, dauxList = dauxList)
  hf  <- x1$hf
  dMu <- x1$dMu
  

  ##############################################################################
  ## Part 3: Compute the vcov matrix   
  ##############################################################################

  #### 'mu' is estimated iteratively?
  if (iterMu)
  {
    #### Omega^{-1}
    vcov <- try(expr = solve(hf), silent = FALSE)    
    #### Check
    if ( is.character(vcov) )
    {
      vcov <- matrix(data = NA, nrow = np, ncol = np)
    }
  }
  else
  {   
    #### Selector of 'theta' and 'mu'
    ind <- which( indIter | iauxList$parm == .mu.N() )
    parm <- iauxList$parm[ind]
    pos.m <- which( parm == .mu.N() )
    pos.t <- which( parm != .mu.N() )

    #### Try G_{theta,theta'}^{-1}
    ## Previous version but wrong
    x1 <- -hf[pos.t, pos.t] / nobs     
    x1 <- try(expr = solve(x1), silent = FALSE)

    #### Variance matrix
    if ( !is.character(x1) )
    {
      ##########################################################################
      ## Part 3.1: Compute   
      ##########################################################################

      #### Components
      ## G_{theta,theta'}^{-1}
      G.tt.inv <- x1
      ## -G_{mu,theta'}  
      G.mt <- -hf[pos.m, pos.t] / nobs
      ## Omega_{theta,theta'}
      O.tt <-  hf[pos.t, pos.t] / nobs
      ## Omega_{theta,mu'}
      O.tm <- dMu[pos.t, ] / nobs 
      ## Omega_{mu,mu'}            
      O.mm <- .vcov.mu.ET(parmVal = parmVal, xDep = xDep, xInd = xInd, 
        iauxList = iauxList, dauxList = dauxList) * nobs
  
      #### Compute G^{-1}
      np <- NROW(G.tt.inv)
      G.inv <- rbind(
        cbind( G.tt.inv,          matrix(0, np, neqn) ), 
        cbind( G.mt %*% G.tt.inv,         -diag(neqn) )) 
  
      #### Compute Omega
      O <- rbind( 
        cbind(    O.tt, O.tm),
        cbind( t(O.tm), O.mm) )
      
      #### Estimated vcov 
      vcov <- crossprod(G.inv, O) %*% G.inv / nobs
  
      
      ##########################################################################
      ## Part 3.2: Restore the starting parameter ordering   
      ##########################################################################
  
      #### Sort
      pos <- c(pos.t, pos.m)
      vcov[pos, pos] <- vcov      
    }
    else
    {
      vcov <- matrix(data = NA, nrow = np, ncol = np)
    }     
  }  
  
  #### Answer
  vcov
}
# ------------------------------------------------------------------------------


.vcov.mu.ET <-
function(parmVal, xDep, xInd, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##  Compute the variance covariance matrix of 'mu' coefficients in case of
  ##  Expectation Targeting.
  ##
  ## Arguments:
  ##  parmVal: (numeric[np])
  ##  xDep: (matrix[nobs,neqn])
  ##  xInd: (matrix[nobs, niv])
  ##  iauxList: (list)
  ##  dauxList: (list)
  ## 
  ## Value:
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### Settings
  nobs <- NROW(xDep)
  neqn <- NCOL(xDep)
  niv  <- NCOL(xInd)
  parm <- iauxList$parm
  
  #### ParmVal -> parmValX
  parmValX <- .parmVal.2.X(parmVal = parmVal, iauxList = iauxList, 
    ExDep = dauxList$ExDep)

  
  ##############################################################################
  ## Part 2: Compute V_{v;v^{-}) 
  ##############################################################################

  #### Fitted values
  mu <- .filter(parmVal = parmVal, xDep = xDep, xInd = xInd, 
    ExDep = dauxList$ExDep, fltLag = dauxList$fltLag, errLag = dauxList$errLag, 
    iauxList = iauxList)$mu
    
  #### Residuals v = x - mu)
  v  <- xDep - mu
  
  #### Residuals v^{-} = v * I(r < 0)
  ## Build I(r_t < 0)
  ind <- c( .gammaE.N(), .gammaX.N()) 
  ind <- any( parm %in% ind )
  if ( ind )
  {
    ind <- (niv - neqn + 1) : niv
    vm <- v * ( xInd[, ind] > 0 )
  }
  else
  {
    vm <- matrix(data = 0, nrow = nobs, ncol = neqn)
  }
  
  #### vcov matrix of (v, vm)
  x1 <- cbind(v, vm)
  vcov <- crossprod(x1) / nobs

  
  ##############################################################################
  ## Part 3: Compute Omega_{mu,mu'} 
  ##############################################################################
  
  #### Aggregate parms by lag
  x1 <- data.frame(parm = iauxList$parm, eqn = iauxList$eqn, 
    from = iauxList$from) 
  x1 <- aggregate(FUN = sum, by = x1, x = parmValX)

  #### Reshape parameters
  psi    <- .parm1.matrix(x = x1, parm = .psi.N())  
  betaE  <- .parm1.matrix(x = x1, parm = .betaE.N())  
  betaX  <- .parm1.matrix(x = x1, parm = .betaX.N())
  alphaE <- .parm1.matrix(x = x1, parm = .alphaE.N())  
  alphaX <- .parm1.matrix(x = x1, parm = .alphaX.N())
  gammaE <- .parm1.matrix(x = x1, parm = .gammaE.N())  
  gammaX <- .parm1.matrix(x = x1, parm = .gammaX.N())  

  #### Compute the matrices needed
  B <- cbind( psi / (1 - betaE), solve( diag(neqn) - betaX ) )
  A <- cbind( rbind(alphaE, alphaX), rbind(gammaE, gammaX) )
  A <- B %*% A
  
  if (neqn > 1)
  {
    ind <- 1 : neqn
    diag( A[ind, ind] ) <- diag( A[ind, ind] ) + 1  
  }
  else
  {
    A[1, 1] <- A[1, 1] + 1  
  }
    
  
  ##############################################################################
  ## Part 3: Compute Omega_{mu,mu'} 
  ##############################################################################

  #### Asymptotic variance matrix: A * V * A'
  tcrossprod(A %*% vcov, A) / nobs
}
# ------------------------------------------------------------------------------


.dmu.hf <-
function(parmVal, xDep, xInd, iauxList, dauxList)
{
  ##############################################################################
  ## Description:
  ##
  ## Arguments:
  ##  parmVal: (numeric)
  ##  xDep: (matrix[nobs,neqn])
  ##  xInd: (matrix[nobs,niv])
  ##  iauxList: (list)
  ##  dauxList: (list)
  ## 
  ## Value:
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings 
  ##############################################################################

  #### Settings
  np   <- NROW(parmVal)
  nobs <- NROW(xDep)
  neqn <- NCOL(xDep)
  niv  <- NCOL(xInd)
  npn  <- np + neqn
  ExDep <- as.numeric(dauxList$ExDep)
  ExInd <- as.numeric(dauxList$ExInd)
    
  
  ##############################################################################
  ## Part 2: Function evaluation 
  ##############################################################################

  #### Call  
  ans <- .Fortran( "MEMGO0",
    parmVal  = as.double(parmVal),
    nobs     = as.integer(nobs),
    neqn     = as.integer(neqn),
    niv      = as.integer(niv),
    xDep     = as.double(xDep),
    xInd     = as.double(xInd),
    ExDep    = as.double(ExDep),
    ExInd    = as.double(ExInd),
    dMu      = double(npn*neqn),
    hf       = double(npn*npn),
    indMod   = as.integer(iauxList$indMod), 
    nF       = as.integer(iauxList$nF), 
    nLagF    = as.integer(iauxList$nLagF), 
    mLagF    = as.integer(iauxList$mLagF), 
    nE       = as.integer(iauxList$nE), 
    nLagE    = as.integer(iauxList$nLagE), 
    mLagE    = as.integer(iauxList$mLagE), 
    in0Eqn   = as.integer(iauxList$in0Eqn), 
    np0Eqn   = as.integer(iauxList$np0Eqn), 
    in1Eqn   = as.integer(iauxList$in1Eqn), 
    np1Eqn   = as.integer(iauxList$np1Eqn), 
    in2Eqn   = as.integer(iauxList$in2Eqn), 
    np2Eqn   = as.integer(iauxList$np2Eqn), 
    npX      = as.integer(iauxList$npx),
    parm     = as.integer(iauxList$parm), 
    pos      = as.integer(iauxList$pos), 
    np       = as.integer(iauxList$np), 
    posX     = as.integer(iauxList$posx), 
    np1      = as.integer(iauxList$np1), 
    posX1    = as.integer(iauxList$posx1), 
    PACKAGE  = .package())
  
  #### Reshape in matrix form 
  dMu <- matrix(data = ans$dMu, nrow = npn)
  hf  <- .copy.UR.2.LL(x = ans$hf)


  ##############################################################################
  ## Part 3: Answer 
  ##############################################################################
  
  ####
  list(dMu = dMu, hf = hf)
}
# ------------------------------------------------------------------------------


################################################################################
## PART VI - FUNCTION:              FAST MODEL FORMULATION:
##  .model.build()                   Build a 'model' formulation starting from
##                                    a synthetic model formulation.
##  .model.build.parse()             Parse a synthetic 'model' formulation.
##  .model.build.label()             Synthetic model label about .model.build' 
##                                    formulation.
##  .model.build.values.parse.1()    Parse 'eqn' or 'from' values in the 
##                                    synthetic .model.build' formulation
##                                    (auxiliary function of 
##                                    '.model.build.parse.1()')
##  .model.build.parse.1()           Parse a line of a .model.build' formulation 
##                                    (auxiliary function of 
##                                    '.model.build.parse()').
##  .model.info.organize.1()         Compose model information (auxiliary 
##                                    function of '.model.build.parse.1()').
##  .model.build.extraInfo.add()     Extract extra information from 'add'.
##  .model.build.extraInfo()         Build extra information. 
##############################################################################

.model.build <- 
function(x)
{	
  ##############################################################################
  ## Description:
  ##  Convert a 'model' formulation into a formulation usable by vMEM.
  ##
  ## Arguments:
  ##  x: (list) with components
  ##   $type: (data.frame) model formulation. Each row must have 5 elements in 
  ##    the following order:
  ##     type[i,1]: (character) parameter name: one among "betaE", "alphaE", 
  ##      "gammaE", "betaX", "alphaX", "gammaX".
  ##     type[i,2]: (character): "f" for 'full', "d" for 'diagonal'. Ignored for
  ##      "*E" parameters.
  ##     type[i,3]: (character) equations. Accepted forms are of the following 
  ##      type:
  ##      "3":   only equation 3 is included;
  ##      "1:3": all equations between 1 and 3 are included;
  ##      "1,3": only equations 1 and 3 are included.
  ##     type[i,4]: (character) from. Accepted forms are identical to type[i,3].
  ##     type[i,5]: (numeric) lag. Accepted forms are identical to type[i,3].
  ##   $add: (character) parameters added to the formulation in the form
  ##    'parm[eqn, from, lag]'.
  ##   $remove: (character) parameters to be removed from the formulation in the 
  ##    same form as 'add'.
  ##
  ## Value:
  ##  (data.frame) model formulation including parameters and corresponding 
  ##   starting values.
  ##############################################################################

  ## FUNCTION:

  #### Extract
  if ( is.list(x) )
  {
    type   <- x$type
    add    <- x$add
    remove <- x$remove
  }
  else
  {
    type   <- x
    add    <- NULL
    remove <- NULL
  }

  #### First handling of 'add'
  x1 <- .model.build.extraInfo.add(add = add)
  
	#### Parse
	model <- .model.build.parse(type = type, add = x1$add, remove = remove)
  #### Starting values
  xX <- .model.build.extraInfo(x = model, add = x1) 
  model <- cbind(parm = model, xX)
	#### Make a model label
	label <- .model.build.label(type = type, add = x1$add, remove = remove)

	#### Answer
	list(model = model, label = label)
}
# ------------------------------------------------------------------------------


.model.build.parse <- 
function(type, add, remove)
{	
  ##############################################################################
  ## Description:
  ##  Parse a synthetic .model.build' formulation returning a character vector
  ##  whose elements of are in the form 'parm[eqn, from, lag].'
  ##
  ## Arguments:
  ##  type: (data.frame) model formulation. Each row must have 5 elements in 
  ##   the following order:
  ##    type[i,1]: (character) parameter name: one among "betaE", "alphaE", 
  ##     "gammaE", "betaX", "alphaX", "gammaX".
  ##    type[i,2]: (character): "f" for 'full', "d" for 'diagonal'. Ignored for
  ##     "*E" parameters.
  ##    type[i,3]: (character) equations. Accepted forms are of the following 
  ##     type:
  ##     "3":   only equation 3 is included;
  ##     "1:3": all equations between 1 and 3 are included;
  ##     "1,3": only equations 1 and 3 are included.
  ##    type[i,4]: (character) from. Accepted forms are identical to type[i,3].
  ##    type[i,5]: (numeric) lag. Accepted forms are identical to type[i,3].
  ##  add: (character) parameters added to the formulation in the form
  ##   'parm[eqn, from, lag]'.
  ##  remove: (character) parameters to be removed from the formulation in the 
  ##   same form as 'add'.
  ##
  ## Value:
  ##  (character) mu model formulation. Elements of are in the form
  ##   parm[eqn, from, lag].
  ##############################################################################

  ## FUNCTION:
  
	##############################################################################
	## Part 1: Handle 'type'
	##############################################################################

  #### Copy
  x <- type
  
  #### 
  if ( NROW(x) > 0 )
  {
    ############################################################################
    ## Part 1.1: Settings
    ############################################################################
  
    #### feasible colnames
    feasible <- c("parm", "type", "eqn", "from", "lag")

    #### If colnames are missing store them
    if (is.null(colnames(x)))
    {
      colnames(x) <- feasible[1:NCOL(x)]
    }

    #### Remove unfeasible colnames
    ind  <- colnames(x) %in% feasible
    if (!all(ind))
    {
       tmp <- paste("'", colnames(x)[!ind], "'", sep = "")
       warning("The following columns of 'model' are not feasible: ", tmp,
        "they have been removed")
       x <- x[, ind, drop = FALSE]
    }
  
    #### Remove duplicated colnames
    ind <- duplicated(colnames(x))
    if (any(ind))
    {
       x <- x[,!ind]
    }
  
    #### Check if at least columns 'parm', 'type', 'eqn', 'lag' are set
    tmp <- feasible[feasible != "from"]
    ind <- tmp %in% colnames(x)
    if (!all(ind))
    {
      tmp <- paste("'", tmp, "' ", sep = "")
      stop("All columns", tmp, "must be set")
    }
    
  
    ############################################################################
    ## Part 1.2: Select
    ############################################################################
    
    #### Select columns
    parm <- .convert.parm(x = x[, "parm"], type = "parm")
    lag  <- x[, "lag"]
    type <- x[, "type"]
    eqn  <- x[, "eqn"]
    if ( !("from" %in% colnames(x)) )
    {
      from <- eqn
    }
    else
    {
      from <- x[, "from"]
    }
	
	
    ############################################################################
    ## Part 1.3: Adjust
    ############################################################################

    #### parm
    type <- substr(x = type, start = 1, stop = 1)
    type <- tolower(x = type)
      
    #### Cycle
    model <- mapply(FUN = .model.build.parse.1, parm = parm, eqn = eqn, from = from, 
      lag = lag, type = type, SIMPLIFY = FALSE)
    model <- do.call(what = rbind, args = model)
          
    #### Condense to parameter names
    x <- .parmName(x = model)
  }


	##############################################################################
	## Part 2: Handle 'add'
	##############################################################################

	#### Add
	if (NROW(add) > 0)
	{
    x <- c(x, add)
	}
	x <- x[!duplicated(x)]


	##############################################################################
	## Part 3: Handle 'remove'
	##############################################################################

	#### Remove
	if (NROW(remove) > 0)
	{
		x <- x[!(x %in% remove)]
	}


	##############################################################################
	## Part 4: Answer
	##############################################################################

	#### Answer
	x
}
# ------------------------------------------------------------------------------


.model.build.label <- 
function(type, add, remove)
{
  ##############################################################################
  ## Description:
  ##  Return a synthetic model label.
  ##
  ## Arguments:
  ##  type: (data.frame) model formulation. Each row must have 5 elements in 
  ##  the following order:
  ##   type[i,1]: (character) parameter name: one among "betaE", "alphaE", 
  ##    "gammaE", "betaX", "alphaX", "gammaX".
  ##   type[i,2]: (character): "f" for 'full', "d" for 'diagonal'. Ignored for
  ##    "*E" parameters.
  ##   type[i,3]: (character) equations. Accepted forms are of the following 
  ##    type:
  ##    "3":   only equation 3 is included;
  ##    "1:3": all equations between 1 and 3 are included;
  ##    "1,3": only equations 1 and 3 are included.
  ##   type[i,4]: (character) from. Accepted forms are identical to type[i,3].
  ##   type[i,5]: (numeric) lag. Accepted forms are identical to type[i,3].
  ##  add: (character) parameters added to the formulation in the form
  ##   'parm[eqn, from, lag]'.
  ##  remove: (character) parameters to be removed from the formulation in the 
  ##   same form as 'add'.
  ##
  ## Value:
  ##  (character) synthetic model label.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  x <- "type:\n"
  if (NROW(type) > 0)
  {
    x1 <- apply(type, 1, paste, collapse = " ")
    x1 <- paste(x1, collapse = "\n")
    x <- paste(x, x1, "\n", sep = "")
  }
	
	#### Refine on the basis of add
  x <- paste(x, "+add(", NROW(add), "):\n", sep = "")
	if (NROW(add) > 0)
	{
		x1 <- paste(add, collapse = " ")
		x <- paste(x, x1, "\n", sep = "")
	}

	#### Refine on the basis of remove
  x <- paste(x, "-remove(", NROW(remove), "):\n", sep = "")
	if (NROW(remove) > 0)
	{
		x1 <- paste(remove, collapse = " ")
		x <- paste(x, x1, "\n", sep = "")
	}
	
	#### Answer
	x
}
# ------------------------------------------------------------------------------


.model.build.parse.1 <- 
function(parm, eqn, from, lag, type)
{
  ##############################################################################
  ## Description:
  ##  Auxiliary function of '.model.build.parse()'. Parse a single line of a .model.build 
  ##  formulation. 
  ##
  ## Arguments:
  ##  parm: (character) parameter
  ##  eqn: (numeric) equation
  ##  from: (numeric) from
  ##  lag: (numeric) lag
  ##  type: (character) "f" or "d" 
  ##
  ## Value:
  ##  (character) in the form 'parm[eqn, from, lag]'.
  ##############################################################################

  ## FUNCTION:

	#### Settings
	parm <- parm[1]
	lag  <- lag[1]
	type <- type[1]
  warn <- options()$warn
  options(warn = -1)
	eqn  <- .model.build.values.parse.1(eqn)
	from <- .model.build.values.parse.1(from)
	lag  <- .model.build.values.parse.1(lag)
  options(warn = warn)
	
  ##############################################################################
  ## Part 1: Checks
  ##############################################################################
  
  #### Check parameter
  ind <- !( parm %in% c(.eta.N(), .xi.N()) )
  if ( ind )
  {
    return(NULL)
  }

  #### Check eqn
  ind <- parm %in% .xi.N() 
  if ( ind )
  { 
    eqn <- eqn[ eqn > 0]
    if ( NROW(eqn) == 0 )
    {
      return(NULL)
    }
  }
  else
  {
    eqn <- NA
  }

  #### Check from
  ind <- ( parm %in% c(.alphaE.N(), .gammaE.N()) ) | 
    ( parm %in% .xi.N() & (type == "f") )
  if ( ind )
  { 
    from <- from[ from > 0]
    if ( NROW(from) == 0 )
    {
      return(NULL)
    }
  }
  else
  {
    from <- NA
  }

  #### Check lags
  lag <- round(abs(lag))
  lag <- lag[lag > 0]
  if ( NROW(lag) == 0 )
  {
    return(NULL)
  }
    
  #### Compose eqn and from info for 'alphaX', 'gammaX', 'betaX'
  if ( parm %in% .xi.N() )
  {        
    #### Argument type == "d"
    if (type == "d")
    {
      #### Combine ('from' is set = to 'eqn' and 'from' input is ignored)
      x1 <- cbind(eqn, eqn)
    }
    
    #### Argument type == "f"
    else if (type == "f")
    {
      ####
      if (parm == .betaX.N())
      {
        from <- from[from %in% eqn]
      }
        
      #### Combine
      x1 <- .combine(eqn, from)
    }

    #### Append lags
    x1 <- .combine(x1, lag)
    
    #### Extract info
    eqn  <- x1[, 1]
    from <- x1[, 2]
    lag  <- x1[, 3]
  }
  
  #### Answer
  .model.info.organize.1(parm = parm, eqn = eqn, from = from, lag = lag)
}
# ------------------------------------------------------------------------------


.model.build.values.parse.1 <- 
function(x)
{
  ##############################################################################
  ## Description:
  ##  Parse 'eqn' or 'from' values in the synthetic .model.build' formulation. 
  ##  It is an auxiliary function of '.model.build.parse.1'.
  ##
  ## Arguments:
  ##  x: (character)  
  ##
  ## Value:
  ##  (character)
  ##############################################################################

  ## FUNCTION:

	#### Settings
	x <- x[1]
	
	#### Corrections
	## Replace '-' with ','
	x <- gsub(x = x, pattern = "-", replacement = ":", fixed = TRUE)
	## Replace '.' with ','
	x <- gsub(x = x, pattern = ".", replacement = ",", fixed = TRUE)
	## Replace ';' with ','
	x <- gsub(x = x, pattern = ";", replacement = ",", fixed = TRUE)

	#### Select 'digits', ':', ','
	x <- gsub(x = x, pattern = "[^([:digit:]:,)]", replacement = "")
	
	#### Build command
	x <- paste("sort(", "c(", x, ")", ")", sep = "")
	
	#### Evaluate
	x <- eval(parse(text = x))
  #### Replace a NULL with a NA
  if ( NROW(x) == 0 )
  {
    x <- NA
  }
  
  #### Answer
  x
}
# ------------------------------------------------------------------------------


.model.info.organize.1 <- 
function(parm, eqn, from, lag)
{
  ##############################################################################
  ## Description:
  ##  Auxiliary function of '.model.build.parse.1()'. Compose model information. 
  ##
  ## Arguments:
  ##  parm: (character[1]) parameter.
  ##  eqn: (numeric) equation.
  ##  from: (numeric) from.
  ##  lag: (numeric) lag. 
  ##
  ## Value:
  ##  (character) in the form 'parm[eqn, from, lag]'.
  ##############################################################################

  ## FUNCTION:

	#### Settings
	parm <- parm[1]
	
  #### 'psi', 'mu'
  if ( parm %in% c(.psi.N(), .mu.N()) )
  {
    data.frame(parm = parm, eqn = eqn, from = NA, lag = NA)
  }
  #### 'betaE'
  else if ( parm == .betaE.N() )
  {
    data.frame(parm = parm, eqn = NA, from = NA, lag = lag)
  }
  #### 'alphaE', 'gammaE'
  else if ( parm %in% c( .alphaE.N(), .gammaE.N() ) )
  {
    data.frame(parm = parm, eqn = NA, from = from, lag = lag)
  }
  #### 'alphaX', 'gammaX', 'betaX'
  else if ( parm %in% .xi.N() )
  {    
    data.frame(parm = parm, eqn = eqn, from = from, lag = lag)
  }
	else
	{
		stop("Parameter ", parm, " is not feasible.")
	}
}
# ------------------------------------------------------------------------------


.model.build.extraInfo.add <- 
function(add)
{	
  ##############################################################################
  ## Description:
  ##  Extract extra information from 'add'.
  ##
  ## Arguments:
  ##  add: (character or matrix) parameters added to the formulation in the 
  ##   form c("parm[eqn, from, lag]", value) for each row. value can be missing.
  ##
  ## Value:
  ##  (matrix) extra information extracted from 'add'.
  ##############################################################################

  ## FUNCTION:
  
	#### Return immediately if 'add' is empty or has only 1 column
	if (NROW(add) <= 1)
  {
    xAdd <- NULL
  }
  else
  {    
    #### Remove duplicated
    add <- as.matrix(add)
    ind <- ifelse("parm" %in% colnames(add), "parm", 1)
    add <- add[!duplicated(add[, ind]), , drop = FALSE]
        
    #### Extract
    x1 <- .extract.model(x = add)
    ind <- !( colnames(x1) %in% c("parm", "eqn", "from", "lag") )
    xAdd <- x1[, ind, drop = FALSE]
    add <- add[, 1]
  }
  
  #### Answer
  list(add = add, x = xAdd)
}
# ------------------------------------------------------------------------------


.model.build.extraInfo <- 
function(x, add)
{
  ##############################################################################
  ## Description:
  ##  Build extra information. 
  ##
  ## Arguments:
  ##  x: (character) model formulation.
  ##  xAdd: (matrix) 'add' extra information.
  ##
  ## Value:
  ##  (matrix) whole 'x' extra information.
  ##############################################################################

  ## FUNCTION:

  #### Extract
  xAdd <- add$x
  add  <- add$add

  #### Return immediately if 'xAdd' is empty
  if (NROW(xAdd) == 0)
  {
    return(NULL)
  }
  
  #### Fill
  xX <- matrix(data = NA, nrow = NROW(x), ncol = NCOL(xAdd))
  colnames(xX) <- colnames(xAdd) 
  xX[x %in% add, ] <- xAdd
  
  #### Answer
  xX
}
# ------------------------------------------------------------------------------

