################################################################################
## 
## File: MEM-Main-dev1.R
## 
## Purpose: 
##  R functions for MEM.
##
## Created: 2010.04.30
## 
## Version: 2017.10.14
##
## Author: 
##  Fabrizio Cipollini <cipollini@disia.unifi.it>
##
################################################################################

################################################################################
## Package name
################################################################################

.package <- function() { "vMEM" }


################################################################################
## MEM
################################################################################

MEM <-
function(xDep, xRet = NULL, xPred = NULL, 
  model = NULL, control = NULL, fileout = "")
{
  ##############################################################################
  ## Description:
  ##  Summarize steps for model estimation.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) specifies the formulation of the model.
  ##  control: (list) control list.
  ##  fileout: (character[1])
  ##
  ## Values: 
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 0: Settings
  ##############################################################################

  #### Constants
  .Machine.constants()

  #### Method
  method <- control$method
  ind <- method %in% c("settings", "inference", "g2s")
  if ( !ind )
  {
    stop("Invalid 'control$method' settings")
  }
  

  ##############################################################################
  ## Part 1: Build
  ##############################################################################

  #### Build
  x1 <- .model.build(x = model)
  model <- x1$model
  label <- x1$label 
   
  #### Save
  if ( NROW(fileout) > 0 && fileout != "")
  {
    cat(file = fileout, append = TRUE, label, "\n")
  }
  
  #### Extract
  model <- .extract.model(x = model)  
  
  ##############################################################################
  ## Part 2: Settings
  ##############################################################################
  
  ####
  if (method == "settings")
  {
    .MEM.settings(xDep = xDep, xRet = xRet, xPred = xPred,
      model = model, control = control, fileout = fileout)
  }  


  ##############################################################################
  ## Part 3: Estimation and inference
  ##############################################################################

  ####
  else if (method == "inference")
  {
    .MEM.inference(xDep = xDep, xRet = xRet, xPred = xPred,
      model = model, control = control, fileout = fileout)
  }


  ##############################################################################
  ## Part 4: General-to-specific model selection
  ##############################################################################

  ####
  else if (method == "g2s")
  {
    .MEM.g2s(xDep = xDep, xRet = xRet, xPred = xPred, 
      model = model, control = control, alpha = 0.05, fileout = fileout)
  }
}
# ------------------------------------------------------------------------------


MEM.forecast <-
function(xDep, xRet = NULL, xPred = NULL, model, 
  tTime, tauMax)
{
  ##############################################################################
  ## Description:
  ##  MEM: Forecasts.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) specifies the formulation of the model.
  ##  tTime: (numeric[1]) time at which to make forecasts. 
  ##  tauMax: (numeric[1]) largest horizon for forecasts. 
  ##
  ## Values:
  ##  (matrix) Forecasts.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Set control
  control <- list(method = "settings", algr = NULL)

  #### Retrieve model     
  modelX <- .extract.model(x = model)
  ind    <- modelX[, "parm"] %in% .filter.N()
  modelX <- as.data.frame( modelX[ind, , drop = FALSE] )
  modelX <- cbind(.parmName(x = modelX), modelX[, "start"] )
  colnames(modelX) <- NULL
  
  #### Make MEM settings for retrieving 'iauxList' and 'inference'
  xEst <- MEM(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = modelX, control = control, fileout = "")
  

  ##############################################################################
  ## Part 2: Answer
  ##############################################################################

  #### Answer
  .forecasts(parmVal = xEst$model[, "start"], 
    xDep = xDep, xRet = xRet, xPred = xPred,  
    tTime = tTime, tauMax = tauMax,  
    iauxList = xEst$iauxList)
}
# ------------------------------------------------------------------------------


MEM.forecast.dm <-
function(xDep, xRet = NULL, xPred = NULL, model, 
  tTimeIn, tTimeEnd, tauMax)
{
  ##############################################################################
  ## Description:
  ##  MEM: Forecasts.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) specifies the formulation of the model.
  ##  tTime: (numeric[1]) time at which to make forecasts. 
  ##  tauMax: (numeric[1]) largest horizon for forecasts. 
  ##
  ## Values:
  ##  (matrix) Forecasts.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Set control
  control <- list(method = "settings", algr = NULL)

  #### Retrieve model     
  modelX <- .extract.model(x = model)
  ind    <- modelX[, "parm"] %in% .filter.N()
  modelX <- as.data.frame( modelX[ind, , drop = FALSE] )
  modelX <- cbind(.parmName(x = modelX), modelX[, "start"] )
  colnames(modelX) <- NULL
  
  #### Accommodate for .model.build()
  modelX <- list(add = modelX)
  
  #### Make MEM settings for retrieving 'iauxList' and 'inference'
  xEst <- MEM(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = modelX, control = control, fileout = "")
  

  ##############################################################################
  ## Part 2: Answer
  ##############################################################################

  #### Answer
  .forecasts.dm(parmVal = xEst$model[, "start"], 
    xDep = xDep, xRet = xRet, xPred = xPred,  
    tTimeIn = tTimeIn, tTimeEnd = tTimeEnd, tauMax = tauMax,  
    iauxList = xEst$iauxList)
}
# ------------------------------------------------------------------------------


MEM.filter <-
function(xDep, xRet = NULL, xPred = NULL, 
  ExDep = NULL, fltLag, errLag, 
  model)
{
  ##############################################################################
  ## Description:
  ##  MEM: Filter.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  fltLag: (numeric) starting values of 'flt'.
  ##  errLag: (numeric) starting values of 'err'.
  ##  ExDep: (numeric) mean of the dependent.
  ##  model: (data.frame) specifies the formulation of the model.
  ##
  ## Values:
  ##  (matrix) Filter.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Set control
  control <- list(method = "settings", algr = NULL)

  #### Retrieve model     
  modelX <- .extract.model(x = model)
  ind    <- modelX[, "parm"] %in% .filter.N()
  modelX <- as.data.frame( modelX[ind, , drop = FALSE] )
  modelX <- cbind(.parmName(x = modelX), modelX[, "start"] )
  colnames(modelX) <- NULL
  
  #### Accommodate for .model.build()
  modelX <- list(add = modelX)
    
  #### Make MEM settings for retrieving 'iauxList' and 'inference'
  xEst <- MEM(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = modelX, control = control, fileout = "")
  

  ##############################################################################
  ## Part 2: Answer
  ##############################################################################

  #### Set dauxList
  if ( NROW(ExDep) == 0 )
  {
    ExDep <- xEst$dauxList$ExDep
  }

  #### Answer
  .filter(parmVal = xEst$parmValStart, xDep = xEst$xDep, xInd = xEst$xInd, 
    ExDep = ExDep, fltLag = fltLag, errLag = errLag, 
    iauxList = xEst$iauxList) 
}
# ------------------------------------------------------------------------------


################################################################################
## PART II - FUNCTION                       Auxiliary functions
################################################################################

.MEM.initialize <-
function(xDep, xRet, xPred, model, control)
{
  ##############################################################################
  ## Description:
  ##  Make data for MEM estimation.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) model formulation 'extracted' by '.model.extract()'.
  ##  control: (list) control list.
  ##
  ## Values: 
  ##  (list)
  ##############################################################################

  ## FUNCTION:
  
  #### Check iterMu
  iter <- .control( control = control[c("iter", "method")] )$iter
  
  #### Check model
  model <- .check.model(x = model)

  #### Integer auxiliary info
  x1        <- .iaux(x = model, iter = iter)
  model     <- x1$model
  iauxList  <- x1$iaux
  iauxWList <- x1$iauxW

  #### Estimation options
  control <- .control(control = control, model = model)
  
  #### Model type
  type <- .model.type(x = model)

  #### Check model vs data inputs
  .check.modelVsData(iauxList = iauxList, xDep = xDep, xRet = xRet, xPred = xPred)
  
  #### Build 'xDep'
  tmp   <- .xDep(x = xDep)
  xDep  <- tmp$x
  ExDep <- tmp$Ex
  nobs  <- NROW(xDep)
  
  #### Build 'xInd'
  tmp  <- .xInd(iauxList = iauxList, xDep = xDep, xRet = xRet, xPred = xPred)
  ExInd <- tmp$Ex
  xInd  <- tmp$x
  
  #### Starting and bound values for parameters
  parmValStart <- .startingValues( model = model, ExDep = ExDep )
  parmValBound <- .boundValues( model = model, ExDep = ExDep )
  colnames( parmValBound ) <- c("parmValLeft", "parmValRight")
  model <- data.frame(model, parmValStart = parmValStart, parmValBound)

  #### Build starting values for the filter
  x1 <- .D.fltLag.errLag.start(parmVal = parmValStart, iauxList = iauxList, 
    xDep = xDep, nobs0 = control$nobs0)
    
  #### Real auxiliary info
  dauxList <- .daux(ExDep = ExDep, ExInd = ExInd, 
    fltLag = x1$flt$xL, DfltLag = x1$flt$dxL, 
    errLag = x1$err$xL, DerrLag = x1$err$dxL)
  
  #### Answer
  list(
     iauxList = iauxList,
    iauxWList = iauxWList,
     dauxList = dauxList,
      control = control, 
        model = model,
         xDep = xDep, 
         xInd = xInd,
        ExDep = ExDep, 
        ExInd = ExInd, 
         type = type)
}
# ------------------------------------------------------------------------------


################################################################################
## PART III - FUNCTION:            INFERENCE:
################################################################################

.MEM.settings <-
function(xDep, xRet, xPred, model, control, fileout)
{
  ##############################################################################
  ## Description:
  ##  Summarize settings.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) specifies the formulation of the model.
  ##  control: (list) control list.
  ##  fileout: (character[1]) .
  ##
  ## Values: 
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  #### Trace
  cat("\n-------------------------------------------------------------------\n")
  cat("\n", "MEM Settings", "\n")
  cat("\n-------------------------------------------------------------------\n")

  #### Initialize
  x1 <- .MEM.initialize(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = model, control = control)
  iauxList  <- x1$iauxList
  iauxWList <- x1$iauxWList
  dauxList  <- x1$dauxList
  control   <- x1$control 
  model     <- x1$model
  xDep      <- x1$xDep 
  xInd      <- x1$xInd
  ExDep     <- x1$ExDep 
  ExInd     <- x1$ExInd
  type      <- x1$type
  
  #### Starting values
  parmValStart <- model[model[,"indIter"], "parmValStart"]         
  
  #### Answer
  list(
        iauxList = iauxList,
       iauxWList = iauxWList,
        dauxList = dauxList,
         control = control, 
           model = model,
            xDep = xDep, 
            xInd = xInd,
           ExDep = ExDep, 
           ExInd = ExInd, 
            type = type, 
    parmValStart = parmValStart) 
}
# ------------------------------------------------------------------------------


.MEM.inference <-
function(xDep, xRet, xPred, model, control, fileout)
{
  ##############################################################################
  ## Description:
  ##  Summarize steps for model estimation.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) specifies the formulation of the model.
  ##  control: (list) control list.
  ##  fileout: (character[1]) .
  ##
  ## Values: 
  ##  (list)
  ##############################################################################

  ## FUNCTION:

  #### Trace
  cat("\n-------------------------------------------------------------------\n")
  cat("\n", "MEM Estimation", "\n")
  cat("\n-------------------------------------------------------------------\n")
      
  #### Initialize
  x1 <- .MEM.initialize(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = model, control = control)
  iauxList  <- x1$iauxList
  iauxWList <- x1$iauxWList
  dauxList  <- x1$dauxList
  control   <- x1$control 
  model     <- x1$model
  xDep      <- x1$xDep 
  xInd      <- x1$xInd
  ExDep     <- x1$ExDep 
  ExInd     <- x1$ExInd
  type      <- x1$type

  #### Starting values
  parmValStart <- model[model[,"indIter"], "parmValStart"]   

  #### Estimate
  tmp <- .gmmEst(parmVal = parmValStart, xDep = xDep, xInd = xInd, 
    iauxList = iauxList, dauxList = dauxList, control = control)
  parmValEst <- tmp$parmVal
  timeEst <- tmp$time
  nitEst <- tmp$nIter  
 
  #### Added stats
  added <- list(time = timeEst, nIter = nitEst)  

  #### Inference
  inference <- .inference(parmVal = parmValEst, 
    xDep = xDep, xInd = xInd, iauxList = iauxList, dauxList = dauxList, 
    iauxWList = iauxWList)

  #### Diagnostics
  diagnostics <- .diagnostics(parmVal = parmValEst, 
    xDep = xDep, xInd = xInd, iauxList = iauxList, dauxList = dauxList, 
    iauxWList = iauxWList)
    
  #### Print
  .print.MEM(inference = inference, diagnostics = diagnostics, 
    control = control, added = added, fileout = fileout)
    
  #### Answer
  list(
        iauxList = iauxList,
       iauxWList = iauxWList,
        dauxList = dauxList,
         control = control, 
           model = model,
            xDep = xDep, 
            xInd = xInd,
           ExDep = ExDep, 
           ExInd = ExInd, 
            type = type, 
    parmValStart = parmValStart,
      parmValEst = parmValEst,
       inference = inference,
     diagnostics = diagnostics, 
           added = added)
}
# ------------------------------------------------------------------------------


################################################################################
## PART IV - FUNCTION:            MODEL SELECTION:
################################################################################

.MEM.g2s <-
function(xDep, xRet, xPred, model, control,
  alpha, fileout)
{
  ##############################################################################
  ## Description:
  ##  General-to-specific model selection.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  model: (data.frame) model formulation 'extracted' by '.model.extract()'.
  ##  control: (list) control list.
  ##  alpha: (numeric[1]) significance level.
  ##  fileout: (character[1]) output filename.
  ##
  ## Values:
  ##  (list)
  ##############################################################################

  # FUNCTION:
  
  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Copy
  control.start  <- control
  model.start    <- model
  model.cnames   <- colnames(model)

  #### Threshold value
  z <- qnorm(1 - alpha / 2)

  #### Trace
  timeEstTot <- 0
  niter <- 0    


  ##############################################################################
  ## Part 2: Cycle
  ##############################################################################

  #### Iteration condition
  cond <- TRUE

  #### Cycle
  while (cond)
  {
    ############################################################################
    ## Part 2.1: Preliminars
    ############################################################################

    #### MEM preliminars
    x1 <- .MEM.initialize(xDep = xDep, xRet = xRet, xPred = xPred, 
      model = model, control = control.start)
    iauxList  <- x1$iauxList
    iauxWList <- x1$iauxWList
    dauxList  <- x1$dauxList
    control   <- x1$control 
    model     <- x1$model
    xDep      <- x1$xDep 
    xInd      <- x1$xInd
    ExDep     <- x1$ExDep 
    ExInd     <- x1$ExInd

    #### Further settings
    parmValStart <- model[model[,"indIter"], "parmValStart"]
    parm     <- model[, "parm"]
    parmName <- .parmName(x = model)
    iterMu   <- iauxWList$iterMu
    

    ############################################################################
    ## Part 2.2: Estimation and inference
    ############################################################################
      
    #### Trace
    niter <- niter + 1

    #### Estimate
    tmp <- .gmmEst(parmVal = parmValStart, xDep = xDep, xInd = xInd, 
      iauxList = iauxList, dauxList = dauxList, control = control)
    parmValEst <- tmp$parmVal
    timeEst    <- tmp$time
    timeEstTot <- timeEstTot + timeEst
    nitEst <- tmp$nit  
 
    #### Added stats
    added <- list(time = timeEst, nIter = nitEst)  
 
    #### Inference
    inference <- .inference(parmVal = parmValEst, xDep = xDep, xInd = xInd, 
      iauxList = iauxList, dauxList = dauxList, iauxWList = iauxWList)

    #### Diagnostics
    diagnostics <- .diagnostics(parmVal = parmValEst, 
      xDep = xDep, xInd = xInd, iauxList = iauxList, dauxList = dauxList, 
      iauxWList = iauxWList)
      
    #### Print
    .print.MEM(inference = inference, diagnostics = diagnostics, 
      control = control, added = added, fileout = fileout)


    ############################################################################
    ## Part 2.3: Adjust for the next step (if any)
    ############################################################################

    #### Extract useful info
    parmNameW <- inference$parmName

    #### Condition
    removed  <- .MEM.g2s.make.removed(inference = inference, 
      iauxWList = iauxWList, z = z)
    removedW <- removed[, "removed"]
    cond     <- removed[1, "type"] > 0

    #### Select and adjust for next step
    if (cond)
    {
      #### Trace
      cat(file = fileout, append = TRUE,
          "In next step (", niter + 1,
          ") we will remove", removedW, "\n")

      #### Starting values
      parmValStart <- .MEM.g2s.adjust.parmVal(inference = inference, 
        iauxWList = iauxWList, removed = removed)        
      ind <- parmNameW %in% parmName
      model[, "start"] <- parmValStart[ind]

      #### Removing unwanted rows
      ind <- !( (parmName %in% removedW) | (!iterMu & parm == .mu.N()) )
      model <- model[ind, model.cnames, drop = FALSE]
    }
  }


  ##############################################################################
  ## Part 3: Answer
  ##############################################################################

  #### Answer
    list(iauxList = iauxList,
        iauxWList = iauxWList,
         dauxList = dauxList,
          control = control, 
            model = model,
     parmValStart = parmValStart, 
       parmValEst = parmValEst,
        inference = inference,
      diagnostics = diagnostics, 
             xDep = xDep, 
             xInd = xInd,
            ExDep = ExDep, 
            ExInd = ExInd)
}
# ------------------------------------------------------------------------------


.MEM.g2s.make.removed <-
function(inference, iauxWList, z)
{
  ##############################################################################
  ## Description:
  ##  Find the parameter to be removed in the 'general-to-specific' model 
  ##  selection.
  ##
  ## Arguments:
  ##  inference: (list)
  ##  iauxWList: (list)
  ##  z: (numeric scalar)
  ##
  ## Value:
  ##  (data.frame) with columns:
  ##   "type": (numeric) 1/0 for removed for tStat/for other reasons. 
  ##   "removed": rows of removed elements in iauxWList. 
  ##############################################################################

  ## FUNCTION:

  #### Extract
  parm <- iauxWList$parm
  eqn  <- iauxWList$eqn
  from <- iauxWList$from
  lag  <- iauxWList$lag
  indIter <- .indIter(parm = parm, eqn = eqn, 
    iterMu = iauxWList$iterMu, indMod = iauxWList$indMod)
  parmName <- inference$parmName
  
  #### Parameters eligible for removing
  ## Version with alphaX[i,i,1] never removed
  indParm <- !( parm %in% c( .psi.N(), .mu.N() ) ) &
             !( parm %in% c( .alphaX.N() ) & eqn == from & lag == 1) &
             indIter
  indParm <- !( parm %in% c( .psi.N(), .mu.N() ) ) &
             indIter
  indParm[is.na(indParm)] <- FALSE

  #### Statistics
  tStat <- abs(inference$est / inference$se)
  tStat[is.na(tStat) | !indParm] <- 2 * z

  #### 
  parmName <- parmName[indParm]
  tStat    <- tStat[indParm]
  indStat  <- tStat < z
  parm     <- parm[indParm]
  eqn      <- eqn[indParm]

  #### Find removed components
  if (any(indStat))
  {     
    #### Find the parameter with the smallest tStat
    removedM <- data.frame(type = 1, removed = which.min(tStat))
 
    #### Adjust for the long term component: 
    #### 'psi' and 'betaE' must be excluded if all 'alphaE' and 'gammaE' are out.
    removedM <- .MEM.g2s.make.removed.long(parm = parm, removed = removedM)

    #### Adjust for the short term component: 
    #### 'betaX' must be excluded of an equation if all 'alphaX' and 'gammaX' 
    #### of the equation are out.
    removedM <- .MEM.g2s.make.removed.short(parm = parm, eqn = eqn, 
      removed = removedM)
 
    #### Convert
    removedM[, "removed"] <- parmName[ removedM[, "removed"] ]
  }
  else
  {
    removedM <- data.frame(type = 0, removed = "")
  }
  
  #### Answer
  removedM
}
# ------------------------------------------------------------------------------


.MEM.g2s.make.removed.long <- 
function(parm, removed)
{
  ##############################################################################
  ## Description:
  ##  Auxiliary function of .MEM.g2s.make.removed(). Adjust for the long term 
  ##  component, in the sense that 'psi' and 'betaE' are excluded if all 
  ##  'alphaE' and 'gammaE' are out.
  ##
  ## Arguments:
  ##  parm: (numeric)
  ##  removed: (data.frame)
  ##
  ## Value:
  ##  (data.frame) with columns:
  ##   "type": (numeric) 1/0 for removed for tStat/for other reasons. 
  ##   "removed": rows of removed elements in iauxWList. 
  ##############################################################################

  ## FUNCTION:

  #### Settings
  type    <- removed[, "type"]
  removed <- removed[, "removed"]

  #### Parameters involved
  parm1 <- c( .alphaE.N(), .gammaE.N() )
  parm2 <- c( .psi.N(), .betaE.N() )

  #### Ind of 'parm1' (but the removing element)
  ind1 <- parm %in% parm1
  ind1[removed] <- FALSE
  
  #### Ind of 'parm2'
  ind2 <- parm %in% parm2
  
  #### Update removed and type
  ind <- !any(ind1) & any(ind2)
  if ( ind )
  {
    ind <- which( ind2 )
    removed <- c(removed, ind)
    type <- c(type, numeric(NROW(ind)))
  }
 
  #### Answer
  data.frame(type = type, removed = removed)
}
# ------------------------------------------------------------------------------


.MEM.g2s.make.removed.short <- 
function(parm, eqn, removed)
{
  ##############################################################################
  ## Description:
  ##  Auxiliary function of .MEM.g2s.make.removed(). Adjust for the short term 
  ##  component, in the sense that 'betaX' are excluded from an equation if all 
  ##  'alphaX' and 'gammaX' of the equation are out.
  ##
  ## Arguments:
  ##  parm: (numeric)
  ##  eqn: (numeric)
  ##  removed: (data.frame)
  ##
  ## Value:
  ##  (data.frame) with columns:
  ##   "type": (numeric) 1/0 for removed for tStat/for other reasons. 
  ##   "removed": rows of removed elements in iauxWList. 
  ##############################################################################

  ## FUNCTION:

  #### Settings
  type    <- removed[, "type"]
  removed <- removed[, "removed"]
 
  #### Parameters involved
  parm1 <- c( .alphaX.N(), .gammaX.N() )
  parm2 <- .betaX.N()

  #### Ind of 'parm1' (but the removing element) and 'parm2'
  ind <- parm %in% c(parm1, parm2)
  ind[removed] <- FALSE

  #### There are equations with no 'parm1' but any 'parm2' parameters?
  tab  <- table( eqn[ind], parm[ind] )
  ind1 <- colnames(tab) %in% parm1
  ind2 <- colnames(tab) %in% parm2
  ind  <- rowSums(tab[, ind1, drop = FALSE]) == 0 & 
    rowSums(tab[, ind2, drop = FALSE]) > 0
  if ( any(ind2) && any(ind) )
  {
    x1  <- as.numeric( rownames(tab)[ind] )
    ind <- which( parm %in% parm2 & eqn %in% x1 )
    removed <- c(removed, ind)
    type <- c(type, numeric(NROW(ind)))
  }
 
  #### Answer
  data.frame(type = type, removed = removed)
}
# ------------------------------------------------------------------------------


.MEM.g2s.adjust.parmVal <-
function(inference, iauxWList, removed)
{
  ##############################################################################
  ## Description:
  ##  Adjust starting values for the next step in the 'back.current' procedure.
  ##
  ## Arguments:
  ##  parmVal: (numeric) parameter values.
  ##  removed: (data.frame) removed parameter.
  ##  iauxList: (list)
  ##
  ## Value:
  ##############################################################################

  ## FUNCTION:

  #### Settings
  ## Parameters
  parmName <- inference$parmName
  parmVal  <- inference$est
  np <- NROW(parmVal)
  ## Removed
  type1 <- as.logical(removed[, "type"])
  removed01 <- removed[, "removed"]
  removed1  <- removed01[ type1 ]
  ## iauxWList info
  parm <- iauxWList$parm
  eqn  <- iauxWList$eqn
  from <- iauxWList$from
  lag  <- iauxWList$lag
  indIter <- .indIter(parm = parm, eqn = eqn, 
    iterMu = iauxWList$iterMu, indMod = iauxWList$indMod)
    
  #### R parms info
  ind <- parmName == removed1
  parmValR <- parmVal[ind]
  parmR    <- parm[ind]
  eqnR     <- eqn[ind]
  fromR    <- from[ind]
  lagR     <- lag[ind]
    
  #### Multiply parmValR by 0.5 if parmR is a 'gamma'
  parmValR <- ifelse( parmR %in% c( .gammaE.N(), .gammaX.N() ), 
    parmValR, 0.5 * parmValR)
  
  #### Candidate to be replaced
  if ( parmR %in% .eta.N() )
  {
    cand <- parm %in% c( .alphaE.N(), .gammaE.N() )
  }
  else if ( parmR %in% .xi.N() )
  {
    #### Initialize
    cand <- parm %in% c( .alphaX.N(), .gammaX.N(), .betaX.N() )
    #### Attempt to merge by eqn, from, lag
    ## Merge
    ind <- apply(X = cbind(eqn == eqnR, from == fromR, lag == lagR), 
      FUN = cumsum, MARGIN = 1)
    ind1 <- ind == matrix(data = 1 : NROW(ind), NROW(ind), NCOL(ind), TRUE)
    ind1 <- which( apply(X = ind1, FUN = any, MARGIN = 1) )
    if ( NROW(ind1) > 0 )
    {
      ind1 <- ind1[ NROW(ind1) ]
      cand <- cand & ind[ind1, ] == ind1
    }
  }
  cand <- cand & indIter
  #### New values
  ## Usually 0...
  mult <- numeric(np)
  ## ... 1 for candidate
  mult[cand] <- 1
  ## ... 2 for 'gamma'...
  ind  <- cand & parm %in% c( .gammaE.N(), .gammaX.N() )
  mult[ind] <- 2
  ## ... 0 for removed.
  ind <- parmName %in% removed01
  mult[ind] <- 0
  ## Replace
  ind <- max(sum(mult > 0), 1)
  x1 <- mult * parmValR / ind
  parmVal <- parmVal + x1
    
  #### Answer
  parmVal
}
# ------------------------------------------------------------------------------


################################################################################
## Stupid functions required by induced regressors
################################################################################

MEM.Dfilter <-
function(xDep, xRet = NULL, xPred = NULL, 
  ExDep = NULL, fltLag = NULL, errLag = NULL, DfltLag = NULL, DerrLag = NULL, 
  model)
{
  ##############################################################################
  ## Description:
  ##  MEM: Filter.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  fltLag: (numeric) starting values of 'flt'.
  ##  errLag: (numeric) starting values of 'err'.
  ##  DfltLag: (numeric) starting values of 'Dflt'.
  ##  DerrLag: (numeric) starting values of 'Derr'.
  ##  ExDep: (numeric) mean of the dependent.
  ##  model: (data.frame) specifies the formulation of the model.
  ##
  ## Values:
  ##  (matrix) Filter.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Set control
  control <- list(method = "settings", algr = NULL)

  #### Retrieve model     
  modelX <- .extract.model(x = model)
  ind    <- modelX[, "parm"] %in% .filter.N()
  modelX <- as.data.frame( modelX[ind, , drop = FALSE] )
  modelX <- cbind(.parmName(x = modelX), modelX[, "start"] )
  colnames(modelX) <- NULL
  
  #### Accommodate for .model.build()
  modelX <- list(add = modelX)
    
  #### Make MEM settings for retrieving 'iauxList' and 'inference'
  xEst <- MEM(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = modelX, control = control, fileout = "")
  
  #### Set dauxList
  if ( NROW(ExDep) > 0 ) { xEst$dauxList$ExDep <- ExDep }
  if ( NROW(fltLag) > 0 ) { xEst$dauxList$fltLag <- fltLag }
  if ( NROW(DfltLag) > 0 ) { xEst$dauxList$DfltLag <- DfltLag }
  if ( NROW(errLag) > 0 ) { xEst$dauxList$errLag <- errLag }
  if ( NROW(DerrLag) > 0 ) { xEst$dauxList$DerrLag <- DerrLag }


  ##############################################################################
  ## Part 2: Make
  ##############################################################################

  #### Compute 
  x1 <- .Dfilter(parmVal = xEst$parmValStart, xDep = xEst$xDep, xInd = xEst$xInd, 
    iauxList = xEst$iauxList, dauxList = xEst$dauxList) 
  
  #### Names
  name1 <- .filter.names(neqn = xEst$iauxList$neqn, nF = xEst$iauxList$nF)
  colnames(x1$fltMatrix) <- colnames(x1$DfltMatrix) <- name1
  
  #### Parameter names
  parmName <- .parmName(xEst$model[, c("parm", "eqn", "from", "lag")])
  ind <- .indIter(parm = xEst$iauxList$parm, eqn = xEst$iauxList$eqn, 
    iterMu = xEst$iauxList$iterMu, indMod = xEst$iauxList$indMod)
  parmName <- parmName[ind]
  
  #### Answer
  c( list(parmName = parmName), x1 )
}
# ------------------------------------------------------------------------------


MEM.gMatrix <-
function(xDep, xRet = NULL, xPred = NULL, 
  ExDep = NULL, fltLag = NULL, errLag = NULL, DfltLag = NULL, DerrLag = NULL, 
  model)
{
  ##############################################################################
  ## Description:
  ##  MEM: Filter.
  ##
  ## Arguments:
  ##  xDep: (numeric) dependent variable.
  ##  xRet: (numeric) returns.
  ##  xPred: (numeric) predetermined variables.
  ##  fltLag: (numeric) starting values of 'flt'.
  ##  errLag: (numeric) starting values of 'err'.
  ##  DfltLag: (numeric) starting values of 'Dflt'.
  ##  DerrLag: (numeric) starting values of 'Derr'.
  ##  ExDep: (numeric) mean of the dependent.
  ##  model: (data.frame) specifies the formulation of the model.
  ##
  ## Values:
  ##  (matrix) Filter.
  ##############################################################################

  ## FUNCTION:

  ##############################################################################
  ## Part 1: Settings
  ##############################################################################

  #### Set control
  control <- list(method = "settings", algr = NULL)

  #### Retrieve model     
  modelX <- .extract.model(x = model)
  ind    <- modelX[, "parm"] %in% .filter.N()
  modelX <- as.data.frame( modelX[ind, , drop = FALSE] )
  modelX <- cbind(.parmName(x = modelX), modelX[, "start"] )
  colnames(modelX) <- NULL
  
  #### Accommodate for .model.build()
  modelX <- list(add = modelX)
    
  #### Make MEM settings for retrieving 'iauxList' and 'inference'
  xEst <- MEM(xDep = xDep, xRet = xRet, xPred = xPred, 
    model = modelX, control = control, fileout = "")


  ##############################################################################
  ## Part 2: Answer
  ##############################################################################

  #### Set dauxList
  if ( NROW(ExDep) > 0 ) { xEst$dauxList$ExDep <- ExDep }
  if ( NROW(fltLag) > 0 ) { xEst$dauxList$fltLag <- fltLag }
  if ( NROW(DfltLag) > 0 ) { xEst$dauxList$DfltLag <- DfltLag }
  if ( NROW(errLag) > 0 ) { xEst$dauxList$errLag <- errLag }
  if ( NROW(DerrLag) > 0 ) { xEst$dauxList$DerrLag <- DerrLag }

  #### Settings
  nobs <- NROW(xEst$xDep)
  neqn <- NCOL(xEst$xDep)
  niv  <- NCOL(xEst$xInd)
  parmVal <- xEst$parmValStart
  np   <- NROW(parmVal)
  iauxList <- xEst$iauxList
  dauxList <- xEst$dauxList
  
  #### Call
  x1 <- .Fortran( "MEMGV",
    parmVal    = as.double(parmVal),
    nobs       = as.integer(nobs),
    neqn       = as.integer(neqn),
    niv        = as.integer(niv),
    xDep       = as.double(xEst$xDep),
    xInd       = as.double(xEst$xInd),
    ExDep      = as.double(xEst$ExDep),
    ExInd      = as.double(xEst$ExInd),
    fltLag     = as.double(dauxList$fltLag),
    DfltLag    = as.double(dauxList$DfltLag),
    errLag     = as.double(dauxList$errLag),
    DerrLag    = as.double(dauxList$DerrLag),
    gfMatrix   = double(nobs * np),
    iterMu     = as.integer(iauxList$iterMu), 
    indMod     = as.integer(iauxList$indMod), 
    nF         = as.integer(iauxList$nF), 
    nLagF      = as.integer(iauxList$nLagF), 
    mLagF      = as.integer(iauxList$mLagF), 
    nE         = as.integer(iauxList$nE), 
    nLagE      = as.integer(iauxList$nLagE), 
    mLagE      = as.integer(iauxList$mLagE),
    in0Eqn     = as.integer(iauxList$in0Eqn), 
    np0Eqn     = as.integer(iauxList$np0Eqn), 
    in1Eqn     = as.integer(iauxList$in1Eqn), 
    np1Eqn     = as.integer(iauxList$np1Eqn), 
    in2Eqn     = as.integer(iauxList$in2Eqn), 
    np2Eqn     = as.integer(iauxList$np2Eqn),
    npx        = as.integer(iauxList$npx), 
    pos        = as.integer(iauxList$pos), 
    np         = as.integer(iauxList$np), 
    posx       = as.integer(iauxList$posx), 
    np1        = as.integer(iauxList$np1), 
    posx1      = as.integer(iauxList$posx1), 
    PACKAGE    = .package())
    
  #### Reshape
  x1 <- matrix(data = x1$gfMatrix, nrow = nobs)
  #### Parameter names
  parmName <- .parmName(xEst$model[, c("parm", "eqn", "from", "lag")])
  ind <- .indIter(parm = xEst$iauxList$parm, eqn = xEst$iauxList$eqn, 
    iterMu = xEst$iauxList$iterMu, indMod = xEst$iauxList$indMod)
  parmName <- parmName[ind]

  #### Answer
  list(parmName = parmName, x = x1)
}
# ------------------------------------------------------------------------------
