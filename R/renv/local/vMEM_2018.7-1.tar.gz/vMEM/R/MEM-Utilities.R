################################################################################
## 
## File: MEM-Utilities.R
##
## Purpose: Utilities for MEM.
##
## Created: 2007.02.07
##
## Version: 2012.10.30
##
## Author: 
##  Fabrizio Cipollini <cipollini@ds.unifi.it>
##
################################################################################
## PART I - FUNCTION:              GENERAL UTILITIES:
##  .factor()                       Recode values of a vector.
##  .rows.of.merge()                Rows of the merge.
## PART II - FUNCTION:             MATH UTILITIES:
##  A.op.tx()                       Compute 'A op t(x)', where A is a matrix and 
##                                   x a vector with as many elements as the 
##                                   columns of A.
##  .rep.mat()                      Replicates a matrix a given number of times.
##  .chol1()                        Cholesky decomposition (for testing the 
##                                   corresponding F77 subroutine). 
##  .matrix.sqrt()                  Compute the square root of a symmetric 
##                                   positive definite matrix.
################################################################################


################################################################################
## PART I - FUNCTION:              GENERAL UTILITIES:
##  .factor()                       Recode values of a vector.
##  .rows.of.merge()                Rows of the merge.
################################################################################

.factor <- 
function(x, levels, labels, typeNum = TRUE)
{
  ##############################################################################
  ## Description:
  ##  Recode values of a vector using a conversion matrix with old and new 
  ##  codes as columns
  ##
  ## Arguments:
  ##  x: (vector[n]) original values
  ##  levels: (vector[k]) present codes
  ##  labels: (vector[k]) new codes
  ##  typeNum: (logical[1]) if TRUE (default) returns a numeric otherwise a
  ##   character.
  ##
  ## Value: 
  ##  (vector[n]) recoded values.
  ##############################################################################

  ## FUNCTION:

  #### match
  ind <- match(x = x, table = levels)
  
  #### Build
  x <- labels[ind]

  #### Convert output
  if ( typeNum[1] )
  {
     as.numeric(x)
  }
  else
  {             
     as.character(x)       
  }
}
# ------------------------------------------------------------------------------


.rows.of.merge <- 
function(x1, x2)
{
  ##############################################################################
  ## Description:
  ##  Rows of the merge.
  ##
  ## Arguments:
  ##  x1: (data.frame) first data.frame.
  ##  x2: (data.frame) second data.frame.
  ##
  ## Value: 
  ##  (matrix[n,2]) rows1 and rows2.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  x1 <- data.frame(x1, row1 = 1 : NROW(x1))
  x2 <- data.frame(x2, row2 = 1 : NROW(x2))
  
  #### Make
  by.x <- colnames(x1)[colnames(x1) != "row1"]
  by.y <- colnames(x2)[colnames(x2) != "row2"]
  x <- merge(x = x1, y = x2, by.x = by.x, by.y = by.y, all = FALSE, 
    sort = FALSE)

  #### Answer
  x[, c("row1", "row2"), drop = FALSE]
}
# ------------------------------------------------------------------------------


################################################################################
## PART II - FUNCTION:             MATH UTILITIES:
##  A.op.tx()                       Compute 'A op t(x)', where A is a matrix and 
##                                   x a vector with as many elements as the 
##                                   columns of A.
##  .rep.mat()                      Replicates a matrix a given number of times.
##  .chol1()                        Cholesky decomposition (for testing the 
##                                   corresponding F77 subroutine). 
##  .matrix.sqrt()                  Compute the square root of a symmetric 
##                                   positive definite matrix.
##  .combine()                      Combine vectors in input.
################################################################################

.A.op.tx <- 
function(A, x, binOp)  
{
  ##############################################################################
  ## Description:
  ##  Compute 'A op t(x)', where A is a matrix and x a vector with as many 
  ##  elements as the columns of A.
  ##
  ## Arguments:
  ##  A: (matrix[m,n]) matrix.
  ##  x: (numeric[n]) vector.
  ##  binOp: (character[1]) binary operator.
  ## 
  ## Value: 
  ##  (matrix[m,n]) matrix of 'A[i,j] binOp x[j]' values
  ##############################################################################

  ## FUNCTION

  #### Answer  
  eval( parse( text = 
    paste("A", binOp, "rep.int( x, rep.int(NROW(A), NROW(x)) )", sep = "") 
      ) )      
}
# ------------------------------------------------------------------------------


.rep.mat <- 
function(x, times, byrow = FALSE)
{
  ##############################################################################
  ## Description:
  ##  Replicates a matrix a given number of times.
  ##
  ## Arguments:
  ##  x: (matrix[m,n]) original values.
  ##  times: (numeric[1]) number of times.
  ##  byrow: (logical[1]) replicates by row? 
  ##
  ## Value: 
  ##  (matrix[m*times, n]) replicated values.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  byrow <- byrow[1]
  times <- times[1]
  
  #### Make
  if ( !byrow )
  {
  	cnames <- colnames(x)
    x <- do.call( what = cbind, 
      args = lapply(FUN = rep.int, X = split(x = x, f = col(x)), times = times))
    colnames(x) <- cnames
  }
  else
  {
  	cnames <- rownames(x)
    x <- do.call( what = rbind, 
      args = lapply(FUN = rep.int, X = split(x = x, f = col(x)), times = times))
    rownames(x) <- cnames
  }
    
  #### Answer
  x
}
# ------------------------------------------------------------------------------


.chol1 <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Cholesky decomposition (for testing the corresponding F77 subroutine). 
  ##
  ## Arguments:
  ##  x: (matrix[n,n]) matrix.
  ##  
  ## Value:
  ##  (matrix[n,n]) Cholesky decomposition.
  ##############################################################################

  ## FUNCTION:

  #### Settings
  n <- NROW(x)
  
  #### Cholesky decomposition
  x <- .Fortran( 
    name    = "CHOL1",
    x       = as.double(x),
    n       = as.integer(n),
    ans     = double(n*n),
    PACKAGE = .package())$ans
  
  #### Answer
  matrix(data = x, nrow = n)
}
# ------------------------------------------------------------------------------


.matrix.sqrt <-
function(x)
{
  ##############################################################################
  ## Description:
  ##  Compute the square root of a symmetric positive definite matrix. 
  ##
  ## Arguments:
  ##  x: (matrix[n,n]) symmetric positive definite matrix.
  ##  
  ## Value:
  ##  (matrix[n,n]) Square root matrix.
  ##
  ## Remarks:
  ##  Take care: checks that the input is a pd matrix are omitted. 
  ##############################################################################

  ## FUNCTION:

  #### Settings
  n <- nrow(x)
  
  #### Eigen decomposition
  x1 <- eigen(x)
  
  #### Eigenvalues stored as (lambda, ..., lambda).
  lamM <- matrix(data = x1$values ^ 0.25, nrow = n, ncol = n, byrow = TRUE)
  
  #### Answer
  tcrossprod(x1$vectors * lamM)
}
# ------------------------------------------------------------------------------


.combine <-
function(...)
{
  ##############################################################################
  ## Description:
  ##  Combine arguments in input.
  ##
  ## Arguments:
  ##  (...) arguments. Each argument is forced to a vector.
  ##  
  ## Value:
  ##  (matrix) with as many columns as the number of arguments.
  ##
  ## Details:
  ##  We can use the function in two different options:
  ##  1) All arguments are vectors;
  ##  2) The first argument is a matrix, the second argument is a vector.
  ##  Other cases can give errors.
  ##############################################################################

  ## FUNCTION:

  #### Local function
  .replicate <-
  function(x1, x2)
  {  
    #### Settings
    r1 <- NROW(x1)
    c1 <- NCOL(x1)
    n1 <- r1 * c1
    r2 <- NROW(x2)
    
    #### Make
    x1 <- rep.int(x1, rep.int(r2, n1))  
    x2 <- rep.int(x2, r1)
  
    #### Answer
    cbind(matrix(data = x1, ncol = c1), x2) 
  }
  # ----------------------------------------------------------------------------

  #### Settings
  x1 <- list(...)  

  #### Settings
  n1 <- NROW(x1)
  
  #### Cases
  if ( n1 == 0 )
  {
    NULL
  }
  else if (n1 == 1)
  {
    x1[[1]]
  }
  else
  {
    #### Initialize
    x <- x1[[1]]
    
    #### Cycle
    for (i in 2 : n1)
    {
      x <- .replicate(x, x1[[i]] )
    }  
    
    ####
    x
  }
}
# ------------------------------------------------------------------------------
